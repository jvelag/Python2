"""
Gestionnaire des interactions avec les objets du jeu.
Auteur: Moss
Date: Novembre 2025
Cours: POO - Projet Blue Prince

Améliorations apportées :
- Gestion des callbacks pour l'interface
- Système de messages plus flexible
- Meilleure intégration avec le système de pièces
"""

import random
from typing import TYPE_CHECKING, Callable, List, Dict, Any, Optional

if TYPE_CHECKING:
    from models.player import Player
    from models.manor import Manor


class InteractionManager:
    """
    Gère toutes les interactions du joueur avec les objets du jeu.
    
    Cette classe centralise la logique d'interaction pour maintenir
    une séparation claire entre le modèle et la logique métier.
    
    Attributes:
        player (Player): Référence au joueur
        manor (Manor): Référence au manoir
        message_callback (Callable): Fonction pour afficher les messages
    """
    
    def __init__(self, player: 'Player', manor: 'Manor', message_callback: Optional[Callable] = None):
        """
        Initialise le gestionnaire d'interactions.
        
        Args:
            player: Le joueur
            manor: Le manoir  
            message_callback: Fonction pour afficher les messages
        """
        self.player = player
        self.manor = manor
        self.message_callback = message_callback or print
        
        # Configuration des tables de butin
        self._setup_loot_tables()
    
    def _setup_loot_tables(self):
        """Initialise les tables de butin pour les coffres et creusage."""
        self.chest_loot_table = [
            {'coins': 20, 'keys': 1},
            {'coins': 30, 'gems': 1},
            {'coins': 15, 'keys': 2},
            {'coins': 40},
            {'keys': 3},
            {'gems': 2},
            {'coins': 25, 'keys': 1},
            {},  # Coffre vide
        ]
        
        self.dig_loot_table = [
            {'coins': 15},
            {'keys': 1},
            {'gems': 1},
            {'coins': 10, 'keys': 1},
            {'coins': 20},
            {},  # Rien trouvé
        ]
        
        self.locker_loot_table = [
            {'coins': 10, 'keys': 1},
            {'coins': 15},
            {'keys': 2},
            {'dice': 1},
            {'coins': 20, 'dice': 1},
            {'gems': 1},
            {},  # Casier vide
        ]
    
    def _show_message(self, message: str, emoji: str = ""):
        """
        Affiche un message via le callback.
        
        Args:
            message: Message à afficher
            emoji: Émoji optionnel pour le message
        """
        formatted_message = f"{emoji} {message}" if emoji else message
        self.message_callback(formatted_message)
    
    # ========================================================================
    # MÉTHODE PRINCIPALE D'INTERACTION
    # ========================================================================
    
    def interact_with_item(self, item_type: str, item_data: dict = None) -> bool:
        """
        Point d'entrée principal pour interagir avec un objet.
        
        Args:
            item_type: Type d'objet ('food', 'chest', 'digging', etc.)
            item_data: Données supplémentaires de l'objet
            
        Returns:
            bool: True si l'interaction a réussi
        """
        if item_data is None:
            item_data = {}
        
        # Dispatch vers la méthode appropriée
        interaction_handlers = {
            'food': self._eat_food,
            'chest': self._open_chest,
            'digging': self._dig_spot,
            'locker': self._open_locker,
            'consumable': self._pickup_consumable,
            'permanent': self._pickup_permanent
        }
        
        handler = interaction_handlers.get(item_type)
        if handler:
            return handler(item_data)
        else:
            self._show_message(f"Unknown interaction type: {item_type}", "❌")
            return False
    
    def interact_with_item_key(self, item_key: str) -> bool:
        """
        Interagit avec un objet à partir de sa clé.
        
        Args:
            item_key: Clé de l'objet (ex: 'food_apple', 'chest')
            
        Returns:
            bool: True si l'interaction a réussi
        """
        item_type, item_data = parse_item_key(item_key)
        return self.interact_with_item(item_type, item_data)
    
    # ========================================================================
    # INTERACTION AVEC LA NOURRITURE
    # ========================================================================
    
    def _eat_food(self, food_data: dict) -> bool:
        """Mange de la nourriture pour regagner des pas."""
        food_type = food_data.get('type', 'apple')
        
        food_values = {
            'apple': 2, 'banana': 3, 'cake': 10, 
            'sandwich': 15, 'meal': 25
        }
        
        food_emojis = {
            'apple': '🍎', 'banana': '🍌', 'cake': '🍰',
            'sandwich': '🥪', 'meal': '🍽️'
        }
        
        steps_gained = food_values.get(food_type, 2)
        emoji = food_emojis.get(food_type, '🍽️')
        
        self.player.inventory.steps.add(steps_gained)
        self._show_message(f"Ate {food_type}, gained {steps_gained} steps!", emoji)
        return True
    
    # ========================================================================
    # INTERACTION AVEC LES COFFRES
    # ========================================================================
    
    def _open_chest(self, chest_data: dict) -> bool:
        """Ouvre un coffre avec une clé ou un marteau."""
        # Vérifie si le joueur a un marteau
        if self.player.inventory.has_item('hammer'):
            self._show_message("Opening chest with hammer (no key needed)!", "🔨")
            self._give_chest_loot()
            return True
        
        # Sinon, essaye avec une clé
        if self.player.inventory.keys.quantity > 0:
            self.player.inventory.keys.use(self.player)
            self._show_message("Opening chest with a key!", "🔑")
            self._give_chest_loot()
            return True
        else:
            self._show_message("Need a key or hammer to open this chest!", "❌")
            return False
    
    def _give_chest_loot(self):
        """Donne le contenu aléatoire d'un coffre."""
        loot_table = self.chest_loot_table.copy()
        
        # Modificateurs d'objets permanents
        if self.player.inventory.has_item('metal_detector'):
            self._show_message("Metal detector active: better loot!", "📡")
            loot_table.extend([
                {'coins': 50, 'keys': 2},
                {'coins': 60, 'keys': 3},
                {'coins': 45, 'keys': 1, 'gems': 1}
            ])
        
        if self.player.inventory.has_item('rabbit_foot'):
            self._show_message("Lucky rabbit's foot active!", "🍀")
            loot_table = [loot for loot in loot_table if loot]
        
        # Tire un lot au hasard
        loot = random.choice(loot_table)
        
        # Distribue le butin
        if loot:
            self._show_message("Chest contains:", "📦")
            for item_name, quantity in loot.items():
                self.player.inventory.add_item(item_name, quantity)
                self._show_message(f"+{quantity} {item_name}", self._get_item_emoji(item_name))
        else:
            self._show_message("The chest was empty...", "😞")
    
    # ========================================================================
    # INTERACTION AVEC LES ENDROITS À CREUSER
    # ========================================================================
    
    def _dig_spot(self, spot_data: dict) -> bool:
        """Creuse un endroit avec la pelle."""
        if not self.player.inventory.has_item('shovel'):
            self._show_message("You need a shovel to dig here!", "❌")
            return False
        
        self._show_message("Digging...", "⛏️")
        
        loot_table = self.dig_loot_table.copy()
        
        # Modificateurs
        if self.player.inventory.has_item('metal_detector'):
            self._show_message("Metal detector beeping!", "📡")
            loot_table.extend([
                {'coins': 25, 'keys': 1},
                {'coins': 30},
                {'keys': 2}
            ])
        
        if self.player.inventory.has_item('rabbit_foot'):
            self._show_message("Feeling lucky!", "🍀")
            loot_table = [loot for loot in loot_table if loot]
        
        # Tire un lot
        loot = random.choice(loot_table)
        
        # Distribue le butin
        if loot:
            self._show_message("Found:", "⛏️")
            for item_name, quantity in loot.items():
                self.player.inventory.add_item(item_name, quantity)
                self._show_message(f"+{quantity} {item_name}", self._get_item_emoji(item_name))
        else:
            self._show_message("Found nothing... just dirt.", "😔")
        
        return True
    
    # ========================================================================
    # INTERACTION AVEC LES CASIERS
    # ========================================================================
    
    def _open_locker(self, locker_data: dict) -> bool:
        """Ouvre un casier avec une clé."""
        # Vérifie si on est dans le vestiaire
        current_room = self.manor.get_room(self.player.position)
        if current_room and current_room.name != "Locker Room":
            self._show_message("Lockers can only be found in the Locker Room!", "❌")
            return False
        
        # Vérifie si le joueur a une clé
        if self.player.inventory.keys.quantity <= 0:
            self._show_message("You need a key to open this locker!", "❌")
            return False
        
        # Consomme une clé
        self.player.inventory.keys.use(self.player)
        self._show_message("Opening locker with a key...", "🔑")
        
        loot_table = self.locker_loot_table.copy()
        
        # Modificateur patte de lapin
        if self.player.inventory.has_item('rabbit_foot'):
            self._show_message("Lucky locker!", "🍀")
            loot_table = [loot for loot in loot_table if loot]
        
        # Tire un lot
        loot = random.choice(loot_table)
        
        # Distribue
        if loot:
            self._show_message("Locker contains:", "🗄️")
            for item_name, quantity in loot.items():
                self.player.inventory.add_item(item_name, quantity)
                self._show_message(f"+{quantity} {item_name}", self._get_item_emoji(item_name))
        else:
            self._show_message("The locker was empty...", "😞")
        
        return True
    
    # ========================================================================
    # RAMASSAGE D'OBJETS
    # ========================================================================
    
    def _pickup_consumable(self, item_data: dict) -> bool:
        """Ramasse un objet consommable au sol."""
        item_type = item_data.get('type', 'coins')
        quantity = item_data.get('quantity', 1)
        
        self.player.inventory.add_item(item_type, quantity)
        
        item_messages = {
            'coins': f"Picked up {quantity} coins!",
            'keys': f"Picked up {quantity} key{'s' if quantity > 1 else ''}!",
            'gems': f"Picked up {quantity} gem{'s' if quantity > 1 else ''}!",
            'dice': f"Picked up {quantity} dice!"
        }
        
        message = item_messages.get(item_type, f"Picked up {quantity} {item_type}!")
        self._show_message(message, self._get_item_emoji(item_type))
        return True
    
    def _pickup_permanent(self, item_data: dict) -> bool:
        """Ramasse un objet permanent."""
        item_type = item_data.get('type')
        
        if not item_type:
            self._show_message("No permanent item type specified!", "❌")
            return False
        
        # Ajoute l'objet permanent à l'inventaire
        success = self.player.inventory.add_permanent_item(item_type)
        
        if success:
            item_descriptions = {
                'shovel': "Now you can dig in special spots!",
                'hammer': "Now you can break chest locks!",
                'lockpick_kit': "Now you can pick simple locks!",
                'metal_detector': "Now you'll find more keys and coins!",
                'rabbit_foot': "Your luck has increased!"
            }
            
            description = item_descriptions.get(item_type, "Item obtained!")
            self._show_message(description, self._get_item_emoji(item_type))
            return True
        else:
            self._show_message(f"Could not obtain {item_type}!", "❌")
            return False
    
    def _get_item_emoji(self, item_name: str) -> str:
        """Retourne l'émoji correspondant à un objet."""
        emoji_map = {
            'coins': '🪙', 'keys': '🔑', 'gems': '💎', 'dice': '🎲',
            'shovel': '⛏️', 'hammer': '🔨', 'lockpick_kit': '🔓',
            'metal_detector': '📡', 'rabbit_foot': '🍀'
        }
        return emoji_map.get(item_name, '📦')
    
    # ========================================================================
    # MÉTHODES UTILITAIRES
    # ========================================================================
    
    def get_current_room(self):
        """Récupère la pièce actuelle du joueur."""
        return self.manor.get_room(self.player.position)
    
    def get_available_interactions(self) -> List[str]:
        """
        Récupère la liste des objets interactifs disponibles.
        
        Returns:
            Liste des clés d'objets avec lesquels on peut interagir
        """
        current_room = self.get_current_room()
        if not current_room:
            return []
        
        return [item for item in current_room.items if self.can_interact_with_object(item)]
    
    def can_interact_with_object(self, object_key: str) -> bool:
        """Vérifie si le joueur peut interagir avec un objet."""
        item_type, _ = parse_item_key(object_key)
        
        requirements = {
            'digging': lambda: self.player.inventory.has_item('shovel'),
            'chest': lambda: (self.player.inventory.keys.quantity > 0 or 
                             self.player.inventory.has_item('hammer')),
            'locker': lambda: (self.player.inventory.keys.quantity > 0 and
                              self.get_current_room().name == "Locker Room")
        }
        
        requirement_check = requirements.get(item_type)
        return requirement_check() if requirement_check else True


# ============================================================================
# FONCTIONS UTILITAIRES
# ============================================================================

def parse_item_key(item_key: str) -> tuple:
    """
    Parse une clé d'objet pour déterminer son type et ses données.
    """
    # Nourriture
    if item_key.startswith('food_'):
        food_type = item_key.replace('food_', '')
        return ('food', {'type': food_type})
    
    # Objet permanent
    elif item_key.startswith('permanent_'):
        perm_type = item_key.replace('permanent_', '')
        return ('permanent', {'type': perm_type})
    
    # Objets simples
    elif item_key in ['chest', 'digging', 'locker']:
        return (item_key, {})
    
    # Consommables simples
    elif item_key in ['coins', 'keys', 'gems', 'dice']:
        return ('consumable', {'type': item_key, 'quantity': 1})
    
    # Type inconnu
    else:
        return ('unknown', {})