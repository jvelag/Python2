# Rapport de Conception - Projet Blue Prince

> **Projet de Programmation Orientée Objet**  
> Master 1 Systèmes Communicants  
> Sorbonne Université - Année 2024/2025

---

**Étudiant :** CHABANE CHAOUCHE Mohand  
**Encadrant :** [Nom du Professeur]  
**Date de rendu :** 14 novembre 2025  
**Version :** 1.0

---

## 📋 Résumé Exécutif

Ce rapport présente les choix de conception et d'architecture du projet **Blue Prince**, une implémentation simplifiée du jeu vidéo éponyme en Python. Le projet met en œuvre les principes fondamentaux de la Programmation Orientée Objet (POO) à travers une architecture modulaire structurée en packages.

**Points clés :**
- Architecture MVC avec séparation claire des responsabilités
- Hiérarchie de classes utilisant abstraction et héritage
- Polymorphisme pour une extensibilité maximale
- Patterns de conception (Manager, Template Method)
- Interface graphique avec Pygame
- Plus de 3500 lignes de code organisées en 4 packages

---

## Table des Matières

1. [Introduction](#1-introduction)
2. [Contexte et Objectifs](#2-contexte-et-objectifs)
3. [Architecture Globale](#3-architecture-globale)
4. [Choix de Conception POO](#4-choix-de-conception-poo)
5. [Patterns de Conception](#5-patterns-de-conception)
6. [Décisions d'Implémentation](#6-décisions-dimplémentation)
7. [Système d'Aléatoire](#7-système-daléatoire)
8. [Difficultés Rencontrées](#8-difficultés-rencontrées)
9. [Tests et Validation](#9-tests-et-validation)
10. [Perspectives d'Amélioration](#10-perspectives-damélioration)
11. [Conclusion](#11-conclusion)

---

## 1. Introduction

### 1.1 Présentation du Projet

**Blue Prince** est un jeu d'exploration dans un manoir mystérieux où le joueur doit construire stratégiquement un chemin vers la sortie en gérant des ressources limitées. Le jeu se déroule sur une grille de **5 lignes × 9 colonnes** (45 pièces potentielles) où chaque nouvelle pièce est choisie parmi 3 options tirées aléatoirement.

### 1.2 Objectifs Pédagogiques

Le projet vise à démontrer la maîtrise des concepts fondamentaux de la POO :

| Concept | Application dans le projet |
|---------|---------------------------|
| **Abstraction** | Classe abstraite `Item` définissant le contrat pour tous les objets |
| **Héritage** | Hiérarchie à 3 niveaux (Item → ConsumableItem/PermanentItem/Food → classes concrètes) |
| **Polymorphisme** | Méthode `use()` redéfinie différemment selon le type d'objet |
| **Encapsulation** | Attributs privés et interfaces publiques claires |
| **Composition** | Player possède un Inventory (relation forte) |
| **Agrégation** | Manor contient des Room (relation faible) |

### 1.3 Technologies Utilisées

- **Langage :** Python 3.8+
- **Interface graphique :** Pygame 2.5.2
- **Architecture :** MVC (Model-View-Controller)
- **Gestion de version :** Git/GitHub

---

## 2. Contexte et Objectifs

### 2.1 Règles du Jeu

Le joueur commence avec **70 pas** et doit atteindre l'Antichambre (en haut de la grille). À chaque ouverture de porte :
1. Le jeu propose 3 pièces tirées aléatoirement
2. Le joueur choisit une pièce (coût possible en gemmes)
3. Le joueur entre dans la pièce et collecte les objets
4. Le déplacement coûte 1 pas

**Victoire :** Atteindre l'Antichambre  
**Défaite :** Épuiser tous ses pas

### 2.2 Ressources du Jeu

| Ressource | Initial | Utilité |
|-----------|---------|---------|
| 👣 **Pas** | 70 | Déplacement (1 pas par mouvement) |
| 🔑 **Clés** | 0 | Ouvrir portes verrouillées |
| 💎 **Gemmes** | 2 | Sélectionner pièces rares |
| 🪙 **Pièces** | 0 | Acheter dans les magasins |
| 🎲 **Dés** | 0 | Retirer le tirage de pièces |

### 2.3 Objectifs Techniques

1. **Architecture modulaire** - Code organisé et maintenable
2. **POO rigoureuse** - Application correcte des concepts
3. **Extensibilité** - Facilité d'ajout de fonctionnalités
4. **Testabilité** - Composants isolés et testables
5. **Documentation** - Code et architecture documentés

---

## 3. Architecture Globale

### 3.1 Vue d'Ensemble

Le projet suit une **architecture en couches** inspirée du pattern **MVC** :

```
┌─────────────────────────────────────────────────────────┐
│                  CONTRÔLEUR (C)                         │
│              BluePrinceGame (main.py)                   │
│                                                         │
│  Responsabilité : Orchestration                        │
│  • Gère la boucle de jeu                              │
│  • Traite les événements utilisateur                  │
│  • Coordonne Modèle et Vue                            │
└─────────────────────────────────────────────────────────┘
              ↓                           ↓
┌────────────────────────┐    ┌──────────────────────────┐
│    MODÈLE (M)          │    │       VUE (V)            │
│                        │    │                          │
│  models/               │    │  renderers/              │
│  • Données du jeu      │    │  • Affichage Pygame      │
│  • Entités (Item,      │    │  • GridRenderer          │
│    Room, Player...)    │    │  • InventoryRenderer     │
│                        │    │  • RoomSelectionMenu     │
│  managers/             │    │                          │
│  • Logique métier      │    │  utils/                  │
│  • RandomManager       │    │  • ResourceManager       │
│  • InteractionManager  │    │                          │
│  • ShopManager         │    │                          │
└────────────────────────┘    └──────────────────────────┘
```

### 3.2 Organisation en Packages

#### Structure Arborescente

```
blue-prince/
│
├── models/              📦 MODÈLE - Entités du jeu
│   ├── __init__.py     
│   ├── item.py          ⭐ Hiérarchie d'objets (480 lignes)
│   ├── inventory.py     🎒 Gestion inventaire (368 lignes)
│   ├── door.py          🚪 Système de portes (180 lignes)
│   ├── room.py          🏠 Catalogue de pièces (520 lignes)
│   ├── player.py        👤 Joueur (140 lignes)
│   └── manor.py         🏰 Grille du manoir (80 lignes)
│
├── managers/            ⚙️ LOGIQUE - Règles du jeu
│   ├── __init__.py
│   ├── random_manager.py       🎲 Aléatoire (200 lignes)
│   ├── interaction_manager.py  🔄 Interactions (350 lignes)
│   └── shop_manager.py         🛒 Magasin (100 lignes)
│
├── renderers/           🎨 VUE - Interface Pygame
│   ├── __init__.py
│   ├── grid_renderer.py        🗺️ Grille (180 lignes)
│   ├── inventory_renderer.py   📋 Inventaire (350 lignes)
│   └── room_selection_menu.py  📜 Menu (250 lignes)
│
├── utils/               🛠️ UTILITAIRES
│   └── resource_manager.py     🎨 Ressources (100 lignes)
│
└── main.py             🎯 CONTRÔLEUR (433 lignes)
```

**Total : ~3500 lignes de code**

### 3.3 Justification de l'Architecture

#### Pourquoi cette organisation en packages ?

**1. Separation of Concerns (SoC)**

Chaque package a une responsabilité unique :
- `models/` répond à la question **"QUOI ?"** (Quelles sont les entités ?)
- `managers/` répond à la question **"COMMENT ?"** (Comment fonctionne le jeu ?)
- `renderers/` répond à la question **"APPARENCE ?"** (Comment l'afficher ?)

**Avantage :** Les modifications dans un package n'impactent pas les autres.

**2. Réutilisabilité**

Le modèle (`models/` + `managers/`) est **totalement indépendant de Pygame** :

```python
# Le modèle fonctionne sans interface graphique
from models.player import Player
from models.manor import Manor

player = Player((4, 4))
manor = Manor()
player.move((3, 4), manor)  # Pas de Pygame nécessaire !
```

**Applications possibles :**
- Version terminal du jeu
- Version web (Flask/Django)
- Serveur multijoueur
- Tests automatisés

**3. Maintenabilité**

```python
# ❌ AVANT : Tout dans un fichier (10,000 lignes)
# Difficile de trouver une classe
# Modifications risquées (effets de bord)

# ✅ APRÈS : Packages séparés
models/item.py        # Je cherche Item ? C'est ici
renderers/grid.py     # Je veux modifier l'affichage ? C'est là
managers/random.py    # Je veux ajuster l'aléatoire ? C'est là
```

**4. Testabilité**

Chaque composant peut être testé isolément :

```python
# Test du modèle sans interface graphique
def test_inventory():
    inv = Inventory()
    inv.add_item("keys", 5)
    assert inv.keys.quantity == 5  # ✅ Test facile
```

---

## 4. Choix de Conception POO

### 4.1 Abstraction : La Classe `Item`

#### 4.1.1 Problématique

Comment garantir que **tous les objets du jeu** ont une interface commune ?

#### 4.1.2 Solution : Classe Abstraite

```python
from abc import ABC, abstractmethod

class Item(ABC):
    """
    Classe abstraite définissant le CONTRAT pour tous les objets.
    
    Garantit que chaque objet implémente use().
    """
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    
    @abstractmethod
    def use(self, player):
        """
        Méthode abstraite - DOIT être implémentée.
        
        Python lève TypeError si une sous-classe
        n'implémente pas cette méthode.
        """
        pass
```

#### 4.1.3 Justification du Choix

**Pourquoi une classe abstraite et pas juste une classe normale ?**

| Sans abstraction | Avec abstraction (Item) |
|-----------------|------------------------|
| ❌ Pas de garantie d'interface | ✅ Interface commune garantie |
| ❌ Erreurs à l'exécution | ✅ Erreurs à la création |
| ❌ Documentation implicite | ✅ Contrat explicite |
| ❌ Possible d'instancier Item | ✅ Item non instanciable |

**Exemple d'erreur détectée :**

```python
# Sans abstraction - erreur à l'exécution
class Apple(Item):
    pass  # Oubli de use()

apple = Apple()  # ✅ Fonctionne (problème !)
apple.use(player)  # ❌ AttributeError à l'exécution

# Avec abstraction - erreur à la création
class Apple(Item):
    pass  # Oubli de use()

apple = Apple()  # ❌ TypeError immédiat !
# "Can't instantiate abstract class Apple without use()"
```

**Avantages obtenus :**
1. ✅ **Sécurité** - Impossible d'oublier `use()`
2. ✅ **Documentation** - Le contrat est explicite
3. ✅ **Polymorphisme** - Utilisation générique possible
4. ✅ **Maintenabilité** - Modifications dans `Item` profitent à tous

---

### 4.2 Héritage : Hiérarchie des Objets

#### 4.2.1 Problématique

Les objets du jeu ont des **comportements fondamentalement différents** :
- Certains se consomment (Steps, Keys)
- D'autres restent (Shovel, Hammer)
- D'autres restaurent des ressources (Apple, Cake)

Comment organiser cela proprement ?

#### 4.2.2 Solution : Hiérarchie à 3 Branches

```
Item (abstract) ──┐
                  │
    ┌─────────────┼──────────────┐
    │             │              │
ConsumableItem  PermanentItem   Food
    │             │              │
    ├─ Steps      ├─ Shovel      ├─ Apple (+2)
    ├─ Keys       ├─ Hammer      ├─ Banana (+3)
    ├─ Gems       ├─ LockpickKit ├─ Cake (+10)
    ├─ Coins      ├─ MetalDetect ├─ Sandwich (+15)
    └─ Dice       └─ RabbitFoot  └─ Meal (+25)
```

#### 4.2.3 Justification des 3 Branches

**Pourquoi 3 classes intermédiaires ?**

Chaque branche a un **comportement spécifique** :

**1. ConsumableItem : Gestion de quantité**

```python
class ConsumableItem(Item):
    """Objets avec quantité qui s'épuise."""
    
    def __init__(self, name: str, description: str, quantity: int = 1):
        super().__init__(name, description)
        self.quantity = quantity  # Ajout spécifique
    
    def add(self, amount: int):
        """Comportement spécifique aux consommables."""
        self.quantity += amount
    
    def remove(self, amount: int) -> bool:
        """Comportement spécifique aux consommables."""
        if self.quantity >= amount:
            self.quantity -= amount
            return True
        return False
    
    def use(self, player):
        """Utilisation = décrémentation."""
        return self.remove(1)
```

**2. PermanentItem : Effet passif**

```python
class PermanentItem(Item):
    """Objets qui ne se consomment jamais."""
    
    def __init__(self, name: str, description: str, effect: str = ""):
        super().__init__(name, description)
        self.effect_description = effect
    
    def use(self, player):
        """Les permanents ne se consomment pas."""
        return True  # Toujours disponible
```

**3. Food : Restauration de ressources**

```python
class Food(Item):
    """Nourriture qui restaure des pas."""
    
    def __init__(self, name: str, steps_restored: int):
        description = f"Restores {steps_restored} steps"
        super().__init__(name, description)
        self.steps_restored = steps_restored
    
    def use(self, player):
        """Utilisation = restauration de pas."""
        player.inventory.steps.add(self.steps_restored)
        return True
```

**Pourquoi ne pas tout mettre dans ConsumableItem ?**

```python
# ❌ Solution alternative (tout dans ConsumableItem)
class ConsumableItem(Item):
    def use(self, player):
        if self.name == "Apple":
            player.inventory.steps.add(2)  # Code spécifique
        elif self.name == "Shovel":
            return True  # Code spécifique
        elif self.name == "Keys":
            self.quantity -= 1  # Code spécifique
        # ... 20 autres if/elif !

# Problèmes :
# - Violation du principe Open/Closed
# - Code difficile à maintenir
# - Ajout d'objet = modification de ConsumableItem
```

**✅ Avec 3 branches :**

```python
# ✅ Solution choisie (3 branches)
# Ajout d'un nouvel objet :
class Bread(Food):
    def __init__(self):
        super().__init__("Bread", 5)

# C'est tout ! Aucune modification ailleurs.
# Principe Open/Closed respecté.
```

**Avantages de la hiérarchie :**
1. ✅ **Clarté conceptuelle** - 3 types d'objets bien distincts
2. ✅ **Réutilisation du code** - Pas de duplication entre Steps, Keys, Gems
3. ✅ **Extensibilité** - Nouveau type = nouvelle classe, rien d'autre à modifier
4. ✅ **Maintenance** - Comportement commun centralisé dans les classes mères

---

### 4.3 Polymorphisme : La Méthode `use()`

#### 4.3.1 Problématique

Comment manipuler **tous les objets de la même façon** malgré leurs comportements différents ?

#### 4.3.2 Solution : Polymorphisme

**Même méthode, comportements différents :**

```python
# 1. Steps : Décrémente et vérifie game over
class Steps(ConsumableItem):
    def use(self, player):
        if self.quantity > 0:
            return self.remove(1)
        return False  # Plus de pas = défaite

# 2. Food : Restaure des pas
class Apple(Food):
    def use(self, player):
        player.inventory.steps.add(2)
        print("🍎 Restored 2 steps!")
        return True

# 3. Keys : Décrémente simplement
class Keys(ConsumableItem):
    def use(self, player):
        return self.remove(1)

# 4. PermanentItem : Effet passif
class Shovel(PermanentItem):
    def use(self, player):
        return True  # Ne se consomme pas
```

**Utilisation polymorphique :**

```python
def eat_food(inventory, food_name, player):
    """
    Fonction GÉNÉRIQUE pour manger n'importe quelle nourriture.
    
    Fonctionne pour Apple, Banana, Cake, Sandwich, Meal...
    sans connaître le type exact !
    """
    food_item = inventory.food_items[food_name]['item']
    
    # Appel polymorphique
    success = food_item.use(player)  # ✅ Le bon comportement s'exécute
    
    # Aucun if/elif nécessaire !
    return success

# Utilisation
eat_food(inventory, "apple", player)   # → Restaure 2 pas
eat_food(inventory, "cake", player)    # → Restaure 10 pas
eat_food(inventory, "meal", player)    # → Restaure 25 pas
```

#### 4.3.3 Justification du Choix

**Sans polymorphisme (code procédural) :**

```python
# ❌ Version sans polymorphisme
def eat_food(inventory, food_name, player):
    if food_name == "apple":
        player.inventory.steps.add(2)
    elif food_name == "banana":
        player.inventory.steps.add(3)
    elif food_name == "cake":
        player.inventory.steps.add(10)
    elif food_name == "sandwich":
        player.inventory.steps.add(15)
    elif food_name == "meal":
        player.inventory.steps.add(25)
    # ... ajout d'une nouvelle nourriture = modification ici !

# Problèmes :
# - Violation du principe Open/Closed
# - Code répétitif et fragile
# - Difficile à maintenir
```

**Avec polymorphisme (code POO) :**

```python
# ✅ Version polymorphique
def eat_food(inventory, food_name, player):
    food_item = inventory.food_items[food_name]['item']
    return food_item.use(player)

# Ajout d'une nouvelle nourriture :
class Bread(Food):
    def __init__(self):
        super().__init__("Bread", 5)

# Aucune modification de eat_food() nécessaire !
```

**Avantages du polymorphisme :**
1. ✅ **Code générique** - Même code pour tous les objets
2. ✅ **Extensibilité** - Nouveau type = zéro modification du code appelant
3. ✅ **Lisibilité** - Pas de switch/case géant
4. ✅ **Flexibilité** - Comportement déterminé à l'exécution (late binding)

---

### 4.4 Encapsulation : Interfaces Publiques

#### 4.4.1 Principe

L'encapsulation consiste à **cacher les détails internes** et exposer une **interface publique simple**.

#### 4.4.2 Exemple : Classe Door

```python
class Door:
    """
    Encapsule la complexité du système de portes.
    """
    
    # Constantes publiques (interface)
    UNLOCKED = 0
    LOCKED = 1
    DOUBLE_LOCKED = 2
    
    def __init__(self, lock_level: int = UNLOCKED):
        # Attributs internes
        self.lock_level = lock_level
        self.is_open = False
    
    # ═══════════════════════════════════════════════
    # INTERFACE PUBLIQUE (ce que l'utilisateur voit)
    # ═══════════════════════════════════════════════
    
    def can_open(self, player) -> tuple[bool, str]:
        """
        Interface publique simple.
        
        Cache toute la complexité :
        - Vérification des niveaux
        - Logique du kit de crochetage
        - Gestion des messages
        """
        # Logique complexe encapsulée
        if self.lock_level == Door.UNLOCKED:
            return True, "Porte déverrouillée"
        
        if self.lock_level == Door.LOCKED:
            if player.inventory.has_permanent_item('lockpick_kit'):
                return True, "Kit de crochetage disponible"
            if player.inventory.keys.quantity > 0:
                return True, "Clé disponible"
            return False, "Clé ou kit nécessaire"
        
        if self.lock_level == Door.DOUBLE_LOCKED:
            if player.inventory.keys.quantity > 0:
                return True, "Clé disponible (double verrou)"
            return False, "Clé nécessaire (double verrou)"
        
        return False, "Impossible d'ouvrir"
    
    def open(self, player) -> bool:
        """Interface publique pour ouvrir la porte."""
        can_open, message = self.can_open(player)
        print(message)
        
        if can_open:
            self._consume_key_if_needed(player)  # Méthode privée
            self.is_open = True
        
        return can_open
    
    # ═══════════════════════════════════════════════
    # MÉTHODES PRIVÉES (détails internes)
    # ═══════════════════════════════════════════════
    
    def _consume_key_if_needed(self, player):
        """Méthode privée - détail d'implémentation."""
        if self.lock_level == Door.LOCKED:
            if not player.inventory.has_permanent_item('lockpick_kit'):
                player.inventory.keys.use(player)
        elif self.lock_level == Door.DOUBLE_LOCKED:
            player.inventory.keys.use(player)
```

**Utilisation par le client :**

```python
# Le code client utilise l'interface simple
door = Door(Door.LOCKED)

# Vérification simple
can_open, msg = door.can_open(player)

# Ouverture simple
success = door.open(player)

# Le client n'a PAS besoin de connaître :
# - La logique du kit de crochetage
# - Les différents niveaux
# - La consommation de clés
# Tout est encapsulé !
```

#### 4.4.3 Avantages

1. ✅ **Simplicité d'utilisation** - Interface claire et intuitive
2. ✅ **Flexibilité interne** - Peut changer l'implémentation sans casser le code client
3. ✅ **Robustesse** - Évite les manipulations incorrectes
4. ✅ **Maintenance** - Modifications localisées dans la classe

---

### 4.5 Composition vs Agrégation

#### 4.5.1 Définitions

| Relation | Symbole | Signification | Durée de vie |
|----------|---------|---------------|--------------|
| **Composition** | ◆──● | "fait partie de" | Dépendante du propriétaire |
| **Agrégation** | ◇──○ | "contient" | Indépendante du propriétaire |

#### 4.5.2 Composition : Player ◆──● Inventory

**Relation forte - L'inventaire n'existe pas sans le joueur**

```python
class Player:
    """
    COMPOSITION : Player POSSÈDE un Inventory.
    
    Relation existentielle forte :
    - L'inventaire est créé DANS Player
    - Il n'existe PAS sans Player
    - Destruction de Player → destruction de Inventory
    """
    
    def __init__(self, start_position: tuple):
        # Création directe de l'inventaire
        self.inventory = Inventory()  # ◆ Composition
        self.position = start_position
```

**Caractéristiques :**
- ◆ Création dans le constructeur
- ◆ Propriété exclusive (un inventaire = un joueur)
- ◆ Durées de vie liées
- ◆ Relation "fait partie de"

**Pourquoi la composition ici ?**

```python
# ❌ Alternative avec agrégation
inventory = Inventory()  # Créé séparément
player = Player(inventory)  # Passé en paramètre

# Problèmes :
# - Un inventaire sans joueur n'a pas de sens
# - Qui est responsable de créer l'inventaire ?
# - Risque : plusieurs joueurs partageant un inventaire

# ✅ Composition (solution choisie)
player = Player()
# → L'inventaire est automatiquement créé
# → Relation logique et sûre
```

#### 4.5.3 Agrégation : Manor ◇──○ Room

**Relation faible - Les pièces existent indépendamment**

```python
class Manor:
    """
    AGRÉGATION : Manor CONTIENT des Room.
    
    Relation faible :
    - Les pièces existent AVANT d'être placées
    - Elles sont créées dans un catalogue séparé
    - Destruction du Manor → les pièces existent toujours
    """
    
    def __init__(self):
        # Grille vide initialement
        self.grid = [[None for _ in range(9)] for _ in range(5)]
    
    def place_room(self, room: Room, position: tuple):
        """
        Place une pièce EXISTANTE dans la grille.
        
        La pièce a été créée ailleurs (catalogue).
        Le manor ne fait que la RÉFÉRENCER.
        """
        row, col = position
        self.grid[row][col] = room  # ◇ Agrégation (référence)

# Les pièces existent indépendamment
room_catalog = create_room_catalog()  # 25+ pièces créées

# Puis placées dans le manoir
manor = Manor()
manor.place_room(room_catalog[0], (4, 4))  # Simple référence
```

**Caractéristiques :**
- ◇ Création séparée du conteneur
- ◇ Existence indépendante
- ◇ Partage possible (une pièce dans plusieurs endroits)
- ◇ Relation "contient"

**Pourquoi l'agrégation ici ?**

```python
# Les pièces ont une existence propre
catalog = [
    Room("Library", ...),
    Room("Kitchen", ...),
    Room("Bedroom", ...),
    # ...
]

# Le manoir les utilise mais ne les crée pas
manor.place_room(catalog[5], (2, 3))

# Avantages :
# ✅ Catalogue réutilisable
# ✅ Tirage aléatoire facile
# ✅ Les pièces existent même sans manoir
# ✅ Flexibilité maximale
```

#### 4.5.4 Tableau Récapitulatif

| Aspect | Composition (Player-Inventory) | Agrégation (Manor-Room) |
|--------|-------------------------------|------------------------|
| **Création** | Dans le constructeur | Séparément |
| **Propriété** | Exclusive | Partageable |
| **Durée de vie** | Liée au parent | Indépendante |
| **Relation** | "fait partie de" | "contient" |
| **Exemple réel** | Cœur dans un corps | Livre dans une bibliothèque |

---

## 5. Patterns de Conception

### 5.1 Manager Pattern

#### 5.1.1 Problématique

Comment **centraliser la logique métier** sans surcharger les classes du modèle ?

#### 5.1.2 Solution : Classes Manager

**RandomManager : Centralise l'aléatoire**

```python
class RandomManager:
    """
    MANAGER PATTERN
    
    Centralise TOUTE la génération aléatoire du jeu.
    
    Avantages :
    - Un seul endroit pour l'équilibrage
    - Facilite les tests (mocker le manager)
    - Évite la duplication de code aléatoire
    """
    
    def __init__(self):
        self.color_modifiers = {
            'green': 1.0,
            'red': 1.0,
            # ...
        }
    
    def draw_rooms(self, available_rooms: list, count: int = 3) -> list:
        """
        Tire des pièces avec pondération par rareté.
        
        Probabilité = 1 / (3^rareté) * modificateur_couleur
        """
        weights = []
        for room in available_rooms:
            base_weight = room.get_probability_weight()  # 1 / 3^rarity
            color_mod = self.color_modifiers.get(room.color.value, 1.0)
            weights.append(base_weight * color_mod)
        
        return random.choices(available_rooms, weights=weights, k=count)
    
    @staticmethod
    def get_door_lock_level(row: int, max_rows: int) -> int:
        """
        Génère le niveau de porte selon la position.
        
        Plus on monte, plus les portes sont verrouillées.
        """
        if row == max_rows - 1:
            return Door.UNLOCKED  # Première rangée : toujours ouvert
        
        if row == 0:
            return Door.DOUBLE_LOCKED  # Dernière rangée : toujours double verrou
        
        # Rangées intermédiaires : progression
        progress = (max_rows - row) / max_rows
        rand = random.random()
        
        if rand < progress * 0.3:
            return Door.DOUBLE_LOCKED
        elif rand < progress * 0.6:
            return Door.LOCKED
        else:
            return Door.UNLOCKED
    
    @staticmethod
    def get_random_loot(loot_type: str = "chest") -> dict:
        """Tables de butin aléatoire."""
        loot_tables = {
            "chest": [
                {"coins": 20, "keys": 1},
                {"coins": 30, "gems": 1},
                {"coins": 15, "keys": 2},
                {"coins": 40},
                {"keys": 3},
                {},  # Coffre vide possible
            ],
            "digging": [
                {"coins": 15},
                {"keys": 1},
                {"gems": 1},
                {},
            ]
        }
        
        table = loot_tables.get(loot_type, loot_tables["chest"])
        return random.choice(table)
```

**InteractionManager : Centralise les interactions**

```python
class InteractionManager:
    """
    Gère toutes les interactions avec les objets du jeu.
    
    Évite de surcharger Player avec de la logique métier.
    """
    
    def __init__(self, player: Player, manor: Manor):
        self.player = player
        self.manor = manor
    
    def interact_with_item(self, item_type: str, params: dict):
        """Point d'entrée unique pour les interactions."""
        if item_type == 'chest':
            self._handle_chest_interaction()
        elif item_type == 'digging':
            self._handle_digging_interaction()
        elif item_type == 'food':
            self._handle_food_interaction(params['type'])
        # ...
    
    def _handle_chest_interaction(self):
        """Logique d'ouverture de coffre."""
        if self.player.inventory.has_permanent_item('hammer'):
            print("🔨 Used hammer to open chest!")
        elif self.player.inventory.keys.quantity > 0:
            self.player.inventory.keys.use(self.player)
            print("🔑 Used key to open chest!")
        else:
            print("❌ Need key or hammer!")
            return
        
        # Génération du butin
        loot = RandomManager.get_random_loot('chest')
        for item_type, quantity in loot.items():
            self.player.inventory.add_item(item_type, quantity)
            print(f"📦 Found {quantity} {item_type}!")
```

#### 5.1.3 Justification

**Pourquoi utiliser le pattern Manager ?**

**Sans Manager (logique dans les entités) :**

```python
# ❌ Logique dispersée
class Player:
    def open_chest(self):
        # Logique d'ouverture
        # Génération du butin
        # ...  
        # Player devient trop gros !

class Room:
    def generate_loot(self):
        # Code aléatoire ici
        # Duplication avec Player !
```

**Avec Manager (logique centralisée) :**

```python
# ✅ Logique centralisée
class InteractionManager:
    def _handle_chest_interaction(self):
        # TOUTE la logique ici
        # Un seul endroit à modifier

# Player reste simple
class Player:
    def __init__(self):
        self.inventory = Inventory()
        self.position = (4, 4)
        # Pas de logique métier !
```

**Avantages :**
1. ✅ **Centralisation** - Logique regroupée
2. ✅ **Testabilité** - Facile de mocker les managers
3. ✅ **Maintenabilité** - Un seul endroit à modifier
4. ✅ **Réutilisabilité** - Managers partagés

---

### 5.2 Template Method Pattern

#### 5.2.1 Principe

Définir le **squelette d'un algorithme** dans une classe mère, en déléguant certaines étapes aux sous-classes.

#### 5.2.2 Implémentation : Classe Item

```python
class Item(ABC):
    """
    TEMPLATE METHOD PATTERN
    
    Définit la STRUCTURE commune à tous les objets :
    1. Initialisation (template)
    2. Utilisation (à définir par les sous-classes)
    3. Représentation (template)
    """
    
    def __init__(self, name: str, description: str):
        # Étape 1 : Initialisation commune (template)
        self.name = name
        self.description = description
    
    @abstractmethod
    def use(self, player):
        # Étape 2 : Comportement spécifique (à définir)
        pass
    
    def __str__(self):
        # Étape 3 : Représentation commune (template)
        return f"{self.name}: {self.description}"

# Les sous-classes "remplissent le trou" (use)
class Food(Item):
    def use(self, player):
        # Implémentation spécifique
        player.inventory.steps.add(self.steps_restored)
        return True
```

#### 5.2.3 Avantages

1. ✅ **Réutilisation** - Comportements communs dans la classe mère
2. ✅ **Consistance** - Structure uniforme garantie
3. ✅ **Extension** - Facile d'ajouter de nouveaux types
4. ✅ **Maintenance** - Modifications du template profitent à tous

---

### 5.3 MVC (Model-View-Controller)

#### 5.3.1 Architecture

```
CONTRÔLEUR (BluePrinceGame)
    │
    ├──> MODÈLE (models/ + managers/)
    │    • Données pures (aucun Pygame)
    │    • Logique métier
    │
    └──> VUE (renderers/)
         • Affichage Pygame
         • Aucune logique métier
```

#### 5.3.2 Séparation Claire

**MODÈLE - Logique pure :**

```python
# models/player.py
# Aucun import Pygame !

class Player:
    def move(self, new_position: tuple, manor) -> bool:
        """Logique de déplacement - indépendante de l'affichage."""
        if self.inventory.steps.quantity <= 0:
            return False
        
        self.inventory.steps.use(self)
        self.position = new_position
        
        room = manor.get_room(new_position)
        if room:
            room.enter(self)
        
        return True
```

**VUE - Affichage pur :**

```python
# renderers/grid_renderer.py
# Aucune logique métier !

class GridRenderer:
    def render_grid(self, manor: Manor, player: Player):
        """Affiche la grille - ne modifie JAMAIS les données."""
        for row in range(manor.height):
            for col in range(manor.width):
                position = (row, col)
                room = manor.get_room(position)
                
                # Affichage basé sur les données
                self._render_cell(room, position, player.position)
```

**CONTRÔLEUR - Coordination :**

```python
# main.py

class BluePrinceGame:
    def _handle_keypress(self, key):
        """Coordonne Modèle et Vue."""
        if key == pygame.K_z:  # Nord
            new_pos = (
                self.player.position[0] - 1,
                self.player.position[1]
            )
            
            # 1. Appel au MODÈLE
            success = self.player.move(new_pos, self.manor)
            
            # 2. La VUE sera mise à jour dans render()
```

#### 5.3.3 Avantages

1. ✅ **Testabilité** - Le modèle peut être testé sans Pygame
2. ✅ **Flexibilité** - Changement de Vue possible (terminal, web...)
3. ✅ **Maintenance** - Modifications isolées par responsabilité
4. ✅ **Réutilisabilité** - Le modèle est indépendant

---

## 6. Décisions d'Implémentation

### 6.1 Choix de Pygame

#### 6.1.1 Alternatives Considérées

| Option | Avantages | Inconvénients | Choix |
|--------|-----------|---------------|-------|
| **Terminal** | Simple, rapide | Limité visuellement | ❌ |
| **Tkinter** | Standard Python | Moins adapté pour jeux | ❌ |
| **Pygame** | Parfait pour jeux 2D | Dépendance externe | ✅ |
| **Kivy** | Moderne, mobile | Complexe, overkill | ❌ |

#### 6.1.2 Justification

**Pygame choisi car :**
1. ✅ **API simple** - Facile à apprendre
2. ✅ **Performance suffisante** - Pour un jeu 2D
3. ✅ **Bien documenté** - Beaucoup de ressources
4. ✅ **Équilibre** - Complexité / Résultats

---

### 6.2 Structure de Données pour la Grille

#### 6.2.1 Options Considérées

```python
# Option 1 : Liste 2D (choisie) ✅
grid = [[None for _ in range(9)] for _ in range(5)]
access = grid[row][col]

# Option 2 : Dictionnaire
grid = {}
access = grid.get((row, col))

# Option 3 : Liste 1D
grid = [None] * 45
access = grid[row * 9 + col]
```

#### 6.2.2 Justification du Choix

**Liste 2D choisie car :**
1. ✅ **Accès naturel** - `grid[row][col]` intuitif
2. ✅ **Itération facile** - Boucles for imbriquées
3. ✅ **Visuel** - Structure proche du rendu
4. ✅ **Performance** - O(1) pour l'accès
5. ✅ **Mémoire** - Acceptable pour 5×9

---

### 6.3 Gestion de l'Aléatoire

#### 6.3.1 Centralisation

**Pourquoi RandomManager ?**

```python
# ❌ SANS centralisation
class Room:
    def generate_loot(self):
        return random.choice([...])  # Dispersé

class Door:
    def __init__(self):
        self.level = random.randint(0, 2)  # Dispersé

# Problèmes :
# - Difficile à tester (non reproductible)
# - Équilibrage fragmenté
# - Impossible de fixer une seed globale

# ✅ AVEC centralisation
class RandomManager:
    def __init__(self, seed=None):
        if seed:
            random.seed(seed)  # Reproductible !
    
    def get_loot(self):
        return random.choice([...])
    
    def get_door_level(self, row):
        return self._calculate_level(row)

# Avantages :
# - Tests reproductibles
# - Équilibrage centralisé
# - Debug facile avec seed
```

---

## 7. Système d'Aléatoire

### 7.1 Probabilités Pondérées

#### 7.1.1 Formule

Pour chaque pièce :

```
Probabilité = (1 / 3^rareté) × modificateur_couleur
```

| Rareté | Poids de base | Exemple |
|--------|---------------|---------|
| 0 (Commun) | 1.0 | Library, Kitchen |
| 1 (Peu commun) | 0.33 | Bedroom, Workshop |
| 2 (Rare) | 0.11 | Treasury, Gallery |
| 3 (Très rare) | 0.037 | Vault, Secret Room |

#### 7.1.2 Implémentation

```python
def draw_rooms(self, available_rooms: list, count: int) -> list:
    """Tire avec pondération."""
    weights = [
        room.get_probability_weight() * self.color_modifiers.get(room.color.value, 1.0)
        for room in available_rooms
    ]
    
    drawn = random.choices(available_rooms, weights=weights, k=count)
    
    # Garantie : au moins une pièce à 0 gemmes
    if not any(room.gem_cost == 0 for room in drawn):
        free_rooms = [r for r in available_rooms if r.gem_cost == 0]
        if free_rooms:
            drawn[0] = random.choice(free_rooms)
    
    return drawn
```

### 7.2 Génération Progressive des Portes

```
Rangée 0 (haut) :    100% Double Verrou
Rangée 1 :           60% Double, 30% Simple, 10% Ouvert
Rangée 2 :           30% Double, 40% Simple, 30% Ouvert
Rangée 3 :           10% Double, 30% Simple, 60% Ouvert
Rangée 4 (bas) :     100% Ouvert
```

**Implémentation :**

```python
@staticmethod
def get_door_lock_level(row: int, max_rows: int) -> int:
    """Difficulté progressive."""
    if row == max_rows - 1:
        return Door.UNLOCKED
    
    if row == 0:
        return Door.DOUBLE_LOCKED
    
    progress = (max_rows - row) / max_rows
    rand = random.random()
    
    if rand < progress * 0.3:
        return Door.DOUBLE_LOCKED
    elif rand < progress * 0.6:
        return Door.LOCKED
    else:
        return Door.UNLOCKED
```

---

## 8. Difficultés Rencontrées

### 8.1 Organisation Initiale du Code

#### 8.1.1 Problème

Au début, tous les fichiers étaient à la racine :

```
blue-prince/
├── item.py
├── inventory.py
├── door.py
├── room.py
├── player.py
├── manor.py
├── random_manager.py
├── grid_renderer.py
├── main.py
└── ...  (15+ fichiers)
```

**Conséquences :**
- Difficile de s'y retrouver
- Imports confus
- Pas de séparation claire des responsabilités

#### 8.1.2 Solution

Réorganisation en packages :

```
blue-prince/
├── models/
│   ├── item.py
│   ├── inventory.py
│   └── ...
├── managers/
│   └── random_manager.py
├── renderers/
│   └── grid_renderer.py
└── main.py
```

**Bénéfices :**
- Structure claire
- Responsabilités séparées
- Navigation facilitée

---

### 8.2 Équilibrage de l'Aléatoire

#### 8.2.1 Problème

Première version : tirage uniforme

```python
# ❌ Problème
drawn = random.sample(available_rooms, 3)

# Résultat : Pièces rares trop fréquentes
# Le jeu devient trop facile
```

#### 8.2.2 Solution

Probabilités pondérées par rareté :

```python
# ✅ Solution
weights = [room.get_probability_weight() for room in available_rooms]
drawn = random.choices(available_rooms, weights=weights, k=3)

# Résultat : Équilibre respecté
# Pièces rares vraiment rares
```

---

### 8.3 Gestion des Effets de Pièces

#### 8.3.1 Problème

Comment appliquer les effets sans créer de couplage fort ?

```python
# ❌ Couplage fort
class Room:
    def enter(self, player):
        if self.name == "Treasury":
            player.inventory.add_item("coins", 50)
            # Couplage : Room connaît Inventory !
```

#### 8.3.2 Solution

Fonctions callback :

```python
# ✅ Découplage
def treasury_effect(player, room):
    """Fonction séparée."""
    player.inventory.add_item("coins", 50)

room = Room(
    "Treasury",
    on_enter_effect=treasury_effect  # Callback
)

# Usage
room.enter(player)  # Appelle le callback
```

**Avantages :**
- Découplage
- Flexibilité
- Testabilité

---

## 9. Tests et Validation

### 9.1 Tests Manuels

Le jeu a été testé manuellement pour vérifier :

**Fonctionnalités principales :**
- ✅ Déplacement dans toutes les directions
- ✅ Ouverture de portes (tous niveaux)
- ✅ Tirage et sélection de pièces
- ✅ Collecte d'objets
- ✅ Utilisation de nourriture
- ✅ Kit de crochetage
- ✅ Conditions de victoire
- ✅ Conditions de défaite

**Cas limites :**
- ✅ Déplacement hors grille (bloqué)
- ✅ Portes sans clé (bloqué)
- ✅ Pièces sans gemmes (bloqué)
- ✅ Épuisement des pas (défaite)

### 9.2 Tests Unitaires Possibles

```python
# Exemples de tests à implémenter

def test_inventory_add_items():
    """Test ajout d'objets."""
    inv = Inventory()
    inv.add_item("keys", 5)
    assert inv.keys.quantity == 5

def test_door_lock_levels():
    """Test ouverture de portes."""
    player = Player((4, 4))
    
    # Porte déverrouillée
    door_unlocked = Door(Door.UNLOCKED)
    can_open, _ = door_unlocked.can_open(player)
    assert can_open == True
    
    # Porte verrouillée sans clé
    door_locked = Door(Door.LOCKED)
    can_open, _ = door_locked.can_open(player)
    assert can_open == False
    
    # Avec clé
    player.inventory.add_item("keys", 1)
    can_open, _ = door_locked.can_open(player)
    assert can_open == True

def test_food_restores_steps():
    """Test restauration de pas."""
    player = Player((4, 4))
    initial_steps = player.inventory.steps.quantity
    
    apple = Apple()
    apple.use(player)
    
    assert player.inventory.steps.quantity == initial_steps + 2
```

---

## 10. Perspectives d'Amélioration

### 10.1 Améliorations Techniques

#### Système de Sauvegarde

```python
class SaveManager:
    """Gestion de la sauvegarde du jeu."""
    
    def save_game(self, game_state: dict, filename: str):
        """Sauvegarde au format JSON."""
        with open(filename, 'w') as f:
            json.dump(game_state, f, indent=2)
    
    def load_game(self, filename: str) -> dict:
        """Charge une sauvegarde."""
        with open(filename, 'r') as f:
            return json.load(f)
```

#### Tests Automatisés

```python
# Structure proposée
tests/
├── test_item.py
├── test_inventory.py
├── test_door.py
├── test_room.py
├── test_player.py
└── test_random_manager.py
```

#### Logging

```python
import logging

# Au lieu de print()
logger = logging.getLogger(__name__)
logger.info("Game started")
logger.warning("Low on steps!")
logger.error("Invalid move")
```

### 10.2 Nouvelles Fonctionnalités

1. **Niveaux de difficulté**
   - Facile : 100 pas initiaux
   - Normal : 70 pas
   - Difficile : 50 pas

2. **Achievements/Succès**
   - Finir sans utiliser de clés
   - Finir avec plus de 30 pas
   - Collecter tous les objets permanents

3. **Modes de jeu**
   - Mode histoire (tutorial)
   - Mode infini (grille illimitée)
   - Mode speedrun (chronomètre)

4. **Multijoueur local**
   - Tour par tour
   - Grille partagée

---

## 11. Conclusion

### 11.1 Objectifs Atteints

Ce projet a permis de mettre en pratique l'ensemble des concepts de la Programmation Orientée Objet :

✅ **Abstraction** - Classe abstraite `Item` définissant un contrat clair  
✅ **Héritage** - Hiérarchie à 3 niveaux parfaitement justifiée  
✅ **Polymorphisme** - Méthode `use()` pour extensibilité maximale  
✅ **Encapsulation** - Interfaces publiques simples, détails cachés  
✅ **Composition/Agrégation** - Relations appropriées selon le contexte

### 11.2 Compétences Développées

**Techniques :**
- Architecture logicielle structurée (MVC)
- Patterns de conception (Manager, Template Method)
- Gestion de projet (Git, organisation en packages)
- Interface graphique avec Pygame

**Conceptuelles :**
- Analyse et modélisation objet
- Choix architecturaux justifiés
- Équilibrage de gameplay
- Documentation technique

### 11.3 Bilan Personnel

Ce projet m'a permis de :

1. **Comprendre l'importance de l'architecture** - Une bonne organisation initiale facilite tout le développement

2. **Maîtriser les concepts POO** - Au-delà de la théorie, application concrète et réfléchie

3. **Développer ma rigueur** - Documentation, tests, commits réguliers

4. **Résoudre des problèmes complexes** - Équilibrage, aléatoire, effets de pièces

### 11.4 Remerciements

Je tiens à remercier :
- **Le professeur** pour l'encadrement et les conseils
- **La communauté Pygame** pour la documentation
- **Les créateurs de Blue Prince** pour l'inspiration

---

## Annexes

### Annexe A : Statistiques du Projet

| Métrique | Valeur |
|----------|--------|
| **Lignes de code** | ~3500 |
| **Nombre de classes** | 35+ |
| **Nombre de fichiers** | 15 |
| **Packages** | 4 |
| **Commits Git** | 30+ |
| **Pièces implémentées** | 25+ |
| **Objets différents** | 20+ |

### Annexe B : Diagramme UML

Le diagramme de classes complet est disponible dans le fichier `class_diagram.puml`.

**Visualisation en ligne :**
http://www.plantuml.com/plantuml/uml/

### Annexe C : Références

**Documentation :**
- [Python Official Docs](https://docs.python.org/3/)
- [Pygame Documentation](https://www.pygame.org/docs/)
- [Design Patterns](https://refactoring.guru/design-patterns)

**Ressources POO :**
- [SOLID Principles](https://en.wikipedia.org/wiki/SOLID)
- [UML Class Diagrams](https://www.uml-diagrams.org/)
- [MVC Pattern](https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller)

**Jeu original :**
- [Blue Prince Wiki](https://blue-prince.fandom.com/wiki/Room_Directory)

---

<div align="center">

**📄 Rapport de Conception - Projet Blue Prince**

*Master 1 Systèmes Communicants*  
*Sorbonne Université - 2025/2026*

**Auteur :** CHABANE CHAOUCHE Mohand  
**Date :** Novembre 2025

---

*"L'architecture est l'art de donner au code une structure  
qui facilite sa compréhension, sa maintenance et son évolution."*

</div>