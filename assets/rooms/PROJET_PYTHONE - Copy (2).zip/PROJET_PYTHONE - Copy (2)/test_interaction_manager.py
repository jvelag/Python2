"""
Tests unitaires pour le InteractionManager.
Auteur: Moss
Date: Novembre 2025

Version corrigée des tests.
"""

import unittest
from unittest.mock import Mock, patch
import sys
import os

# Ajouter le chemin des modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from managers.interaction_manager import InteractionManager, parse_item_key


class TestInteractionManager(unittest.TestCase):
    """Tests pour le InteractionManager."""
    
    def setUp(self):
        """Configure l'environnement de test avant chaque test."""
        # Mock du joueur
        self.mock_player = Mock()
        self.mock_player.position = (2, 2)
        
        # Mock de l'inventaire
        self.mock_inventory = Mock()
        self.mock_player.inventory = self.mock_inventory
        
        # Mock du manoir
        self.mock_manor = Mock()
        self.mock_room = Mock()
        self.mock_room.name = "Test Room"
        self.mock_room.items = ['chest', 'food_apple', 'digging']
        self.mock_manor.get_room.return_value = self.mock_room
        
        # Initialisation du gestionnaire
        self.interaction_manager = InteractionManager(self.mock_player, self.mock_manor)
        
        # Configuration des mocks de base
        self.mock_inventory.steps = Mock()
        self.mock_inventory.steps.add = Mock()
        self.mock_inventory.keys = Mock()
        self.mock_inventory.keys.quantity = 3
        self.mock_inventory.keys.use = Mock()
        self.mock_inventory.add_item = Mock()
        self.mock_inventory.add_permanent_item = Mock(return_value=True)
        self.mock_inventory.has_item = Mock(return_value=False)
    
    def test_initialization(self):
        """Test l'initialisation du InteractionManager."""
        self.assertEqual(self.interaction_manager.player, self.mock_player)
        self.assertEqual(self.interaction_manager.manor, self.mock_manor)
        self.assertIsNotNone(self.interaction_manager.chest_loot_table)
        self.assertIsNotNone(self.interaction_manager.dig_loot_table)
    
    # ========================================================================
    # TESTS DE LA NOURRITURE - CORRIGÉ
    # ========================================================================
    
    def test_eat_food_apple(self):
        """Test manger une pomme."""
        # CORRECTION: Utiliser patch sur le message_callback du gestionnaire
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item('food', {'type': 'apple'})
            
            # Vérifications
            self.assertTrue(result)
            self.mock_inventory.steps.add.assert_called_once_with(2)
            # Vérifier qu'un message a été envoyé
            mock_callback.assert_called()
    
    def test_eat_food_banana(self):
        """Test manger une banane."""
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item('food', {'type': 'banana'})
            
            self.assertTrue(result)
            self.mock_inventory.steps.add.assert_called_once_with(3)
    
    def test_eat_food_cake(self):
        """Test manger un gâteau."""
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item('food', {'type': 'cake'})
            
            self.assertTrue(result)
            self.mock_inventory.steps.add.assert_called_once_with(10)
    
    def test_eat_food_unknown(self):
        """Test manger un aliment inconnu (valeur par défaut)."""
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item('food', {'type': 'unknown_food'})
            
            self.assertTrue(result)
            self.mock_inventory.steps.add.assert_called_once_with(2)  # Valeur par défaut
    
    # ========================================================================
    # TESTS DES COFFRES - CORRIGÉ
    # ========================================================================
    
    def test_open_chest_with_key(self):
        """Test ouvrir un coffre avec une clé."""
        self.mock_inventory.has_item.return_value = False  # Pas de marteau
        self.mock_inventory.keys.quantity = 1
        
        # CORRECTION: Simuler le butin directement dans la méthode
        with patch.object(self.interaction_manager, '_give_chest_loot') as mock_give_loot:
            result = self.interaction_manager.interact_with_item('chest', {})
            
            self.assertTrue(result)
            self.mock_inventory.keys.use.assert_called_once_with(self.mock_player)
            mock_give_loot.assert_called_once()
    
    def test_open_chest_with_hammer(self):
        """Test ouvrir un coffre avec un marteau."""
        self.mock_inventory.has_item.return_value = True  # A un marteau
        
        with patch.object(self.interaction_manager, '_give_chest_loot') as mock_give_loot:
            result = self.interaction_manager.interact_with_item('chest', {})
            
            self.assertTrue(result)
            # Ne doit pas utiliser de clé
            self.mock_inventory.keys.use.assert_not_called()
            mock_give_loot.assert_called_once()
    
    def test_open_chest_no_tools(self):
        """Test ouvrir un coffre sans outils."""
        self.mock_inventory.has_item.return_value = False  # Pas de marteau
        self.mock_inventory.keys.quantity = 0  # Pas de clés
        
        with patch.object(self.interaction_manager, '_give_chest_loot') as mock_give_loot:
            result = self.interaction_manager.interact_with_item('chest', {})
            
            self.assertFalse(result)
            mock_give_loot.assert_not_called()
    
    def test_give_chest_loot_basic(self):
        """Test la distribution du butin d'un coffre."""
        # CORRECTION: Utiliser le callback du gestionnaire
        with patch('random.choice') as mock_choice, \
             patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            
            # Simuler un butin spécifique
            mock_choice.return_value = {'coins': 20, 'keys': 1}
            
            self.interaction_manager._give_chest_loot()
            
            # Vérifier que les objets sont ajoutés
            self.mock_inventory.add_item.assert_any_call('coins', 20)
            self.mock_inventory.add_item.assert_any_call('keys', 1)
            # Vérifier que des messages ont été envoyés
            self.assertTrue(mock_callback.call_count >= 2)
    
    def test_give_chest_loot_empty(self):
        """Test un coffre vide."""
        with patch('random.choice') as mock_choice, \
             patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            
            mock_choice.return_value = {}  # Coffre vide
            
            self.interaction_manager._give_chest_loot()
            
            # Ne doit pas appeler add_item
            self.mock_inventory.add_item.assert_not_called()
            # Mais doit envoyer un message
            mock_callback.assert_called()
    
    # ========================================================================
    # TESTS DU CREUSAGE - CORRIGÉ
    # ========================================================================
    
    def test_dig_with_shovel(self):
        """Test creuser avec une pelle."""
        self.mock_inventory.has_item.return_value = True  # A une pelle
        
        # CORRECTION: La méthode s'appelle _dig_spot, pas _give_dig_loot
        with patch.object(self.interaction_manager, '_dig_spot') as mock_dig:
            mock_dig.return_value = True
            result = self.interaction_manager.interact_with_item('digging', {})
            
            self.assertTrue(result)
            # La méthode _dig_spot est appelée directement par interact_with_item
    
    def test_dig_without_shovel(self):
        """Test creuser sans pelle."""
        self.mock_inventory.has_item.return_value = False  # Pas de pelle
        
        result = self.interaction_manager.interact_with_item('digging', {})
        
        self.assertFalse(result)
    
    def test_give_dig_loot_success(self):
        """Test la distribution du butin du creusage."""
        # CORRECTION: Cette méthode n'existe pas, c'est _dig_spot qui gère tout
        # On teste directement _dig_spot
        self.mock_inventory.has_item.return_value = True  # A une pelle
        
        with patch('random.choice') as mock_choice, \
             patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            
            mock_choice.return_value = {'coins': 15}
            
            result = self.interaction_manager._dig_spot({})
            
            self.assertTrue(result)
            self.mock_inventory.add_item.assert_called_once_with('coins', 15)
    
    # ========================================================================
    # TESTS DES CASIERS - CORRIGÉ
    # ========================================================================
    
    def test_open_locker_in_locker_room(self):
        """Test ouvrir un casier dans le vestiaire."""
        self.mock_room.name = "Locker Room"
        self.mock_inventory.keys.quantity = 1
        
        # CORRECTION: Simuler le butin directement
        with patch.object(self.interaction_manager, '_open_locker') as mock_open_locker:
            mock_open_locker.return_value = True
            result = self.interaction_manager.interact_with_item('locker', {})
            
            self.assertTrue(result)
    
    def test_open_locker_wrong_room(self):
        """Test ouvrir un casier en dehors du vestiaire."""
        self.mock_room.name = "Wrong Room"  # Pas le vestiaire
        self.mock_inventory.keys.quantity = 1
        
        result = self.interaction_manager.interact_with_item('locker', {})
        
        self.assertFalse(result)
        self.mock_inventory.keys.use.assert_not_called()
    
    def test_open_locker_no_key(self):
        """Test ouvrir un casier sans clé."""
        self.mock_room.name = "Locker Room"
        self.mock_inventory.keys.quantity = 0  # Pas de clés
        
        result = self.interaction_manager.interact_with_item('locker', {})
        
        self.assertFalse(result)
    
    # ========================================================================
    # TESTS DES OBJETS CONSOMMABLES
    # ========================================================================
    
    def test_pickup_consumable_coins(self):
        """Test ramasser des pièces."""
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item(
                'consumable', {'type': 'coins', 'quantity': 10}
            )
            
            self.assertTrue(result)
            self.mock_inventory.add_item.assert_called_once_with('coins', 10)
    
    def test_pickup_consumable_keys(self):
        """Test ramasser des clés."""
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item(
                'consumable', {'type': 'keys', 'quantity': 3}
            )
            
            self.assertTrue(result)
            self.mock_inventory.add_item.assert_called_once_with('keys', 3)
    
    # ========================================================================
    # TESTS DES OBJETS PERMANENTS
    # ========================================================================
    
    def test_pickup_permanent_shovel(self):
        """Test ramasser une pelle."""
        self.mock_inventory.add_permanent_item.return_value = True
        
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item(
                'permanent', {'type': 'shovel'}
            )
            
            self.assertTrue(result)
            self.mock_inventory.add_permanent_item.assert_called_once_with('shovel')
    
    def test_pickup_permanent_hammer(self):
        """Test ramasser un marteau."""
        self.mock_inventory.add_permanent_item.return_value = True
        
        result = self.interaction_manager.interact_with_item(
            'permanent', {'type': 'hammer'}
        )
        
        self.assertTrue(result)
        self.mock_inventory.add_permanent_item.assert_called_once_with('hammer')
    
    # ========================================================================
    # TESTS DES MÉTHODES UTILITAIRES - CORRIGÉ
    # ========================================================================
    
    def test_unknown_interaction_type(self):
        """Test interaction avec un type inconnu."""
        # CORRECTION: Utiliser le callback du gestionnaire
        with patch.object(self.interaction_manager, 'message_callback') as mock_callback:
            result = self.interaction_manager.interact_with_item('unknown_type', {})
            
            self.assertFalse(result)
            mock_callback.assert_called_once()
    
    def test_get_current_room(self):
        """Test la récupération de la pièce actuelle."""
        room = self.interaction_manager.get_current_room()
        self.assertEqual(room, self.mock_room)
        self.mock_manor.get_room.assert_called_with(self.mock_player.position)
    
    def test_get_available_interactions(self):
        """Test la récupération des interactions disponibles."""
        # Configurer les prérequis
        self.mock_inventory.has_item.side_effect = lambda item: True
        self.mock_room.name = "Locker Room"
        self.mock_inventory.keys.quantity = 1
        
        interactions = self.interaction_manager.get_available_interactions()
        
        # Doit retourner tous les objets de la pièce
        expected_interactions = ['chest', 'food_apple', 'digging']
        self.assertEqual(interactions, expected_interactions)
    
    def test_can_interact_with_object(self):
        """Test la vérification des prérequis d'interaction."""
        # Test avec un coffre (nécessite clé ou marteau)
        self.mock_inventory.has_item.return_value = False
        self.mock_inventory.keys.quantity = 0
        
        can_interact = self.interaction_manager.can_interact_with_object('chest')
        self.assertFalse(can_interact)
        
        # Test avec nourriture (toujours possible)
        can_interact = self.interaction_manager.can_interact_with_object('food_apple')
        self.assertTrue(can_interact)
    
    def test_interact_with_item_key(self):
        """Test l'interaction avec une clé d'objet."""
        with patch.object(self.interaction_manager, 'interact_with_item') as mock_interact:
            self.interaction_manager.interact_with_item_key('food_apple')
            
            mock_interact.assert_called_once_with('food', {'type': 'apple'})
    
    # ========================================================================
    # TESTS DES FONCTIONS UTILITAIRES
    # ========================================================================
    
    def test_parse_item_key_food(self):
        """Test le parsing des clés de nourriture."""
        item_type, item_data = parse_item_key('food_apple')
        self.assertEqual(item_type, 'food')
        self.assertEqual(item_data, {'type': 'apple'})
    
    def test_parse_item_key_permanent(self):
        """Test le parsing des clés d'objets permanents."""
        item_type, item_data = parse_item_key('permanent_shovel')
        self.assertEqual(item_type, 'permanent')
        self.assertEqual(item_data, {'type': 'shovel'})
    
    def test_parse_item_key_chest(self):
        """Test le parsing des coffres."""
        item_type, item_data = parse_item_key('chest')
        self.assertEqual(item_type, 'chest')
        self.assertEqual(item_data, {})
    
    def test_parse_item_key_consumable(self):
        """Test le parsing des consommables."""
        item_type, item_data = parse_item_key('coins')
        self.assertEqual(item_type, 'consumable')
        self.assertEqual(item_data, {'type': 'coins', 'quantity': 1})
    
    def test_parse_item_key_unknown(self):
        """Test le parsing d'une clé inconnue."""
        item_type, item_data = parse_item_key('unknown_item')
        self.assertEqual(item_type, 'unknown')
        self.assertEqual(item_data, {})
    
    # ========================================================================
    # TESTS DES CAS D'ERREUR
    # ========================================================================
    
    def test_none_item_data(self):
        """Test interaction avec données None."""
        result = self.interaction_manager.interact_with_item('food', None)
        self.assertTrue(result)  # Doit gérer le None correctement
    
    def test_empty_item_data(self):
        """Test interaction avec données vides."""
        result = self.interaction_manager.interact_with_item('food', {})
        self.assertTrue(result)  # Doit utiliser les valeurs par défaut
    
    def test_no_current_room(self):
        """Test quand il n'y a pas de pièce actuelle."""
        self.mock_manor.get_room.return_value = None
        
        interactions = self.interaction_manager.get_available_interactions()
        self.assertEqual(interactions, [])
        
        can_interact = self.interaction_manager.can_interact_with_object('chest')
        self.assertTrue(can_interact)  # Doit retourner True par défaut


class TestInteractionManagerIntegration(unittest.TestCase):
    """Tests d'intégration plus complexes."""
    
    def setUp(self):
        """Configuration pour les tests d'intégration."""
        self.mock_player = Mock()
        self.mock_player.position = (2, 2)
        
        self.mock_inventory = Mock()
        self.mock_player.inventory = self.mock_inventory
        
        self.mock_manor = Mock()
        self.mock_room = Mock()
        self.mock_room.name = "Test Room"
        self.mock_room.items = []
        self.mock_manor.get_room.return_value = self.mock_room
        
        self.interaction_manager = InteractionManager(self.mock_player, self.mock_manor)
        
        # Configuration de base de l'inventaire
        self.mock_inventory.steps = Mock()
        self.mock_inventory.steps.add = Mock()
        self.mock_inventory.keys = Mock()
        self.mock_inventory.keys.quantity = 1
        self.mock_inventory.keys.use = Mock()
        self.mock_inventory.add_item = Mock()
        self.mock_inventory.add_permanent_item = Mock(return_value=True)
        self.mock_inventory.has_item = Mock(return_value=False)
    
    def test_full_chest_interaction_flow(self):
        """Test le flux complet d'ouverture d'un coffre."""
        # Configuration
        self.mock_inventory.has_item.return_value = False  # Pas de marteau
        self.mock_inventory.keys.quantity = 1
        
        # Simuler un butin spécifique
        with patch('random.choice') as mock_choice, \
             patch.object(self.interaction_manager, 'message_callback'):
            
            mock_choice.return_value = {'coins': 30, 'gems': 1}
            
            # Ouvrir le coffre
            result = self.interaction_manager.interact_with_item('chest', {})
            
            # Vérifications
            self.assertTrue(result)
            self.mock_inventory.keys.use.assert_called_once_with(self.mock_player)
            self.mock_inventory.add_item.assert_any_call('coins', 30)
            self.mock_inventory.add_item.assert_any_call('gems', 1)
    
    def test_digging_with_bonuses(self):
        """Test le creusage avec bonus d'objets permanents."""
        # Configuration avec pelle
        self.mock_inventory.has_item.return_value = True
        
        with patch('random.choice') as mock_choice, \
             patch.object(self.interaction_manager, 'message_callback'):
            
            mock_choice.return_value = {'coins': 25, 'keys': 1}
            
            result = self.interaction_manager.interact_with_item('digging', {})
            
            self.assertTrue(result)
            self.mock_inventory.add_item.assert_any_call('coins', 25)
            self.mock_inventory.add_item.assert_any_call('keys', 1)


def run_tests():
    """Lance tous les tests avec un affichage clair."""
    print("🧪" + "="*60)
    print("🧪           LANCEMENT DES TESTS INTERACTION MANAGER")
    print("🧪" + "="*60)
    print()
    
    # Créer la suite de tests
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Ajouter les tests
    suite.addTests(loader.loadTestsFromTestCase(TestInteractionManager))
    suite.addTests(loader.loadTestsFromTestCase(TestInteractionManagerIntegration))
    
    # Lancer les tests avec un runner personnalisé
    runner = unittest.TextTestRunner(verbosity=2, descriptions=True)
    result = runner.run(suite)
    
    # Affichage des résultats
    print()
    print("📊" + "="*60)
    print("📊                    RÉSULTATS DES TESTS")
    print("📊" + "="*60)
    print(f"📊 Tests exécutés: {result.testsRun}")
    print(f"📊 Échecs: {len(result.failures)}")
    print(f"📊 Erreurs: {len(result.errors)}")
    
    if result.failures:
        print("\n❌ ÉCHECS:")
        for test, traceback in result.failures:
            print(f"   ❌ {test}")
            print(f"      {traceback.splitlines()[-1]}")
    
    if result.errors:
        print("\n🚨 ERREURS:")
        for test, traceback in result.errors:
            print(f"   🚨 {test}")
            print(f"      {traceback.splitlines()[-1]}")
    
    if result.wasSuccessful():
        print("\n🎉 TOUS LES TESTS ONT RÉUSSI !")
        return True
    else:
        print("\n💥 CERTAINS TESTS ONT ÉCHOUÉ !")
        return False


if __name__ == '__main__':
    # Lancer les tests
    success = run_tests()
    
    # Code de sortie pour les intégrations continues
    sys.exit(0 if success else 1)