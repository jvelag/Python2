"""
Classe principale du jeu.
Jour 4 : Structure de base du jeu.
"""

from manor import Manor
from player import Player
from room import Room, RoomColor
from door import Door
from random_manager import RandomManager


class BluePrinceGame:
    """Classe principale gérant le jeu."""
    
    def __init__(self):
        print("🎮 Initializing Blue Prince...")
        
        # Initialisation du modèle
        self.manor = Manor()
        self.player = Player(self.manor.entrance_position)
        self.random_manager = RandomManager()
        
        # Catalogue de pièces (simplifié pour l'instant)
        self.room_catalog = self._create_basic_catalog()
        
        # Place les pièces de départ
        self._setup_initial_rooms()
        
        # État du jeu
        self.running = True
        self.game_over = False
        self.victory = False
        
        print("✅ Game initialized!\n")
    
    def _create_basic_catalog(self) -> list:
        """Crée un catalogue basique de pièces."""
        catalog = []
        
        # Quelques pièces d'exemple
        catalog.append(Room("Library", RoomColor.BLUE, rarity=0, gem_cost=0))
        catalog.append(Room("Kitchen", RoomColor.YELLOW, rarity=0, gem_cost=0))
        catalog.append(Room("Bedroom", RoomColor.GREEN, rarity=1, gem_cost=1))
        catalog.append(Room("Treasury", RoomColor.PURPLE, rarity=2, gem_cost=2))
        catalog.append(Room("Secret Room", RoomColor.RED, rarity=3, gem_cost=3))
        
        return catalog
    
    def _setup_initial_rooms(self):
        """Place les pièces d'entrée et de sortie."""
        entrance = Room("Entrance Hall", RoomColor.BLUE, rarity=0)
        entrance.add_door("north", Door(Door.UNLOCKED))
        
        antechamber = Room("Antechamber", RoomColor.BLUE, rarity=0)
        antechamber.add_door("south", Door(Door.UNLOCKED))
        
        self.manor.place_room(entrance, self.manor.entrance_position)
        self.manor.place_room(antechamber, self.manor.exit_position)
    
    def run_text_mode(self):
        """Boucle de jeu en mode texte (temporaire)."""
        print("=" * 60)
        print("         BLUE PRINCE - TEXT MODE (Day 4)")
        print("=" * 60)
        print("\nCommands: n=north, s=south, e=east, w=west, i=inventory, q=quit\n")
        
        while self.running and not self.game_over:
            # Affichage
            self.manor.display_grid(self.player.position)
            self.player.inventory.display()
            
            # Victoire/Défaite
            if self.player.position == self.manor.exit_position:
                print("\n🎉 VICTORY! You reached the Antechamber!")
                self.victory = True
                self.game_over = True
                break
            
            if self.player.has_lost():
                print("\n💀 GAME OVER! No more steps!")
                self.game_over = False
                break
            
            # Input
            command = input("\n> ").strip().lower()
            
            if command == 'q':
                self.running = False
            elif command == 'i':
                self.player.inventory.display()
            elif command in ['n', 's', 'e', 'w']:
                self._handle_movement(command)
            else:
                print("❌ Unknown command")
        
        print("\n👋 Thanks for playing!")
    
    def _handle_movement(self, direction: str):
        """Gère un déplacement."""
        direction_map = {
            'n': 'north',
            's': 'south',
            'e': 'east',
            'w': 'west'
        }
        
        direction_offset = {
            'north': (-1, 0),
            'south': (1, 0),
            'east': (0, 1),
            'west': (0, -1)
        }
        
        dir_name = direction_map[direction]
        offset = direction_offset[dir_name]
        
        new_pos = (
            self.player.position[0] + offset[0],
            self.player.position[1] + offset[1]
        )
        
        if not self.manor.is_position_valid(new_pos):
            print("❌ Cannot go outside the manor!")
            return
        
        # Pour l'instant, déplacement direct (sans système de portes complet)
        self.player.move(new_pos, self.manor)


# Test
if __name__ == "__main__":
    game = BluePrinceGame()
    game.run_text_mode()