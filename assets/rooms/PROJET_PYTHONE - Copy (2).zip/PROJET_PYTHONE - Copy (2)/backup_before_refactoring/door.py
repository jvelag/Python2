"""Module de gestion des portes.
Jour 2 : Système de verrouillage à 3 niveaux.
"""

class Door:
    """Représente une porte avec niveau de verrouillage."""
    
    # Constantes pour les niveaux
    UNLOCKED = 0
    LOCKED = 1
    DOUBLE_LOCKED = 2
    
    def __init__(self, lock_level: int = UNLOCKED):
        self.lock_level = lock_level
        self.is_open = False
    
    def get_emoji(self) -> str:
        """Retourne l'emoji correspondant à l'état de la porte."""
        if self.is_open:
            return "🚪➡️"
        elif self.lock_level == Door.UNLOCKED:
            return "🚪"
        elif self.lock_level == Door.LOCKED:
            return "🔒"
        elif self.lock_level == Door.DOUBLE_LOCKED:
            return "🔐"
        else:
            return "🚪"
    
    def get_lock_level_name(self) -> str:
        """Retourne le nom du niveau de verrouillage."""
        lock_names = {
            Door.UNLOCKED: "déverrouillée",
            Door.LOCKED: "verrouillée",
            Door.DOUBLE_LOCKED: "doublement verrouillée"
        }
        return lock_names.get(self.lock_level, "état inconnu")
    
    def get_state_name(self) -> str:
        """Retourne le nom complet de l'état de la porte."""
        status = "ouverte" if self.is_open else "fermée"
        lock_state = self.get_lock_level_name()
        return f"{status} ({lock_state})"
    
    def can_open(self, player) -> tuple[bool, str]:
        """Vérifie si le joueur peut ouvrir la porte."""
        if self.lock_level == Door.UNLOCKED:
            return True, "Porte déverrouillée"
        
        # ✅ CORRECTION: Vérification du kit de crochetage pour niveau 1
        if self.lock_level == Door.LOCKED:
            # Kit de crochetage peut ouvrir les portes niveau 1
            if player.inventory.has_permanent_item('lockpick_kit'):
                return True, "Peut ouvrir avec kit de crochetage"
            if player.inventory.keys.quantity > 0:
                return True, "Peut ouvrir avec une clé"
            return False, "Clé ou kit de crochetage nécessaire"
        
        if self.lock_level == Door.DOUBLE_LOCKED:
            # Kit ne fonctionne PAS sur niveau 2
            if player.inventory.keys.quantity > 0:
                return True, "Peut ouvrir avec une clé (double verrou)"
            return False, "Clé nécessaire (double verrou)"
        
        return False, "Impossible d'ouvrir"
    
    def open(self, player) -> bool:
        """Tente d'ouvrir la porte."""
        can_open, message = self.can_open(player)
        emoji = self.get_emoji()
        print(f"{emoji} {message}")
        
        if can_open:
            # ✅ CORRECTION: Ne consomme une clé que si pas de kit
            if self.lock_level == Door.LOCKED and player.inventory.has_permanent_item('lockpick_kit'):
                # Kit de crochetage utilisé, pas de consommation de clé
                print("🔓 Kit de crochetage utilisé")
                self.is_open = True
                return True
            elif self.lock_level > 0:
                # Consomme une clé
                player.inventory.keys.use(player)
                self.is_open = True
                return True
            else:
                self.is_open = True
                return True
        
        return False
    
    def __str__(self):
        emoji = self.get_emoji()
        state_name = self.get_state_name()
        return f"{emoji} Porte ({state_name})"


def demo_doors():
    """Démonstration du fonctionnement des portes."""
    from inventory import Inventory
    
    class MockPlayer:
        def __init__(self):
            self.inventory = Inventory()
    
    player = MockPlayer()
    
    print("🧪 Démonstration du système de portes:")
    print("=" * 50)
    
    # Création de différentes portes
    door1 = Door(Door.UNLOCKED)
    door2 = Door(Door.LOCKED)
    door3 = Door(Door.DOUBLE_LOCKED)
    
    # Test des emojis et états
    print("📋 États des portes:")
    print(f"✓ Porte déverrouillée : {door1} {door1.get_emoji()}")
    print(f"✓ Porte verrouillée : {door2} {door2.get_emoji()}")
    print(f"✓ Porte doublement verrouillée : {door3} {door3.get_emoji()}")
    
    # Test d'ouverture sans kit
    print("\n🎮 Test d'ouverture SANS kit de crochetage:")
    print(f"Avant ouverture: {door2}")
    success = door2.open(player)  # Devrait échouer sans clé
    print(f"Réussite: {success}")
    
    player.inventory.add_item("keys", 1)
    print(f"Avec une clé: {door2}")
    success = door2.open(player)  # Devrait réussir avec clé
    print(f"Réussite: {success}")
    print(f"Après ouverture: {door2}")
    
    # Test avec kit de crochetage
    print("\n🔓 Test AVEC kit de crochetage:")
    player.inventory.add_permanent_item('lockpick_kit')
    door4 = Door(Door.LOCKED)
    print(f"Nouvelle porte verrouillée: {door4}")
    print(f"Kit disponible: {player.inventory.has_permanent_item('lockpick_kit')}")
    success = door4.open(player)  # Devrait réussir avec kit
    print(f"Réussite: {success}")
    print(f"Clés restantes: {player.inventory.keys.quantity}")  # Doit rester 0 clés
    print(f"Après ouverture: {door4}")


# Test
if __name__ == "__main__":
    demo_doors()