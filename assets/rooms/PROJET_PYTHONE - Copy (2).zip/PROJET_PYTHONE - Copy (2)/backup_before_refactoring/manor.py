"""
Module du manoir.
Jour 3 : Grille 5x9 de pièces.
"""

from room import Room
 

class Manor:
    """Représente le manoir (grille  5*9)."""
    
    def __init__(self, height: int = 5, width: int = 9):
        self.height = height
        self.width = width
        # Grille de pièces (None = pas découvert)
        self.grid = [[None for _ in range(width)] for _ in range(height)]
        
        # Positions spéciales
        self.entrance_position = (height - 1, width // 2)  # (4, 4)
        self.exit_position = (0, width // 2)  # (0, 4)
    
    def place_room(self, room: Room, position: tuple):
        """Place une pièce dans la grille."""
        row, col = position
        if self.is_position_valid(position):
            self.grid[row][col] = room
            print(f"✅ Placed {room.name} at {position}")
        else:
            print(f"❌ Invalid position {position}")
    
    def get_room(self, position: tuple):
        """Récupère la pièce à une position."""
        row, col = position
        if self.is_position_valid(position):
            return self.grid[row][col]
        return None
    
    def is_position_valid(self, position: tuple) -> bool:
        """Vérifie si une position est valide."""
        row, col = position
        return 0 <= row < self.height and 0 <= col < self.width
    
    def display_grid(self, player_position: tuple = None):
        """Affiche la grille (version texte simple)."""
        print("\n📍 Manor Grid:")
        print("=" * (self.width * 4 + 1))
        
        for row in range(self.height):
            line = "|"
            for col in range(self.width):
                pos = (row, col)
                
                if pos == player_position:
                    line += " 👤 |"
                elif pos == self.exit_position:
                    line += " 🎯 |"
                elif pos == self.entrance_position:
                    line += " 🚪 |"
                elif self.grid[row][col]:
                    line += " ✓ |"
                else:
                    line += "   |"
            
            print(line)
            print("-" * (self.width * 4 + 1))
        
        print("=" * (self.width * 4 + 1))
        print("Legend: 👤=Player, 🎯=Exit, 🚪=Entrance, ✓=Room\n")


# Test
if __name__ == "__main__":
    from room import RoomColor
    from player import Player
    
    manor = Manor()
    player = Player(manor.entrance_position)
    
    # Place quelques pièces
    entrance = Room("Entrance Hall", RoomColor.BLUE)
    manor.place_room(entrance, manor.entrance_position)
    
    manor.display_grid(player.position)