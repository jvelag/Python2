#!/usr/bin/env python3
"""
Blue Prince - Projet POO 2025
Jour 7 : Version finale avec tous les systèmes.
"""

import pygame
import sys

from manor import Manor
from player import Player
from room import create_room_catalog , Room, RoomColor
from door import Door
from resource_manager import ResourceManager
from random_manager import RandomManager
from interaction_manager import InteractionManager
from grid_renderer import GridRenderer
from inventory_renderer import InventoryRenderer
from room_selection_menu import RoomSelectionMenu


class BluePrinceGame:
    """Classe principale du jeu - Version finale Jour 7."""
    
    def __init__(self):
        pygame.init()
        
        # Fenêtre
        self.screen = pygame.display.set_mode((1920, 1080))
        pygame.display.set_caption("Blue Prince - Final Version")
        self.clock = pygame.time.Clock()
        
        # Ressources
        self.resources = ResourceManager()
        
        # Modèle
        self.manor = Manor()
        self.player = Player(self.manor.entrance_position)
        self.random_manager = RandomManager()
        self.interaction_manager = InteractionManager(self.player, self.manor)
        self.room_catalog = create_room_catalog()
        
        # Renderers
        self.grid_renderer = GridRenderer(self.screen, self.resources)
        self.inventory_renderer = InventoryRenderer(self.screen, self.resources)
        self.room_selection_menu = RoomSelectionMenu(self.screen, self.resources)
        
        # Setup
        self._setup_initial_rooms()
        
        # État
        self.running = True
        self.game_over = False
        self.game_state = "playing"
        self.pending_room_position = None
        
        print("✅ Blue Prince initialized successfully!")
    
    def _setup_initial_rooms(self):
        """Place les pièces de départ."""
        # Entrée
        entrance = Room("Entrance Hall", RoomColor.BLUE, rarity=0)
        entrance.add_door("north", Door(Door.UNLOCKED))
        entrance.visited = True
        self.manor.place_room(entrance, self.manor.entrance_position)
        
        # Sortie
        antechamber = Room("Antechamber", RoomColor.BLUE, rarity=0)
        antechamber.add_door("south", Door(Door.UNLOCKED))
        self.manor.place_room(antechamber, self.manor.exit_position)
    
    def handle_events(self):
        """Gère les événements."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            # Menu de sélection prioritaire
            if self.room_selection_menu.handle_input(event):
                continue
            
            if event.type == pygame.KEYDOWN:
                self._handle_keypress(event.key)
    
    def _handle_keypress(self, key):
        """Gère les touches."""
        if self.game_state != "playing":
            return
        
        # Déplacements / Portes
        direction_map = {
            pygame.K_z: ('north', (-1, 0)),
            pygame.K_s: ('south', (1, 0)),
            pygame.K_q: ('west', (0, -1)),
            pygame.K_d: ('east', (0, 1))
        }
        
        if key in direction_map:
            dir_name, offset = direction_map[key]
            self._try_move_or_open_door(dir_name, offset)
        
        # Interactions avec objets de la pièce (touches 1-9)
        elif pygame.K_1 <= key <= pygame.K_9:
            index = key - pygame.K_1
            self._interact_with_room_object(index)
        
        # Utiliser un dé pour retirer (touche R)
        elif key == pygame.K_r:
            if self.room_selection_menu.is_visible:
                self._use_dice_redraw()
        
        elif key == pygame.K_ESCAPE:
            self.running = False
        
        elif key == pygame.K_i:
            # Affiche l'inventaire dans la console (debug)
            self.player.inventory.display()
    
    def _try_move_or_open_door(self, direction: str, offset: tuple):
        """Essaye de se déplacer ou d'ouvrir une porte."""
        current_room = self.manor.get_room(self.player.position)
        
        if not current_room:
            return
        
        new_pos = (
            self.player.position[0] + offset[0],
            self.player.position[1] + offset[1]
        )
        
        if not self.manor.is_position_valid(new_pos):
            print("❌ Cannot go outside!")
            return
        
        if direction not in current_room.doors:
            print(f"❌ No door to the {direction}!")
            return
        
        door = current_room.doors[direction]
        
        if door.is_open:
            next_room = self.manor.get_room(new_pos)
            if next_room:
                self.player.move(new_pos, self.manor)
            else:
                print("⚠️ Door open but no room!")
        else:
            if door.open(self.player):
                self._draw_rooms_for_selection(new_pos)
    
    def _draw_rooms_for_selection(self, position: tuple):
        """Tire 3 pièces pour sélection."""
        available = [r for r in self.room_catalog if r.can_be_placed(position, (self.manor.height, self.manor.width))]
        
        if not available:
            print("⚠️ No more rooms!")
            return
        
        drawn_rooms = self.random_manager.draw_rooms(available, 3)
        self.pending_room_position = position
        
        self.game_state = "selecting_room"
        self.room_selection_menu.show(drawn_rooms, lambda room: self._place_selected_room(room))
    
    def _place_selected_room(self, room: Room):
        """Place la pièce sélectionnée."""
        if self.player.inventory.gems.quantity < room.gem_cost:
            print("❌ Not enough gems!")
            return
        
        # Dépense gemmes
        for _ in range(room.gem_cost):
            self.player.inventory.gems.use(self.player)
        
        # Place
        self.manor.place_room(room, self.pending_room_position)
        
        # Retire du catalogue
        if room in self.room_catalog:
            self.room_catalog.remove(room)
        
        # Effet au tirage
        if room.on_draw_effect:
            room.on_draw_effect(self.player, room)
        
        # ✅ AJOUT: Gestion des effets de couleur
        self._apply_room_color_effects(room)
        
        # Génère portes
        self._generate_doors_for_room(room, self.pending_room_position)
        
        # Déplace
        self.player.move(self.pending_room_position, self.manor)
        
        # Retour au jeu
        self.game_state = "playing"
        self.pending_room_position = None

    def _apply_room_color_effects(self, room: Room):
        """Applique les effets de couleur des pièces spéciales."""
        if room.name == "Greenhouse":
            self.random_manager.apply_color_boost('green', 2.0)
            print("🌿 La serre augmente vos chances de trouver des pièces vertes!")
        
        elif room.name == "Furnace Room":
            self.random_manager.apply_color_boost('red', 1.5)
            print("🔥 Le fourneau attire les pièces rouges dangereuses...")
        
        elif room.name == "Library":
            # Les bibliothèques pourraient booster les pièces bleues
            self.random_manager.apply_color_boost('blue', 1.3)
            print("📚 La bibliothèque influence les tirages vers les pièces bleues")
        
        elif room.name == "Workshop":
            # Les ateliers pourraient booster les pièces vertes
            self.random_manager.apply_color_boost('green', 1.4)
            print("🛠️ L'atelier augmente les chances de pièces vertes")
        
        elif room.name == "Treasury":
            # Les trésoreries pourraient booster les pièces violettes
            self.random_manager.apply_color_boost('purple', 1.6)
            print("💰 Le trésor attire les pièces violettes riches!")
    
    def _generate_doors_for_room(self, room: Room, position: tuple):
        """Génère les portes avec niveaux aléatoires."""
        row, col = position
        
        directions = {
            'north': (-1, 0),
            'south': (1, 0),
            'east': (0, 1),
            'west': (0, -1)
        }
        
        for dir_name, offset in directions.items():
            adj_pos = (row + offset[0], col + offset[1])
            
            if self.manor.is_position_valid(adj_pos):
                # ✅ CORRECTION: Utilise la génération aléatoire
                lock_level = self.random_manager.get_door_lock_level(row, self.manor.height)
                door = Door(lock_level)
                room.add_door(dir_name, door)
                
                print(f"🚪 Porte {dir_name} générée avec niveau {lock_level}")
    
    def _interact_with_room_object(self, index: int):
        """Interagit avec un objet de la pièce."""
        current_room = self.manor.get_room(self.player.position)
        
        if not current_room or not current_room.items:
            return
        
        if index >= len(current_room.items):
            return
        
        item_key = current_room.items[index]
        
        # Détermine le type et interagit
        if item_key.startswith("food_"):
            food_type = item_key.replace("food_", "")
            self.interaction_manager.interact_with_item('food', {'type': food_type})
            current_room.items.remove(item_key)
        
        elif item_key == "chest":
            self.interaction_manager.interact_with_item('chest', {})
            current_room.items.remove(item_key)
        
        elif item_key == "digging":
            self.interaction_manager.interact_with_item('digging', {})
            current_room.items.remove(item_key)
        
        elif item_key in ["coins", "keys", "gems", "dice"]:
            self.interaction_manager.interact_with_item('consumable', {'type': item_key, 'quantity': 1})
            current_room.items.remove(item_key)
        
        elif item_key.startswith("permanent_"):
            perm_type = item_key.replace("permanent_", "")
            self.interaction_manager.interact_with_item('permanent', {'type': perm_type})
            current_room.items.remove(item_key)
    
    def _use_dice_redraw(self):
        """Utilise un dé pour retirer."""
        if self.player.inventory.dice.quantity <= 0:
            print("❌ No dice!")
            return
        
        self.player.inventory.dice.use(self.player)
        print("🎲 Used a dice to redraw!")
        
        # Retirer (simplifié)
        if self.pending_room_position:
            self._draw_rooms_for_selection(self.pending_room_position)
    
    def update(self):
        """Met à jour le jeu."""
        if self.game_state != "playing":
            return
        
        # Victoire
        if self.player.position == self.manor.exit_position:
            print("\n🎉 VICTORY!")
            self.game_over = True
        
        # Défaite
        if self.player.has_lost():
            print("\n💀 GAME OVER!")
            self.game_over = True
    
    def render(self):
        """Affiche le jeu."""
        self.screen.fill(self.resources.get_color('background'))
        
        self.grid_renderer.render_grid(self.manor, self.player)
        self.inventory_renderer.render(self.player.inventory)
        self.room_selection_menu.render(self.player.inventory)
        
        if self.game_over:
            self._render_game_over()
        
        self._render_instructions()
        
        pygame.display.flip()
    
    def _render_game_over(self):
        """Affiche l'écran de fin."""
        overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 200))
        self.screen.blit(overlay, (0, 0))
        
        font_title = self.resources.get_font('title')
        
        if self.player.position == self.manor.exit_position:
            message = "🎉 VICTORY! 🎉"
            color = (100, 255, 100)
            subtitle = f"Steps remaining: {self.player.inventory.steps.quantity}"
        else:
            message = "💀 GAME OVER 💀"
            color = (255, 100, 100)
            subtitle = "No more steps..."
        
        title = font_title.render(message, True, color)
        title_rect = title.get_rect(center=(self.screen.get_width() // 2, 300))
        self.screen.blit(title, title_rect)
        
        font_sub = self.resources.get_font('medium')
        sub = font_sub.render(subtitle, True, (255, 255, 255))
        sub_rect = sub.get_rect(center=(self.screen.get_width() // 2, 360))
        self.screen.blit(sub, sub_rect)
        
        font_inst = self.resources.get_font('medium')
        inst = font_inst.render("Press ESC to quit", True, (255, 255, 255))
        inst_rect = inst.get_rect(center=(self.screen.get_width() // 2, 450))
        self.screen.blit(inst, inst_rect)
    
    def _render_instructions(self):
        """Affiche les instructions."""
        if self.game_over or self.room_selection_menu.is_visible:
            return
        
        font = self.resources.get_font('small')
        instructions = [
            "ZQSD: Move/Open doors",
            "1-9: Interact with objects",
            "R: Use dice (in selection)",
            "I: Show inventory (console)",
            "ESC: Quit"
        ]
        
        y = 20
        for instruction in instructions:
            text = font.render(instruction, True, self.resources.get_color('text_dark'))
            self.screen.blit(text, (50, y))
            y += 22
    
    def run(self):
        """Boucle principale."""
        print("=" * 70)
        print("                    BLUE PRINCE - FINAL VERSION")
        print("=" * 70)
        print("\n📜 Goal: Reach the Antechamber at the top of the manor!")
        print("\n🎮 Controls:")
        print("  ZQSD        : Move / Open doors")
        print("  1-9         : Interact with room objects")
        print("  ← →         : Navigate in room selection")
        print("  ENTER       : Select room")
        print("  R           : Use dice to redraw rooms")
        print("  I           : Display inventory (console)")
        print("  ESC         : Quit")
        print("\n💡 Tips:")
        print("  • Manage your steps wisely!")
        print("  • Collect keys to open doors")
        print("  • Use gems to select better rooms")
        print("  • Find permanent items for advantages")
        print("=" * 70)
        print()
        
        while self.running and not self.game_over:
            self.handle_events()
            self.update()
            self.render()
            self.clock.tick(60)
        
        # Attendre avant de quitter
        if self.game_over:
            waiting = True
            while waiting:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                        waiting = False
                self.render()
                self.clock.tick(60)
        
        pygame.quit()
        print("\n👋 Thanks for playing Blue Prince!")


def main():
    """Point d'entrée."""
    try:
        game = BluePrinceGame()
        game.run()
    except KeyboardInterrupt:
        print("\n⚠️ Game interrupted")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()