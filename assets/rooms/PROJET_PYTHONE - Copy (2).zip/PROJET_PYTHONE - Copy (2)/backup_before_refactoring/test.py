#!/usr/bin/env python3
"""
Script de refactoring pour réorganiser le projet Blue Prince.

Ce script:
1. Crée la nouvelle structure de dossiers
2. Déplace les fichiers aux bons endroits
3. Met à jour les imports
4. Crée les __init__.py appropriés
5. Génère requirements.txt
"""

import os
import shutil
from pathlib import Path

# Couleurs pour l'affichage
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    END = '\033[0m'

def print_step(message):
    print(f"\n{Colors.BLUE}📋 {message}{Colors.END}")

def print_success(message):
    print(f"{Colors.GREEN}✅ {message}{Colors.END}")

def print_warning(message):
    print(f"{Colors.YELLOW}⚠️  {message}{Colors.END}")

def print_error(message):
    print(f"{Colors.RED}❌ {message}{Colors.END}")


class ProjectRefactorer:
    """Réorganise la structure du projet Blue Prince."""
    
    def __init__(self, project_root: str = "."):
        """
        Initialise le refactorer.
        
        Args:
            project_root: Chemin vers la racine du projet
        """
        self.root = Path(project_root).resolve()
        self.backup_dir = self.root / "backup_before_refactoring"
        
        # Nouvelle structure
        self.new_structure = {
            'models': [
                'item.py', 'inventory.py', 'door.py', 
                'room.py', 'player.py', 'manor.py'
            ],
            'managers': [
                'random_manager.py', 'interaction_manager.py',
                'shop_manager.py'
            ],
            'renderers': [
                'grid_renderer.py', 'inventory_renderer.py',
                'room_selection_menu.py'
            ],
            'utils': [
                'resource_manager.py'
            ]
        }
        
        # Fichiers à supprimer (obsolètes)
        self.files_to_remove = ['game.py', 'init.py']
        
        # Fichiers à garder à la racine
        self.root_files = [
            'main.py', 'README.md', 'requirements.txt',
            '.gitignore'
        ]
    
    def create_backup(self):
        """Crée une sauvegarde du projet actuel."""
        print_step("Création de la sauvegarde...")
        
        if self.backup_dir.exists():
            print_warning(f"Le dossier de sauvegarde existe déjà: {self.backup_dir}")
            response = input("Voulez-vous l'écraser? (y/N): ")
            if response.lower() != 'y':
                print_error("Sauvegarde annulée. Arrêt du script.")
                return False
            shutil.rmtree(self.backup_dir)
        
        # Copier tous les fichiers Python
        self.backup_dir.mkdir(parents=True)
        for file in self.root.glob("*.py"):
            if file.name not in ['refactor.py']:  # Ne pas sauvegarder le script lui-même
                shutil.copy2(file, self.backup_dir / file.name)
        
        print_success(f"Sauvegarde créée dans: {self.backup_dir}")
        return True
    
    def create_directory_structure(self):
        """Crée la nouvelle structure de dossiers."""
        print_step("Création de la nouvelle structure...")
        
        for directory in self.new_structure.keys():
            dir_path = self.root / directory
            dir_path.mkdir(exist_ok=True)
            print_success(f"Dossier créé: {directory}/")
    
    def move_files(self):
        """Déplace les fichiers vers leurs nouveaux emplacements."""
        print_step("Déplacement des fichiers...")
        
        for directory, files in self.new_structure.items():
            for filename in files:
                source = self.root / filename
                destination = self.root / directory / filename
                
                if source.exists():
                    shutil.move(str(source), str(destination))
                    print_success(f"{filename} → {directory}/")
                else:
                    print_warning(f"Fichier non trouvé: {filename}")
    
    def remove_obsolete_files(self):
        """Supprime les fichiers obsolètes."""
        print_step("Suppression des fichiers obsolètes...")
        
        for filename in self.files_to_remove:
            file_path = self.root / filename
            if file_path.exists():
                file_path.unlink()
                print_success(f"Supprimé: {filename}")
            else:
                print_warning(f"Déjà absent: {filename}")
    
    def create_init_files(self):
        """Crée les fichiers __init__.py."""
        print_step("Création des fichiers __init__.py...")
        
        # models/__init__.py
        models_init = '''"""
Package models pour le jeu Blue Prince.
Contient toutes les classes du modèle de données.
"""

from .item import (
    Item, ConsumableItem, PermanentItem, Food,
    Steps, Keys, Gems, Coins, Dice,
    Shovel, Hammer, LockpickKit, MetalDetector, RabbitFoot,
    Compass, Map, Torch, Spyglass, Hourglass,
    Apple, Banana, Cake, Sandwich, Meal
)
from .inventory import Inventory
from .door import Door
from .room import Room, RoomColor, create_room_catalog
from .player import Player
from .manor import Manor

__all__ = [
    # Abstract
    'Item', 'ConsumableItem', 'PermanentItem', 'Food',
    # Consumables
    'Steps', 'Keys', 'Gems', 'Coins', 'Dice',
    # Permanent items
    'Shovel', 'Hammer', 'LockpickKit', 'MetalDetector', 'RabbitFoot',
    'Compass', 'Map', 'Torch', 'Spyglass', 'Hourglass',
    # Food
    'Apple', 'Banana', 'Cake', 'Sandwich', 'Meal',
    # Core
    'Inventory', 'Door', 'Room', 'RoomColor', 'Player', 'Manor',
    # Functions
    'create_room_catalog'
]

__version__ = '1.0.0'
__author__ = 'Moss'
'''
        
        # managers/__init__.py
        managers_init = '''"""
Package managers pour le jeu Blue Prince.
Contient la logique métier du jeu.
"""

from .random_manager import RandomManager
from .interaction_manager import InteractionManager
from .shop_manager import ShopManager

__all__ = [
    'RandomManager',
    'InteractionManager',
    'ShopManager'
]
'''
        
        # renderers/__init__.py
        renderers_init = '''"""
Package renderers pour le jeu Blue Prince.
Contient les composants d'affichage Pygame.
"""

from .grid_renderer import GridRenderer
from .inventory_renderer import InventoryRenderer
from .room_selection_menu import RoomSelectionMenu

__all__ = [
    'GridRenderer',
    'InventoryRenderer',
    'RoomSelectionMenu'
]
'''
        
        # utils/__init__.py
        utils_init = '''"""
Package utils pour le jeu Blue Prince.
Contient les utilitaires et ressources.
"""

from .resource_manager import ResourceManager

__all__ = [
    'ResourceManager'
]
'''
        
        # Écrire les fichiers
        init_files = {
            'models': models_init,
            'managers': managers_init,
            'renderers': renderers_init,
            'utils': utils_init
        }
        
        for directory, content in init_files.items():
            init_path = self.root / directory / '__init__.py'
            init_path.write_text(content)
            print_success(f"Créé: {directory}/__init__.py")
    
    def update_imports(self):
        """Met à jour les imports dans tous les fichiers."""
        print_step("Mise à jour des imports...")
        
        # Mappages d'imports à remplacer
        import_mappings = {
            'from models.item import': 'from models.item import',
            'from models.inventory import': 'from models.inventory import',
            'from models.door import': 'from models.door import',
            'from models.room import': 'from models.room import',
            'from models.player import': 'from models.player import',
            'from models.manor import': 'from models.manor import',
            'from models.door import': 'from models.door import',  # Déjà correct
            'from models.inventory import': 'from models.inventory import',  # Déjà correct
            'from managers.random_manager import': 'from managers.random_manager import',
            'from managers.interaction_manager import': 'from managers.interaction_manager import',
            'from managers.shop_manager import': 'from managers.shop_manager import',
            'from renderers.grid_renderer import': 'from renderers.grid_renderer import',
            'from renderers.inventory_renderer import': 'from renderers.inventory_renderer import',
            'from renderers.room_selection_menu import': 'from renderers.room_selection_menu import',
            'from utils.resource_manager import': 'from utils.resource_manager import'
        }
        
        # Parcourir tous les fichiers Python
        for directory in ['models', 'managers', 'renderers', 'utils', '.']:
            dir_path = self.root if directory == '.' else self.root / directory
            
            for py_file in dir_path.glob('*.py'):
                if py_file.name in ['refactor.py', '__init__.py']:
                    continue
                
                try:
                    # CORRECTION : Spécifier l'encodage UTF-8 explicitement
                    content = py_file.read_text(encoding='utf-8')
                    original_content = content
                    
                    # Remplacer les imports
                    for old_import, new_import in import_mappings.items():
                        content = content.replace(old_import, new_import)
                    
                    # Sauvegarder si modifié
                    if content != original_content:
                        # CORRECTION : Écrire aussi en UTF-8
                        py_file.write_text(content, encoding='utf-8')
                        print_success(f"Imports mis à jour: {py_file.name}")
                        
                except UnicodeDecodeError as e:
                    print_warning(f"Problème d'encodage avec {py_file.name}, tentative avec gestion d'erreurs...")
                    try:
                        # Fallback avec gestion d'erreurs
                        content = py_file.read_text(encoding='utf-8', errors='replace')
                        original_content = content
                        
                        # Remplacer les imports
                        for old_import, new_import in import_mappings.items():
                            content = content.replace(old_import, new_import)
                        
                        if content != original_content:
                            py_file.write_text(content, encoding='utf-8')
                            print_success(f"Imports mis à jour (avec remplacement): {py_file.name}")
                            
                    except Exception as e2:
                        print_error(f"Impossible de lire {py_file.name}: {e2}")
    
    def create_requirements_txt(self):
        """Crée le fichier requirements.txt."""
        print_step("Création de requirements.txt...")
        
        requirements = '''# Blue Prince - Projet POO 2025
# Requirements

pygame==2.5.2

# Dev dependencies (optional)
# pytest==7.4.3
# black==23.12.1
# pylint==3.0.3
'''
        
        req_file = self.root / 'requirements.txt'
        req_file.write_text(requirements)
        print_success("requirements.txt créé")
    
    def create_gitignore(self):
        """Crée ou met à jour le fichier .gitignore."""
        print_step("Création de .gitignore...")
        
        gitignore = '''# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# PyCharm
.idea/

# VS Code
.vscode/

# Virtual environments
venv/
env/
ENV/

# OS
.DS_Store
Thumbs.db

# Backup
backup_before_refactoring/

# Pytest
.pytest_cache/
.coverage
htmlcov/

# Logs
*.log
'''
        
        gitignore_file = self.root / '.gitignore'
        gitignore_file.write_text(gitignore)
        print_success(".gitignore créé")
    
    def update_readme(self):
        """Met à jour le README avec les nouvelles instructions."""
        print_step("Mise à jour du README...")
        
        readme = '''# Blue Prince - Projet POO 2025

Version simplifiée du jeu vidéo "Blue Prince" en Python avec Pygame.

## 🎯 Objectif

Atteindre l'Antichambre au sommet du manoir en gérant ses ressources (pas, clés, gemmes) et en choisissant stratégiquement les pièces à explorer.

## 📁 Structure du Projet

```
blue-prince/
├── models/              # Classes du modèle de données
│   ├── item.py         # Système d'objets (abstraction + héritage)
│   ├── inventory.py    # Inventaire du joueur
│   ├── door.py         # Système de portes
│   ├── room.py         # Catalogue de pièces
│   ├── player.py       # Joueur
│   └── manor.py        # Grille du manoir
├── managers/            # Logique métier
│   ├── random_manager.py      # Gestion de l'aléatoire
│   ├── interaction_manager.py # Interactions avec les objets
│   └── shop_manager.py        # Système de magasin
├── renderers/           # Interface graphique
│   ├── grid_renderer.py       # Affichage de la grille
│   ├── inventory_renderer.py  # Affichage de l'inventaire
│   └── room_selection_menu.py # Menu de sélection
├── utils/               # Utilitaires
│   └── resource_manager.py    # Gestion des ressources (polices, couleurs)
├── main.py             # Point d'entrée du jeu
├── requirements.txt    # Dépendances
└── README.md          # Ce fichier
```

## 🚀 Installation

### Prérequis

- Python 3.8 ou supérieur
- pip

### Installation des dépendances

```bash
# Cloner le repository
git clone <votre-repo-url>
cd blue-prince

# Installer les dépendances
pip install -r requirements.txt
```

## 🎮 Lancer le Jeu

```bash
python main.py
```

## 🕹️ Contrôles

- **ZQSD** : Se déplacer / Ouvrir les portes
- **1-9** : Interagir avec les objets de la pièce
- **← →** : Naviguer dans le menu de sélection de pièce
- **ENTRÉE** : Sélectionner une pièce
- **R** : Utiliser un dé pour retirer (pendant la sélection)
- **I** : Afficher l'inventaire (console)
- **ESC** : Quitter

## 📚 Architecture POO

### Abstraction

- `Item` : Classe abstraite de base pour tous les objets
- Méthode abstraite `use()` implémentée différemment selon les sous-classes

### Héritage

```
Item (abstract)
├── ConsumableItem (Steps, Keys, Gems, Coins, Dice)
├── PermanentItem (Shovel, Hammer, LockpickKit, etc.)
└── Food (Apple, Banana, Cake, Sandwich, Meal)
```

### Polymorphisme

Chaque type d'objet redéfinit `use()` avec son comportement spécifique:
- `Food.use()` : Restaure des pas
- `Keys.use()` : Ouvre une porte
- `PermanentItem.use()` : Effet passif

## 🎲 Fonctionnalités

### Fonctionnalités Principales

✅ Interface graphique Pygame  
✅ Déplacement dans un manoir 5x9  
✅ Système de portes verrouillées (3 niveaux)  
✅ Tirage aléatoire de pièces pondéré par rareté  
✅ Gestion de l'inventaire (pas, clés, gemmes, pièces, dés)  
✅ Objets permanents avec effets passifs  
✅ Système de nourriture  
✅ Conditions de victoire/défaite  

### Fonctionnalités Avancées

✅ Système de magasin  
✅ Coffres avec récompenses aléatoires  
✅ Pelle et zones à creuser  
✅ Effets spéciaux des pièces  
✅ Modificateurs de probabilité  

## 👨‍💻 Auteur

**Moss**  
Master 1 Systèmes Communicants  
Sorbonne Université  
2024-2025

## 📝 License

Projet académique - POO 2025
'''
        
        readme_file = self.root / 'README.md'
        readme_file.write_text(readme)
        print_success("README.md mis à jour")
    
    def verify_structure(self):
        """Vérifie que la nouvelle structure est correcte."""
        print_step("Vérification de la structure...")
        
        errors = []
        warnings = []
        
        # Vérifier les dossiers
        for directory in self.new_structure.keys():
            dir_path = self.root / directory
            if not dir_path.exists():
                errors.append(f"Dossier manquant: {directory}/")
            else:
                # Vérifier __init__.py
                init_file = dir_path / '__init__.py'
                if not init_file.exists():
                    warnings.append(f"__init__.py manquant dans {directory}/")
        
        # Vérifier les fichiers
        for directory, files in self.new_structure.items():
            for filename in files:
                file_path = self.root / directory / filename
                if not file_path.exists():
                    errors.append(f"Fichier manquant: {directory}/{filename}")
        
        # Vérifier main.py
        if not (self.root / 'main.py').exists():
            errors.append("main.py manquant à la racine")
        
        # Afficher les résultats
        if not errors and not warnings:
            print_success("✅ Structure vérifiée - Aucun problème détecté!")
            return True
        
        if warnings:
            for warning in warnings:
                print_warning(warning)
        
        if errors:
            for error in errors:
                print_error(error)
            return False
        
        return True
    
    def run(self):
        """Exécute le refactoring complet."""
        print("\n" + "="*70)
        print(f"{Colors.BLUE}🔧 REFACTORING DU PROJET BLUE PRINCE{Colors.END}")
        print("="*70)
        
        steps = [
            ("Sauvegarde", self.create_backup),
            ("Structure", self.create_directory_structure),
            ("Déplacement", self.move_files),
            ("Nettoyage", self.remove_obsolete_files),
            ("__init__.py", self.create_init_files),
            ("Imports", self.update_imports),
            ("requirements.txt", self.create_requirements_txt),
            (".gitignore", self.create_gitignore),
            ("README", self.update_readme),
            ("Vérification", self.verify_structure)
        ]
        
        for step_name, step_func in steps:
            try:
                result = step_func()
                if result is False:
                    print_error(f"Échec de l'étape: {step_name}")
                    return False
            except Exception as e:
                print_error(f"Erreur pendant {step_name}: {e}")
                import traceback
                traceback.print_exc()
                return False
        
        print("\n" + "="*70)
        print(f"{Colors.GREEN}✅ REFACTORING TERMINÉ AVEC SUCCÈS!{Colors.END}")
        print("="*70)
        print(f"\n📁 Sauvegarde disponible dans: {self.backup_dir}")
        print("\n🎯 Prochaines étapes:")
        print("  1. Tester le jeu: python main.py")
        print("  2. Vérifier que tout fonctionne")
        print("  3. Faire un commit Git")
        print("\n💡 Si problème: restaurer depuis backup_before_refactoring/")
        
        return True


def main():
    """Point d'entrée du script."""
    print(f"\n{Colors.BLUE}╔══════════════════════════════════════════════════════════╗{Colors.END}")
    print(f"{Colors.BLUE}║  SCRIPT DE REFACTORING - PROJET BLUE PRINCE             ║{Colors.END}")
    print(f"{Colors.BLUE}╚══════════════════════════════════════════════════════════╝{Colors.END}\n")
    
    print("Ce script va réorganiser votre projet:")
    print("  • Créer la structure models/, managers/, renderers/, utils/")
    print("  • Déplacer les fichiers aux bons emplacements")
    print("  • Mettre à jour tous les imports")
    print("  • Créer les __init__.py")
    print("  • Générer requirements.txt et .gitignore")
    print("  • Mettre à jour le README")
    
    print(f"\n{Colors.YELLOW}⚠️  Une sauvegarde sera créée avant toute modification{Colors.END}")
    
    response = input("\n✨ Voulez-vous continuer? (y/N): ")
    if response.lower() != 'y':
        print_error("Refactoring annulé.")
        return
    
    refactorer = ProjectRefactorer()
    success = refactorer.run()
    
    return 0 if success else 1


if __name__ == "__main__":
    import sys
    sys.exit(main())