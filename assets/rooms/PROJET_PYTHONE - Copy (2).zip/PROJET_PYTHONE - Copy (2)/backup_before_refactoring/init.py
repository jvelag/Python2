"""
Package models pour le jeu Blue Prince.
Contient toutes les classes du modèle de données.

Jour 1 : Objets et inventaire de base
"""

from item import Item, ConsumableItem, Steps, Keys, Gems, Coins
from inventory import Inventory
from door import Door
from room import Room, RoomColor



__all__ = [
    'Item',
    'ConsumableItem',
    'Steps',
    'Keys',
    'Gems',
    'Coins',
    'Inventory',
    'Door',
    'Room',
    'RoomColor'
    
]

__version__ = '0.1.0'
__author__ = 'mohand'