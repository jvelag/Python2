"""
Tests unitaires pour le Jour 2 du projet Blue Prince.

Ce fichier contient des tests pour vérifier le bon fonctionnement
des classes Door et Room ajoutées au Jour 2.
"""

import unittest
from door import Door
from room import Room, RoomColor
from inventory import Inventory


class MockPlayer:
    """Joueur factice pour les tests."""
    def __init__(self):
        self.inventory = Inventory()


class TestDoor(unittest.TestCase):
    """Tests pour la classe Door."""
    
    def setUp(self):
        """Préparation avant chaque test."""
        self.player = MockPlayer()
    
    def test_door_creation_unlocked(self):
        """Test de création d'une porte déverrouillée."""
        door = Door(Door.UNLOCKED)
        self.assertEqual(door.lock_level, Door.UNLOCKED)
        self.assertFalse(door.is_open)
    
    def test_door_creation_locked(self):
        """Test de création d'une porte verrouillée."""
        door = Door(Door.LOCKED)
        self.assertEqual(door.lock_level, Door.LOCKED)
        self.assertFalse(door.is_open)
    
    def test_door_creation_double_locked(self):
        """Test de création d'une porte doublement verrouillée."""
        door = Door(Door.DOUBLE_LOCKED)
        self.assertEqual(door.lock_level, Door.DOUBLE_LOCKED)
        self.assertFalse(door.is_open)
    
    def test_door_creation_invalid(self):
        """Test que la création avec un niveau invalide lève une erreur."""
        with self.assertRaises(ValueError):
            Door(99)
    
    def test_can_open_unlocked_door(self):
        """Test de vérification d'ouverture d'une porte déverrouillée."""
        door = Door(Door.UNLOCKED)
        can_open, msg = door.can_open(self.player)
        self.assertTrue(can_open)
        self.assertIn("unlocked", msg.lower())
    
    def test_can_open_locked_door_without_key(self):
        """Test de vérification d'une porte verrouillée sans clé."""
        door = Door(Door.LOCKED)
        can_open, msg = door.can_open(self.player)
        self.assertFalse(can_open)
        self.assertIn("key", msg.lower())
    
    def test_can_open_locked_door_with_key(self):
        """Test de vérification d'une porte verrouillée avec clé."""
        door = Door(Door.LOCKED)
        self.player.inventory.add_item("keys", 1)
        can_open, msg = door.can_open(self.player)
        self.assertTrue(can_open)
    
    def test_open_unlocked_door(self):
        """Test d'ouverture d'une porte déverrouillée."""
        door = Door(Door.UNLOCKED)
        result = door.open(self.player)
        self.assertTrue(result)
        self.assertTrue(door.is_open)
        self.assertEqual(self.player.inventory.keys.quantity, 0)
    
    def test_open_locked_door_with_key(self):
        """Test d'ouverture d'une porte verrouillée avec clé."""
        door = Door(Door.LOCKED)
        self.player.inventory.add_item("keys", 2)
        
        result = door.open(self.player)
        
        self.assertTrue(result)
        self.assertTrue(door.is_open)
        self.assertEqual(self.player.inventory.keys.quantity, 1)
    
    def test_open_locked_door_without_key(self):
        """Test d'ouverture d'une porte verrouillée sans clé."""
        door = Door(Door.LOCKED)
        result = door.open(self.player)
        
        self.assertFalse(result)
        self.assertFalse(door.is_open)
    
    def test_open_double_locked_door(self):
        """Test d'ouverture d'une porte doublement verrouillée."""
        door = Door(Door.DOUBLE_LOCKED)
        self.player.inventory.add_item("keys", 1)
        
        result = door.open(self.player)
        
        self.assertTrue(result)
        self.assertTrue(door.is_open)
        self.assertEqual(self.player.inventory.keys.quantity, 0)
    
    def test_close_door(self):
        """Test de fermeture d'une porte."""
        door = Door(Door.UNLOCKED)
        door.open(self.player)
        self.assertTrue(door.is_open)
        
        door.close()
        self.assertFalse(door.is_open)
    
    def test_get_lock_level_name(self):
        """Test de récupération du nom du niveau."""
        door1 = Door(Door.UNLOCKED)
        door2 = Door(Door.LOCKED)
        door3 = Door(Door.DOUBLE_LOCKED)
        
        self.assertEqual(door1.get_lock_level_name(), "Unlocked")
        self.assertEqual(door2.get_lock_level_name(), "Locked")
        self.assertEqual(door3.get_lock_level_name(), "Double-locked")
    
    def test_door_str_representation(self):
        """Test de la représentation textuelle."""
        door = Door(Door.LOCKED)
        str_repr = str(door)
        self.assertIn("Door", str_repr)
        self.assertIn("Locked", str_repr)


class TestRoom(unittest.TestCase):
    """Tests pour la classe Room."""
    
    def test_room_creation(self):
        """Test de création d'une pièce."""
        room = Room("Test Room", RoomColor.BLUE)
        self.assertEqual(room.name, "Test Room")
        self.assertEqual(room.color, RoomColor.BLUE)
        self.assertEqual(room.rarity, 0)
        self.assertEqual(room.gem_cost, 0)
        self.assertFalse(room.visited)
    
    def test_room_creation_with_rarity(self):
        """Test de création avec rareté."""
        room = Room("Rare Room", RoomColor.PURPLE, rarity=2, gem_cost=2)
        self.assertEqual(room.rarity, 2)
        self.assertEqual(room.gem_cost, 2)
    
    def test_room_creation_invalid_rarity(self):
        """Test que la création avec rareté invalide lève une erreur."""
        with self.assertRaises(ValueError):
            Room("Bad Room", RoomColor.BLUE, rarity=10)
    
    def test_room_creation_negative_gem_cost(self):
        """Test que la création avec coût négatif lève une erreur."""
        with self.assertRaises(ValueError):
            Room("Bad Room", RoomColor.BLUE, gem_cost=-1)
    
    def test_add_door(self):
        """Test d'ajout de porte."""
        room = Room("Test Room", RoomColor.BLUE)
        door = Door(Door.LOCKED)
        
        room.add_door("north", door)
        
        self.assertTrue(room.has_door("north"))
        self.assertEqual(room.get_door("north"), door)
    
    def test_add_door_invalid_direction(self):
        """Test que l'ajout d'une porte dans une direction invalide lève une erreur."""
        room = Room("Test Room", RoomColor.BLUE)
        door = Door(Door.LOCKED)
        
        with self.assertRaises(ValueError):
            room.add_door("diagonal", door)
    
    def test_get_available_directions(self):
        """Test de récupération des directions disponibles."""
        room = Room("Test Room", RoomColor.BLUE)
        room.add_door("north", Door())
        room.add_door("east", Door())
        
        directions = room.get_available_directions()
        
        self.assertEqual(len(directions), 2)
        self.assertIn("north", directions)
        self.assertIn("east", directions)
    
    def test_has_door(self):
        """Test de vérification de présence de porte."""
        room = Room("Test Room", RoomColor.BLUE)
        room.add_door("north", Door())
        
        self.assertTrue(room.has_door("north"))
        self.assertFalse(room.has_door("south"))
    
    def test_get_door_none(self):
        """Test de récupération d'une porte inexistante."""
        room = Room("Test Room", RoomColor.BLUE)
        door = room.get_door("north")
        self.assertIsNone(door)
    
    def test_add_item(self):
        """Test d'ajout d'objet."""
        room = Room("Test Room", RoomColor.BLUE)
        
        class MockItem:
            pass
        
        item = MockItem()
        room.add_item(item)
        
        self.assertEqual(len(room.items), 1)
        self.assertIn(item, room.items)
    
    def test_remove_item_success(self):
        """Test de retrait d'objet (succès)."""
        room = Room("Test Room", RoomColor.BLUE)
        
        class MockItem:
            pass
        
        item = MockItem()
        room.add_item(item)
        result = room.remove_item(item)
        
        self.assertTrue(result)
        self.assertEqual(len(room.items), 0)
    
    def test_remove_item_failure(self):
        """Test de retrait d'objet (échec - objet non présent)."""
        room = Room("Test Room", RoomColor.BLUE)
        
        class MockItem:
            pass
        
        item = MockItem()
        result = room.remove_item(item)
        
        self.assertFalse(result)
    
    def test_get_probability_weight(self):
        """Test du calcul du poids de probabilité."""
        room0 = Room("Common", RoomColor.BLUE, rarity=0)
        room1 = Room("Rare", RoomColor.YELLOW, rarity=1)
        room2 = Room("Epic", RoomColor.PURPLE, rarity=2)
        room3 = Room("Legendary", RoomColor.RED, rarity=3)
        
        self.assertAlmostEqual(room0.get_probability_weight(), 1.0)
        self.assertAlmostEqual(room1.get_probability_weight(), 1.0/3)
        self.assertAlmostEqual(room2.get_probability_weight(), 1.0/9)
        self.assertAlmostEqual(room3.get_probability_weight(), 1.0/27)
    
    def test_enter_room(self):
        """Test d'entrée dans une pièce."""
        room = Room("Test Room", RoomColor.BLUE)
        player = MockPlayer()
        
        self.assertFalse(room.visited)
        room.enter(player)
        self.assertTrue(room.visited)
    
    def test_get_rarity_name(self):
        """Test de récupération du nom de rareté."""
        room0 = Room("Test", RoomColor.BLUE, rarity=0)
        room1 = Room("Test", RoomColor.BLUE, rarity=1)
        room2 = Room("Test", RoomColor.BLUE, rarity=2)
        room3 = Room("Test", RoomColor.BLUE, rarity=3)
        
        self.assertEqual(room0.get_rarity_name(), "Common")
        self.assertEqual(room1.get_rarity_name(), "Rare")
        self.assertEqual(room2.get_rarity_name(), "Epic")
        self.assertEqual(room3.get_rarity_name(), "Legendary")
    
    def test_get_info(self):
        """Test de récupération des informations."""
        room = Room("Test Room", RoomColor.PURPLE, rarity=2, gem_cost=2)
        room.add_door("north", Door())
        
        info = room.get_info()
        
        self.assertEqual(info["name"], "Test Room")
        self.assertEqual(info["color"], "purple")
        self.assertEqual(info["rarity"], 2)
        self.assertEqual(info["gem_cost"], 2)
        self.assertFalse(info["visited"])
        self.assertIn("north", info["doors"])
    
    def test_room_colors(self):
        """Test de toutes les couleurs de pièces."""
        colors = [RoomColor.BLUE, RoomColor.YELLOW, RoomColor.GREEN,
                  RoomColor.PURPLE, RoomColor.ORANGE, RoomColor.RED]
        
        for color in colors:
            room = Room(f"{color.value} room", color)
            self.assertEqual(room.color, color)
    
    def test_room_str_representation(self):
        """Test de la représentation textuelle."""
        room = Room("Treasury", RoomColor.YELLOW, rarity=2, gem_cost=2)
        str_repr = str(room)
        
        self.assertIn("Treasury", str_repr)
        self.assertIn("yellow", str_repr)
        self.assertIn("Epic", str_repr)


class TestIntegration(unittest.TestCase):
    """Tests d'intégration entre Door et Room."""
    
    def test_room_with_multiple_doors(self):
        """Test d'une pièce avec plusieurs portes."""
        room = Room("Central Hall", RoomColor.BLUE)
        
        room.add_door("north", Door(Door.UNLOCKED))
        room.add_door("south", Door(Door.LOCKED))
        room.add_door("east", Door(Door.DOUBLE_LOCKED))
        room.add_door("west", Door(Door.UNLOCKED))
        
        self.assertEqual(len(room.get_available_directions()), 4)
        
        # Vérifier que chaque porte a le bon niveau
        self.assertEqual(room.get_door("north").lock_level, Door.UNLOCKED)
        self.assertEqual(room.get_door("south").lock_level, Door.LOCKED)
        self.assertEqual(room.get_door("east").lock_level, Door.DOUBLE_LOCKED)
        self.assertEqual(room.get_door("west").lock_level, Door.UNLOCKED)
    
    def test_player_opens_doors_in_room(self):
        """Test d'un joueur qui ouvre des portes dans une pièce."""
        player = MockPlayer()
        player.inventory.add_item("keys", 3)
        
        room = Room("Test Room", RoomColor.BLUE)
        room.add_door("north", Door(Door.LOCKED))
        room.add_door("east", Door(Door.LOCKED))
        
        # Ouvrir la porte nord
        door_north = room.get_door("north")
        success = door_north.open(player)
        self.assertTrue(success)
        self.assertEqual(player.inventory.keys.quantity, 2)
        
        # Ouvrir la porte est
        door_east = room.get_door("east")
        success = door_east.open(player)
        self.assertTrue(success)
        self.assertEqual(player.inventory.keys.quantity, 1)
    
    def test_complete_scenario(self):
        """Test d'un scénario complet avec pièces et portes."""
        player = MockPlayer()
        player.inventory.add_item("keys", 2)
        
        # Créer deux pièces
        room1 = Room("Entrance", RoomColor.BLUE, rarity=0)
        room2 = Room("Treasure Room", RoomColor.YELLOW, rarity=2, gem_cost=2)
        
        # Ajouter des portes
        room1.add_door("north", Door(Door.LOCKED))
        room2.add_door("south", Door(Door.LOCKED))
        
        # Le joueur entre dans la première pièce
        room1.enter(player)
        self.assertTrue(room1.visited)
        
        # Le joueur ouvre la porte nord
        door = room1.get_door("north")
        success = door.open(player)
        self.assertTrue(success)
        self.assertEqual(player.inventory.keys.quantity, 1)
        
        # Le joueur entre dans la deuxième pièce
        room2.enter(player)
        self.assertTrue(room2.visited)


def run_tests():
    """Exécute tous les tests et affiche les résultats."""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    suite.addTests(loader.loadTestsFromTestCase(TestDoor))
    suite.addTests(loader.loadTestsFromTestCase(TestRoom))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "=" * 70)
    if result.wasSuccessful():
        print("✅ TOUS LES TESTS SONT PASSÉS")
    else:
        print("❌ CERTAINS TESTS ONT ÉCHOUÉ")
    print(f"Tests exécutés : {result.testsRun}")
    print(f"Succès : {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Échecs : {len(result.failures)}")
    print(f"Erreurs : {len(result.errors)}")
    print("=" * 70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)