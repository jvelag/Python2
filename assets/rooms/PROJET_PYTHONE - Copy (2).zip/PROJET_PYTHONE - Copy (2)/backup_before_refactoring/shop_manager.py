"""
Gestionnaire des magasins.
Permet d'échanger de l'or contre des objets.
"""

class ShopManager:
    """Gère les interactions avec les magasins."""
    
    def __init__(self, player):
        self.player = player
        
        # Catalogue de vente standard
        self.shop_catalog = {
            'key': {'price': 10, 'emoji': '🔑'},
            'gem': {'price': 25, 'emoji': '💎'},
            'dice': {'price': 15, 'emoji': '🎲'},
            'steps_pack': {'price': 5, 'emoji': '👣', 'quantity': 10}
        }
    
    def can_buy(self, item_name: str) -> bool:
        """Vérifie si le joueur peut acheter."""
        if item_name not in self.shop_catalog:
            return False
        price = self.shop_catalog[item_name]['price']
        return self.player.inventory.coins.quantity >= price
    
    def buy_item(self, item_name: str) -> bool:
        """Achète un objet du magasin."""
        if not self.can_buy(item_name):
            print("💰 Pas assez de pièces!")
            return False
        
        item_info = self.shop_catalog[item_name]
        price = item_info['price']
        emoji = item_info['emoji']
        
        # Dépense l'or
        self.player.inventory.coins.remove(price)
        
        # Donne l'objet
        if item_name == 'key':
            self.player.inventory.add_item('keys', 1)
        elif item_name == 'gem':
            self.player.inventory.add_item('gems', 1)
        elif item_name == 'dice':
            self.player.inventory.add_item('dice', 1)
        elif item_name == 'steps_pack':
            quantity = item_info['quantity']
            self.player.inventory.add_item('steps', quantity)
        
        print(f"{emoji} Acheté pour {price} pièces!")
        return True
    
    def display_shop(self):
        """Affiche le catalogue du magasin."""
        print("\n🏪 MAGASIN")
        print("=" * 50)
        for item_name, info in self.shop_catalog.items():
            price = info['price']
            emoji = info['emoji']
            can_afford = "✅" if self.can_buy(item_name) else "❌"
            print(f"{can_afford} {emoji} {item_name}: {price} pièces")
        print("=" * 50)