"""
Module définissant les objets du jeu Blue Prince.

Jour 7 : Système complet d'objets avec consommables, permanents et nourriture.

Ce module implémente le système d'objets du jeu en utilisant :
- L'abstraction (classe abstraite Item)
- L'héritage (ConsumableItem, PermanentItem, Food)
- Le polymorphisme (méthode use() redéfinie)
"""

from abc import ABC, abstractmethod


class Item(ABC):
    """Classe abstraite représentant un objet du jeu.
    
    Attributes:
        name (str): Le nom de l'objet
        description (str): Une description de l'objet
    """
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    
    @abstractmethod
    def use(self, player):
        """Méthode abstraite pour utiliser l'objet.
        
        Args:
            player: Le joueur qui utilise l'objet
            
        Returns:
            bool: True si l'utilisation a réussi, False sinon
        """
        pass
    
    def __str__(self):
        """Représentation textuelle de l'objet."""
        return f"{self.name}: {self.description}"
    
    def __repr__(self):
        """Représentation pour le débogage."""
        return f"{self.__class__.__name__}(name='{self.name}')"


class ConsumableItem(Item):
    """Objet consommable qui disparaît après utilisation.
    
    Attributes:
        quantity (int): La quantité disponible de cet objet
    """
    
    def __init__(self, name: str, description: str, quantity: int = 1):
        """
        Initialise un objet consommable.
        
        Args:
            name: Le nom de l'objet
            description: La description de l'objet
            quantity: La quantité initiale (par défaut 1)
        """
        super().__init__(name, description)
        self.quantity = quantity
    
    def add(self, amount: int):
        """Ajoute une quantité.
        
        Args:
            amount: La quantité à ajouter (doit être positive)
            
        Raises:
            ValueError: Si amount est négatif
        """
        if amount < 0:
            raise ValueError("Cannot add negative amount")
        self.quantity += amount
    
    def remove(self, amount: int) -> bool:
        """
        Retire une quantité de l'objet si possible.
        
        Args:
            amount: La quantité à retirer
            
        Returns:
            bool: True si la quantité a été retirée, False sinon.
        """
        if amount < 0:
            raise ValueError("Cannot remove negative amount")
        
        if self.quantity >= amount:
            self.quantity -= amount
            return True
        return False
    
    def use(self, player):
        """
        Utilise une unité de l'objet.
        
        Implémentation par défaut qui retire 1 de la quantité.
        Peut être surchargée dans les sous-classes pour des comportements spécifiques.
        
        Args:
            player: Le joueur qui utilise l'objet
            
        Returns:
            bool: True si l'utilisation a réussi, False sinon.
        """
        return self.remove(1)
    
    def __str__(self):
        """Représentation textuelle incluant la quantité."""
        return f"{self.name}: {self.description} (x{self.quantity})"


class PermanentItem(Item):
    """Objet permanent qui reste dans l'inventaire.
    
    Attributes:
        effect_description (str): Description de l'effet de l'objet
    """
    
    def __init__(self, name: str, description: str, effect_description: str = ""):
        """
        Initialise un objet permanent.
        
        Args:
            name: Le nom de l'objet
            description: La description de l'objet
            effect_description: Description de l'effet spécial
        """
        super().__init__(name, description)
        self.effect_description = effect_description
    
    def use(self, player):
        """
        Utilise l'objet permanent.
        
        Les objets permanents ont généralement des effets passifs
        mais peuvent aussi avoir des utilisations activables.
        
        Args:
            player: Le joueur qui utilise l'objet
            
        Returns:
            bool: True si l'effet a été appliqué, False sinon
        """
        # Les objets permanents retournent toujours True car ils ne sont pas consommés
        return True
    
    def __str__(self):
        """Représentation textuelle avec effet."""
        if self.effect_description:
            return f"{self.name}: {self.description} - {self.effect_description}"
        return super().__str__()


class Food(Item):
    """Nourriture qui restaure des pas.
    
    Attributes:
        steps_restored (int): Nombre de pas restaurés
    """
    
    def __init__(self, name: str, steps_restored: int):
        """
        Initialise un objet nourriture.
        
        Args:
            name: Le nom de la nourriture
            steps_restored: Nombre de pas restaurés lors de l'utilisation
        """
        description = f"Restores {steps_restored} steps"
        super().__init__(name, description)
        self.steps_restored = steps_restored
    
    def use(self, player):
        """
        Consomme la nourriture et restaure des pas.
        
        Args:
            player: Le joueur qui mange la nourriture
            
        Returns:
            bool: True si la nourriture a été consommée, False sinon
        """
        if hasattr(player, 'inventory') and hasattr(player.inventory, 'steps'):
            player.inventory.steps.add(self.steps_restored)
            return True
        return False


# ============================================================================
# CLASSES SPÉCIFIQUES - RESSOURCES DE BASE
# ============================================================================

class Steps(ConsumableItem):
    """Représente les pas du joueur.
    
    Les pas sont la ressource principale du jeu. Chaque déplacement
    consomme un pas. Le jeu se termine quand le joueur n'a plus de pas.
    
    Quantité initiale : 70 pas
    """
    
    def __init__(self, quantity: int = 70):
        super().__init__(
            name="Steps",
            description="Steps remaining to explore the manor",
            quantity=quantity
        )
    
    def use(self, player):
        """
        Utilise un pas (lors d'un déplacement).
        
        Args:
            player: Le joueur qui se déplace
            
        Returns:
            bool: True si un pas a été consommé, False si plus de pas
        """
        if self.quantity > 0:
            return self.remove(1)
        return False


class Keys(ConsumableItem):
    """Représente les clés pour ouvrir les portes.
    
    Les clés sont nécessaires pour ouvrir les portes verrouillées.
    Une clé est consommée à chaque ouverture de porte.
    
    Quantité initiale : 0 clés
    """
    
    def __init__(self, quantity: int = 0):
        super().__init__(
            name="Keys",
            description="Keys to open locked doors",
            quantity=quantity
        )
    
    def use(self, player):
        """
        Utilise une clé pour ouvrir une porte.
        
        Args:
            player: Le joueur qui ouvre la porte
            
        Returns:
            bool: True si une clé a été utilisée, False si pas de clé
        """
        if self.quantity > 0:
            return self.remove(1)
        return False


class Gems(ConsumableItem):
    """Représente les gemmes pour sélectionner des pièces spéciales.
    
    Les gemmes permettent de choisir des pièces rares lors de la sélection.
    Plus une pièce est rare, plus elle coûte de gemmes.
    
    Quantité initiale : 2 gemmes
    """
    
    def __init__(self, quantity: int = 2):
        super().__init__(
            name="Gems",
            description="Gems to select special rooms",
            quantity=quantity
        )
    
    def use(self, player):
        """
        Utilise une gemme pour choisir une pièce rare.
        
        Args:
            player: Le joueur qui utilise la gemme
            
        Returns:
            bool: True si une gemme a été utilisée, False sinon
        """
        if self.quantity > 0:
            return self.remove(1)
        return False


class Coins(ConsumableItem):
    """Représente les pièces d'or collectées.
    
    Les pièces sont collectées dans les coffres et autres sources.
    Elles servent de score et peuvent être utilisées pour des bonus.
    
    Quantité initiale : 0 pièces
    """
    
    def __init__(self, quantity: int = 0):
        super().__init__(
            name="Coins",
            description="Gold coins collected",
            quantity=quantity
        )
    
    def use(self, player):
        """
        Utilise des pièces (pour des achats futurs).
        
        Args:
            player: Le joueur qui utilise les pièces
            
        Returns:
            bool: True si une pièce a été utilisée, False sinon
        """
        if self.quantity > 0:
            return self.remove(1)
        return False


class Dice(ConsumableItem):
    """Représente les dés pour relancer la sélection de pièces.
    
    Les dés permettent de relancer les pièces proposées lors de la sélection.
    
    Quantité initiale : 0 dés
    """
    
    def __init__(self, quantity: int = 0):
        super().__init__(
            name="Dice",
            description="Reroll room selection",
            quantity=quantity
        )


# ============================================================================
# CLASSES SPÉCIFIQUES - OBJETS PERMANENTS
# ============================================================================

class Shovel(PermanentItem):
    """Pelle pour creuser dans les endroits spéciaux."""
    
    def __init__(self):
        super().__init__(
            name="Shovel",
            description="Allows digging in special spots",
            effect_description="Use to dig and find hidden treasures"
        )


class Hammer(PermanentItem):
    """Marteau pour ouvrir les coffres sans clés."""
    
    def __init__(self):
        super().__init__(
            name="Hammer",
            description="Opens chests without keys",
            effect_description="Break chest locks instantly"
        )


class LockpickKit(PermanentItem):
    """Kit de crochetage pour ouvrir les portes verrouillées de niveau 1."""
    
    def __init__(self):
        super().__init__(
            name="Lockpick Kit",
            description="Opens level 1 locked doors without keys",
            effect_description="Bypass simple locks"
        )


class MetalDetector(PermanentItem):
    """Détecteur de métaux pour améliorer la qualité du butin."""
    
    def __init__(self):
        super().__init__(
            name="Metal Detector",
            description="Increases chance of finding keys and coins",
            effect_description="Improves loot quality"
        )


class RabbitFoot(PermanentItem):
    """Patte de lapin porte-bonheur pour augmenter la chance."""
    
    def __init__(self):
        super().__init__(
            name="Lucky Rabbit's Foot",
            description="Increases overall luck",
            effect_description="Reduces empty loot chances"
        )


# ✅ AJOUT: NOUVEAUX OBJETS PERMANENTS
class Compass(PermanentItem):
    """Boussole : révèle les pièces adjacentes."""
    
    def __init__(self):
        super().__init__(
            name="Compass",
            description="Reveals adjacent rooms",
            effect_description="See what's around you"
        )


class Map(PermanentItem):
    """Carte : affiche la grille complète."""
    
    def __init__(self):
        super().__init__(
            name="Map",
            description="Shows the complete manor grid",
            effect_description="Full manor visibility"
        )


class Torch(PermanentItem):
    """Torche : réduit le coût en pas."""
    
    def __init__(self):
        super().__init__(
            name="Torch",
            description="Reduces step cost by 1",
            effect_description="Light your path"
        )


class Spyglass(PermanentItem):
    """Longue-vue : révèle les pièces à distance."""
    
    def __init__(self):
        super().__init__(
            name="Spyglass",
            description="Reveals rooms from a distance",
            effect_description="See further ahead"
        )


class Hourglass(PermanentItem):
    """Sablier : donne du temps supplémentaire."""
    
    def __init__(self):
        super().__init__(
            name="Hourglass",
            description="Grants extra steps occasionally",
            effect_description="Time is on your side"
        )


# ============================================================================
# CLASSES SPÉCIFIQUES - NOURRITURE
# ============================================================================

class Apple(Food):
    """Pomme qui restaure 2 pas."""
    
    def __init__(self):
        super().__init__("Apple", 2)


class Banana(Food):
    """Banane qui restaure 3 pas."""
    
    def __init__(self):
        super().__init__("Banana", 3)


class Cake(Food):
    """Gâteau qui restaure 10 pas."""
    
    def __init__(self):
        super().__init__("Cake", 10)


class Sandwich(Food):
    """Sandwich qui restaure 15 pas."""
    
    def __init__(self):
        super().__init__("Sandwich", 15)


class Meal(Food):
    """Repas complet qui restaure 25 pas."""
    
    def __init__(self):
        super().__init__("Full Meal", 25)


# ============================================================================
# TESTS DU MODULE
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("TEST DU MODULE ITEM - JOUR 7 (AVEC NOUVEAUX OBJETS)")
    print("=" * 70)
    
    # Test 1 : Création d'objets de base
    print("\nTest 1 : Création d'objets de base")
    print("-" * 70)
    steps = Steps(70)
    keys = Keys(0)
    gems = Gems(2)
    coins = Coins(0)
    dice = Dice(0)
    
    print(f"✓ {steps}")
    print(f"✓ {keys}")
    print(f"✓ {gems}")
    print(f"✓ {coins}")
    print(f"✓ {dice}")
    
    # Test 2 : Création d'objets permanents
    print("\nTest 2 : Création d'objets permanents")
    print("-" * 70)
    shovel = Shovel()
    hammer = Hammer()
    lockpick = LockpickKit()
    detector = MetalDetector()
    rabbit_foot = RabbitFoot()
    compass = Compass()
    map_item = Map()
    torch = Torch()
    spyglass = Spyglass()
    hourglass = Hourglass()
    
    print(f"✓ {shovel}")
    print(f"✓ {hammer}")
    print(f"✓ {lockpick}")
    print(f"✓ {detector}")
    print(f"✓ {rabbit_foot}")
    print(f"✓ {compass}")
    print(f"✓ {map_item}")
    print(f"✓ {torch}")
    print(f"✓ {spyglass}")
    print(f"✓ {hourglass}")
    
    # Test 3 : Création de nourriture
    print("\nTest 3 : Création de nourriture")
    print("-" * 70)
    apple = Apple()
    banana = Banana()
    cake = Cake()
    sandwich = Sandwich()
    meal = Meal()
    
    print(f"✓ {apple}")
    print(f"✓ {banana}")
    print(f"✓ {cake}")
    print(f"✓ {sandwich}")
    print(f"✓ {meal}")
    
    # Test 4 : Gestion des quantités
    print("\nTest 4 : Gestion des quantités")
    print("-" * 70)
    keys.add(5)
    coins.add(100)
    dice.add(3)
    
    print(f"✓ Ajout de 5 clés : {keys}")
    print(f"✓ Ajout de 100 pièces : {coins}")
    print(f"✓ Ajout de 3 dés : {dice}")
    
    # Test 5 : Utilisation d'objets
    print("\nTest 5 : Utilisation d'objets")
    print("-" * 70)
    
    class MockPlayer:
        """Joueur factice pour les tests."""
        def __init__(self):
            self.inventory = MockInventory()
    
    class MockInventory:
        """Inventaire factice pour les tests."""
        def __init__(self):
            self.steps = Steps(50)
    
    player = MockPlayer()
    
    # Utiliser un pas
    success = steps.use(player)
    print(f"✓ Utilisation d'un pas : {success} → {steps}")
    
    # Utiliser une clé
    success = keys.use(player)
    print(f"✓ Utilisation d'une clé : {success} → {keys}")
    
    # Utiliser un objet permanent
    success = compass.use(player)
    print(f"✓ Utilisation de la boussole : {success}")
    
    # Utiliser de la nourriture
    print(f"✓ Pas avant nourriture : {player.inventory.steps}")
    success = apple.use(player)
    print(f"✓ Utilisation d'une pomme : {success}")
    print(f"✓ Pas après nourriture : {player.inventory.steps}")
    
    # Test 6 : Vérification des nouveaux objets
    print("\nTest 6 : Vérification des nouveaux objets")
    print("-" * 70)
    print(f"✓ Boussole : {compass.name} - {compass.effect_description}")
    print(f"✓ Carte : {map_item.name} - {map_item.effect_description}")
    print(f"✓ Torche : {torch.name} - {torch.effect_description}")
    print(f"✓ Longue-vue : {spyglass.name} - {spyglass.effect_description}")
    print(f"✓ Sablier : {hourglass.name} - {hourglass.effect_description}")
    
    print("\n" + "=" * 70)
    print("✅ TOUS LES TESTS SONT PASSÉS - NOUVEAUX OBJETS AJOUTÉS")
    print("=" * 70)