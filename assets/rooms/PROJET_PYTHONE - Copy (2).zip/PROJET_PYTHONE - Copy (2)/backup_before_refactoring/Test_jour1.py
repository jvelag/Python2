"""
Tests unitaires pour le Jour 1 du projet Blue Prince.

Ce fichier contient des tests pour vérifier le bon fonctionnement
des classes Item, ConsumableItem et Inventory.
"""

import unittest
from item import Item, ConsumableItem, Steps, Keys, Gems, Coins
from inventory import Inventory


class TestItem(unittest.TestCase):
    """Tests pour la classe Item et ses sous-classes."""
    
    def test_steps_creation(self):
        """Test de création d'un objet Steps."""
        steps = Steps(70)
        self.assertEqual(steps.quantity, 70)
        self.assertEqual(steps.name, "Steps")
    
    def test_keys_creation(self):
        """Test de création d'un objet Keys."""
        keys = Keys(5)
        self.assertEqual(keys.quantity, 5)
        self.assertEqual(keys.name, "Keys")
    
    def test_gems_creation(self):
        """Test de création d'un objet Gems."""
        gems = Gems(2)
        self.assertEqual(gems.quantity, 2)
        self.assertEqual(gems.name, "Gems")
    
    def test_coins_creation(self):
        """Test de création d'un objet Coins."""
        coins = Coins(100)
        self.assertEqual(coins.quantity, 100)
        self.assertEqual(coins.name, "Coins")
    
    def test_add_quantity(self):
        """Test d'ajout de quantité."""
        keys = Keys(5)
        keys.add(10)
        self.assertEqual(keys.quantity, 15)
    
    def test_remove_quantity_success(self):
        """Test de retrait de quantité (succès)."""
        keys = Keys(10)
        result = keys.remove(5)
        self.assertTrue(result)
        self.assertEqual(keys.quantity, 5)
    
    def test_remove_quantity_failure(self):
        """Test de retrait de quantité (échec - quantité insuffisante)."""
        keys = Keys(5)
        result = keys.remove(10)
        self.assertFalse(result)
        self.assertEqual(keys.quantity, 5)  # Quantité inchangée
    
    def test_use_consumable(self):
        """Test d'utilisation d'un objet consommable."""
        keys = Keys(3)
        
        class MockPlayer:
            pass
        
        player = MockPlayer()
        result = keys.use(player)
        
        self.assertTrue(result)
        self.assertEqual(keys.quantity, 2)
    
    def test_add_negative_raises_error(self):
        """Test que l'ajout d'une quantité négative lève une erreur."""
        keys = Keys(5)
        with self.assertRaises(ValueError):
            keys.add(-5)
    
    def test_remove_negative_raises_error(self):
        """Test que le retrait d'une quantité négative lève une erreur."""
        keys = Keys(5)
        with self.assertRaises(ValueError):
            keys.remove(-5)
    
    def test_item_str_representation(self):
        """Test de la représentation textuelle d'un objet."""
        steps = Steps(70)
        self.assertIn("Steps", str(steps))
        self.assertIn("70", str(steps))


class TestInventory(unittest.TestCase):
    """Tests pour la classe Inventory."""
    
    def test_inventory_creation(self):
        """Test de création d'inventaire avec valeurs par défaut."""
        inv = Inventory()
        self.assertEqual(inv.steps.quantity, 70)
        self.assertEqual(inv.keys.quantity, 0)
        self.assertEqual(inv.gems.quantity, 2)
        self.assertEqual(inv.coins.quantity, 0)
    
    def test_add_item_keys(self):
        """Test d'ajout de clés."""
        inv = Inventory()
        inv.add_item("keys", 5)
        self.assertEqual(inv.keys.quantity, 5)
    
    def test_add_item_coins(self):
        """Test d'ajout de pièces."""
        inv = Inventory()
        inv.add_item("coins", 100)
        self.assertEqual(inv.coins.quantity, 100)
    
    def test_add_item_gems(self):
        """Test d'ajout de gemmes."""
        inv = Inventory()
        inv.add_item("gems", 3)
        self.assertEqual(inv.gems.quantity, 5)  # 2 + 3
    
    def test_add_item_steps(self):
        """Test d'ajout de pas."""
        inv = Inventory()
        inv.add_item("steps", 10)
        self.assertEqual(inv.steps.quantity, 80)  # 70 + 10
    
    def test_remove_item_success(self):
        """Test de retrait d'objet (succès)."""
        inv = Inventory()
        inv.add_item("keys", 5)
        result = inv.remove_item("keys", 2)
        self.assertTrue(result)
        self.assertEqual(inv.keys.quantity, 3)
    
    def test_remove_item_failure(self):
        """Test de retrait d'objet (échec - quantité insuffisante)."""
        inv = Inventory()
        inv.add_item("keys", 5)
        result = inv.remove_item("keys", 10)
        self.assertFalse(result)
        self.assertEqual(inv.keys.quantity, 5)  # Inchangé
    
    def test_get_quantity(self):
        """Test de récupération de quantité."""
        inv = Inventory()
        inv.add_item("coins", 50)
        quantity = inv.get_quantity("coins")
        self.assertEqual(quantity, 50)
    
    def test_has_item_true(self):
        """Test de vérification de présence d'objet (True)."""
        inv = Inventory()
        inv.add_item("keys", 5)
        self.assertTrue(inv.has_item("keys", 3))
    
    def test_has_item_false(self):
        """Test de vérification de présence d'objet (False)."""
        inv = Inventory()
        inv.add_item("keys", 5)
        self.assertFalse(inv.has_item("keys", 10))
    
    def test_get_summary(self):
        """Test de récupération du résumé."""
        inv = Inventory()
        inv.add_item("keys", 3)
        inv.add_item("coins", 50)
        
        summary = inv.get_summary()
        
        self.assertEqual(summary['steps'], 70)
        self.assertEqual(summary['keys'], 3)
        self.assertEqual(summary['gems'], 2)
        self.assertEqual(summary['coins'], 50)
    
    def test_add_unknown_item_raises_error(self):
        """Test que l'ajout d'un objet inconnu lève une erreur."""
        inv = Inventory()
        with self.assertRaises(ValueError):
            inv.add_item("unknown_item", 5)
    
    def test_remove_unknown_item_raises_error(self):
        """Test que le retrait d'un objet inconnu lève une erreur."""
        inv = Inventory()
        with self.assertRaises(ValueError):
            inv.remove_item("unknown_item", 5)
    
    def test_get_quantity_unknown_item_raises_error(self):
        """Test que la récupération d'un objet inconnu lève une erreur."""
        inv = Inventory()
        with self.assertRaises(ValueError):
            inv.get_quantity("unknown_item")
    
    def test_add_negative_quantity_raises_error(self):
        """Test que l'ajout d'une quantité négative lève une erreur."""
        inv = Inventory()
        with self.assertRaises(ValueError):
            inv.add_item("keys", -5)
    
    def test_remove_negative_quantity_raises_error(self):
        """Test que le retrait d'une quantité négative lève une erreur."""
        inv = Inventory()
        with self.assertRaises(ValueError):
            inv.remove_item("keys", -5)
    
    def test_case_insensitive_item_names(self):
        """Test que les noms d'objets ne sont pas sensibles à la casse."""
        inv = Inventory()
        inv.add_item("KEYS", 5)
        inv.add_item("Keys", 3)
        inv.add_item("keys", 2)
        self.assertEqual(inv.keys.quantity, 10)


class TestGameScenario(unittest.TestCase):
    """Tests de scénarios de jeu complets."""
    
    def test_complete_game_scenario(self):
        """Test d'un scénario de jeu complet."""
        # Création de l'inventaire
        inv = Inventory()
        
        # Le joueur commence avec les ressources de base
        self.assertEqual(inv.steps.quantity, 70)
        self.assertEqual(inv.keys.quantity, 0)
        self.assertEqual(inv.gems.quantity, 2)
        self.assertEqual(inv.coins.quantity, 0)
        
        # Le joueur trouve un coffre avec des clés et des pièces
        inv.add_item("keys", 3)
        inv.add_item("coins", 50)
        
        # Le joueur ouvre une porte (utilise 1 clé)
        result = inv.remove_item("keys", 1)
        self.assertTrue(result)
        self.assertEqual(inv.keys.quantity, 2)
        
        # Le joueur fait plusieurs déplacements (utilise 5 pas)
        for _ in range(5):
            result = inv.remove_item("steps", 1)
            self.assertTrue(result)
        self.assertEqual(inv.steps.quantity, 65)
        
        # Le joueur utilise une gemme pour une pièce rare
        result = inv.remove_item("gems", 1)
        self.assertTrue(result)
        self.assertEqual(inv.gems.quantity, 1)
        
        # Vérification de l'état final
        summary = inv.get_summary()
        self.assertEqual(summary['steps'], 65)
        self.assertEqual(summary['keys'], 2)
        self.assertEqual(summary['gems'], 1)
        self.assertEqual(summary['coins'], 50)
    
    def test_running_out_of_steps(self):
        """Test du scénario où le joueur épuise ses pas."""
        inv = Inventory()
        
        # Le joueur utilise tous ses pas
        for _ in range(70):
            result = inv.remove_item("steps", 1)
            self.assertTrue(result)
        
        # Le joueur n'a plus de pas
        self.assertEqual(inv.steps.quantity, 0)
        
        # Tentative d'utilisation d'un pas supplémentaire (échec)
        result = inv.remove_item("steps", 1)
        self.assertFalse(result)


def run_tests():
    """Exécute tous les tests et affiche les résultats."""
    # Création de la suite de tests
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Ajout des tests
    suite.addTests(loader.loadTestsFromTestCase(TestItem))
    suite.addTests(loader.loadTestsFromTestCase(TestInventory))
    suite.addTests(loader.loadTestsFromTestCase(TestGameScenario))
    
    # Exécution des tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Affichage du résumé
    print("\n" + "=" * 70)
    if result.wasSuccessful():
        print("TOUS LES TESTS SONT PASSÉS")
    else:
        print("CERTAINS TESTS ONT ÉCHOUÉ")
    print(f"Tests exécutés : {result.testsRun}")
    print(f"Succès : {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Échecs : {len(result.failures)}")
    print(f"Erreurs : {len(result.errors)}")
    print("=" * 70)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)