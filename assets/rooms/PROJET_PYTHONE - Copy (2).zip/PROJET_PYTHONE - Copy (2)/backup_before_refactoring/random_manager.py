"""
Gestionnaire de l'aléatoire.
Jour 4 : Tirage de pièces et génération de portes.
"""

import random
from door import Door


class RandomManager:
    """Gère tous les aspects aléatoires du jeu."""
    
    def __init__(self):
        # Modificateurs de probabilité par couleur
        self.color_modifiers = {
            'green': 1.0,
            'red': 1.0,
            'yellow': 1.0,
            'blue': 1.0,
            'purple': 1.0,
            'orange': 1.0
        }
    
    def apply_color_boost(self, color: str, multiplier: float = 2.0):
        """Augmente la probabilité de tirer une couleur."""
        if color in self.color_modifiers:
            self.color_modifiers[color] = multiplier
            print(f"📊 Probabilité de {color} multipliée par {multiplier}")
        else:
            print(f"⚠️ Couleur {color} inconnue pour le boost")
    
    def reset_color_boost(self, color: str):
        """Remet la probabilité normale."""
        if color in self.color_modifiers:
            self.color_modifiers[color] = 1.0
            print(f"📊 Probabilité de {color} remise à la normale")
    
    def reset_all_boosts(self):
        """Remet toutes les probabilités à la normale."""
        for color in self.color_modifiers:
            self.color_modifiers[color] = 1.0
        print("📊 Tous les boosts de couleur ont été réinitialisés")
    
    def get_color_modifier(self, color: str) -> float:
        """Retourne le modificateur actuel pour une couleur."""
        return self.color_modifiers.get(color, 1.0)
    
    def get_boosted_colors(self) -> list:
        """Retourne la liste des couleurs actuellement boostées."""
        return [color for color, modifier in self.color_modifiers.items() if modifier > 1.0]
    
    @staticmethod
    def get_door_lock_level(row: int, max_rows: int) -> int:
        """
        Détermine le niveau de verrouillage selon la position.
        Plus on monte, plus les portes sont verrouillées.
        """
        # Première rangée : toujours déverrouillé
        if row == max_rows - 1:
            return Door.UNLOCKED
        
        # Dernière rangée : toujours double verrouillage
        if row == 0:
            return Door.DOUBLE_LOCKED
        
        # Rangées intermédiaires : probabilité progressive
        progress = (max_rows - row) / max_rows
        rand = random.random()
        
        if rand < progress * 0.3:
            return Door.DOUBLE_LOCKED
        elif rand < progress * 0.6:
            return Door.LOCKED
        else:
            return Door.UNLOCKED
    
    def draw_rooms(self, available_rooms: list, count: int = 3) -> list:
        """
        Tire des pièces au hasard en tenant compte de la rareté et des boosts de couleur.
        """
        if not available_rooms:
            return []
        
        # ✅ CORRECTION: Calcule les poids avec modificateurs de couleur
        weights = []
        for room in available_rooms:
            base_weight = room.get_probability_weight()
            color_modifier = self.color_modifiers.get(room.color.value, 1.0)
            final_weight = base_weight * color_modifier
            weights.append(final_weight)
        
        # Tire les pièces avec pondération
        drawn = random.choices(
            available_rooms,
            weights=weights,
            k=min(count, len(available_rooms))
        )
        
        # S'assure qu'au moins une pièce coûte 0 gemmes
        has_free = any(room.gem_cost == 0 for room in drawn)
        if not has_free:
            free_rooms = [r for r in available_rooms if r.gem_cost == 0]
            if free_rooms:
                drawn[0] = random.choice(free_rooms)
        
        # Debug: affiche les boosts actifs
        boosted_colors = self.get_boosted_colors()
        if boosted_colors:
            print(f"🎨 Couleurs boostées: {', '.join(boosted_colors)}")
        
        return drawn
    
    @staticmethod
    def get_random_loot(loot_type: str = "chest") -> dict:
        """Génère un butin aléatoire."""
        loot_tables = {
            "chest": [
                {"coins": 20, "keys": 1},
                {"coins": 30, "gems": 1},
                {"coins": 15, "keys": 2},
                {"coins": 40},
                {"keys": 3},
                {},
            ],
            "digging": [
                {"coins": 15},
                {"keys": 1},
                {"gems": 1},
                {"coins": 10, "keys": 1},
                {},
            ]
        }
        
        table = loot_tables.get(loot_type, loot_tables["chest"])
        return random.choice(table)


# Test
if __name__ == "__main__":
    from room import Room, RoomColor
    
    # Test tirage de pièces avec boost
    rooms = [
        Room("Common Room", RoomColor.BLUE, rarity=0, gem_cost=0),
        Room("Rare Room", RoomColor.YELLOW, rarity=1, gem_cost=1),
        Room("Epic Room", RoomColor.PURPLE, rarity=2, gem_cost=2),
        Room("Legendary Room", RoomColor.RED, rarity=3, gem_cost=3),
        Room("Green Room", RoomColor.GREEN, rarity=1, gem_cost=1),
        Room("Orange Room", RoomColor.ORANGE, rarity=2, gem_cost=1),
    ]
    
    # Création du manager
    rm = RandomManager()
    
    print("🎲 Test 1: Tirage normal (sans boost)")
    print("-" * 50)
    drawn = rm.draw_rooms(rooms, 3)
    for room in drawn:
        print(f"  - {room}")
    
    print("\n🎲 Test 2: Tirage avec boost BLUE x3")
    print("-" * 50)
    rm.apply_color_boost('blue', 3.0)
    drawn = rm.draw_rooms(rooms, 3)
    for room in drawn:
        print(f"  - {room}")
    
    print("\n🎲 Test 3: Tirage avec multiple boosts")
    print("-" * 50)
    rm.apply_color_boost('yellow', 2.5)
    rm.apply_color_boost('green', 1.8)
    drawn = rm.draw_rooms(rooms, 4)
    for room in drawn:
        print(f"  - {room}")
    
    print("\n🎲 Test 4: Réinitialisation")
    print("-" * 50)
    rm.reset_all_boosts()
    drawn = rm.draw_rooms(rooms, 3)
    for room in drawn:
        print(f"  - {room}")
    
    print("\n🎲 Test 5: Niveaux de verrouillage")
    print("-" * 50)
    for row in range(5):
        level = RandomManager.get_door_lock_level(row, 5)
        level_names = {
            Door.UNLOCKED: "Déverrouillée",
            Door.LOCKED: "Verrouillée",
            Door.DOUBLE_LOCKED: "Doublement verrouillée"
        }
        print(f"  Rangée {row}: {level_names[level]}")
    
    print("\n🎲 Test 6: Butin aléatoire")
    print("-" * 50)
    for _ in range(5):
        loot = RandomManager.get_random_loot("chest")
        print(f"  {loot}")