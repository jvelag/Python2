"""
Gestionnaire de ressources (polices, couleurs, images, sons).
Jour 5 : Ressources complètes pour l'interface graphique.
"""

import pygame
import os
from typing import Dict, Tuple, Optional


class ResourceManager:
    """Gère toutes les ressources graphiques et sonores du jeu."""
    
    def __init__(self):
        pygame.font.init()
        
        # Dossiers de ressources
        self.assets_dir = "assets"
        self.fonts_dir = os.path.join(self.assets_dir, "fonts")
        self.images_dir = os.path.join(self.assets_dir, "images")
        self.sounds_dir = os.path.join(self.assets_dir, "sounds")
        
        # Créer les dossiers s'ils n'existent pas
        self._create_directories()
        
        # Polices améliorées
        self.fonts = self._load_fonts()
        
        # Couleurs enrichies
        self.colors = self._define_colors()
        
        # Images (chargées à la demande)
        self.images: Dict[str, pygame.Surface] = {}
        
        # Sons (chargés à la demande)
        self.sounds: Dict[str, pygame.mixer.Sound] = {}
        
        # Configuration des animations
        self.animation_speed = 0.1
        
        print("✅ ResourceManager initialized with enhanced resources")
    
    def _create_directories(self):
        """Crée la structure de dossiers pour les assets."""
        directories = [self.assets_dir, self.fonts_dir, self.images_dir, self.sounds_dir]
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    def _load_fonts(self) -> Dict[str, pygame.font.Font]:
        """Charge les polices avec fallback vers les polices système."""
        fonts = {}
        
        # Essayer de charger des polices personnalisées d'abord
        custom_fonts = {
            'small': ("PixeloidSans.ttf", 18),
            'medium': ("PixeloidSans.ttf", 24),
            'medium_bold': ("PixeloidSans-Bold.ttf", 24),
            'large': ("PixeloidSans.ttf", 32),
            'large_bold': ("PixeloidSans-Bold.ttf", 32),
            'title': ("PixeloidSans-Bold.ttf", 42),
            'header': ("PixeloidSans-Bold.ttf", 36)
        }
        
        for font_name, (filename, size) in custom_fonts.items():
            font_path = os.path.join(self.fonts_dir, filename)
            try:
                if os.path.exists(font_path):
                    fonts[font_name] = pygame.font.Font(font_path, size)
                    print(f"✅ Loaded custom font: {font_name}")
                else:
                    raise FileNotFoundError
            except:
                # Fallback vers les polices système
                fonts[font_name] = pygame.font.Font(None, size)
                print(f"⚠️ Using system font for: {font_name}")
        
        return fonts
    
    def _define_colors(self) -> Dict[str, Tuple[int, int, int]]:
        """Définit la palette de couleurs complète."""
        return {
            # Arrière-plans
            'background': (15, 15, 25),
            'background_light': (25, 25, 35),
            'background_dark': (10, 10, 20),
            
            # Texte
            'text': (240, 240, 240),
            'text_light': (255, 255, 255),
            'text_dark': (180, 180, 180),
            'text_highlight': (255, 215, 100),
            'text_warning': (255, 100, 100),
            'text_success': (100, 255, 150),
            
            # Couleurs des pièces avec variations
            'blue': (70, 130, 220),
            'blue_light': (90, 150, 240),
            'blue_dark': (50, 110, 200),
            
            'yellow': (230, 180, 50),
            'yellow_light': (250, 200, 70),
            'yellow_dark': (210, 160, 30),
            
            'green': (80, 200, 120),
            'green_light': (100, 220, 140),
            'green_dark': (60, 180, 100),
            
            'purple': (160, 90, 200),
            'purple_light': (180, 110, 220),
            'purple_dark': (140, 70, 180),
            
            'orange': (230, 120, 50),
            'orange_light': (250, 140, 70),
            'orange_dark': (210, 100, 30),
            
            'red': (220, 60, 60),
            'red_light': (240, 80, 80),
            'red_dark': (200, 40, 40),
            
            # Interface utilisateur
            'panel': (35, 35, 50),
            'panel_light': (45, 45, 60),
            'panel_dark': (25, 25, 40),
            'panel_border': (80, 80, 120),
            'panel_border_light': (100, 100, 140),
            
            'button': (60, 60, 90),
            'button_hover': (80, 80, 110),
            'button_active': (100, 100, 130),
            'button_disabled': (40, 40, 60),
            
            'slider': (70, 70, 100),
            'slider_handle': (120, 120, 160),
            
            # Éléments de jeu
            'player': (255, 200, 100),
            'player_glow': (255, 220, 120, 100),  # Avec alpha
            
            'entrance': (100, 255, 100),
            'entrance_glow': (120, 255, 120, 100),
            
            'exit': (255, 100, 255),
            'exit_glow': (255, 120, 255, 100),
            
            # Portes
            'door_unlocked': (50, 200, 50),
            'door_locked': (200, 50, 50),
            'door_double_locked': (150, 30, 30),
            'door_open': (100, 200, 255),
            
            # État et feedback
            'health': (255, 80, 80),
            'mana': (80, 150, 255),
            'energy': (255, 200, 50),
            
            'selection': (255, 215, 100, 150),
            'highlight': (255, 255, 255, 100),
            'glow': (255, 255, 200, 50),
            
            # Rareté des objets
            'common': (200, 200, 200),
            'uncommon': (100, 200, 100),
            'rare': (100, 150, 255),
            'epic': (200, 100, 255),
            'legendary': (255, 180, 50),
            
            # Effets
            'shadow': (0, 0, 0, 100),
            'overlay': (0, 0, 0, 180),
            'flash': (255, 255, 255, 100)
        }
    
    def get_font(self, size: str = 'medium', bold: bool = False) -> pygame.font.Font:
        """Récupère une police avec option de gras."""
        font_key = f"{size}_bold" if bold and f"{size}_bold" in self.fonts else size
        return self.fonts.get(font_key, self.fonts['medium'])
    
    def get_color(self, name: str, variant: str = "") -> Tuple[int, int, int]:
        """Récupère une couleur avec gestion des variantes."""
        color_key = f"{name}_{variant}" if variant else name
        return self.colors.get(color_key, self.colors.get(name, (255, 255, 255)))
    
    def get_room_color(self, room_type: str, state: str = "") -> Tuple[int, int, int]:
        """Récupère la couleur d'une pièce avec son état."""
        base_color = self.get_color(room_type)
        
        if state == "visited":
            # Assombrir les pièces visitées
            return tuple(max(0, c - 40) for c in base_color)
        elif state == "highlight":
            # Éclaircir les pièces en surbrillance
            return tuple(min(255, c + 30) for c in base_color)
        
        return base_color
    
    def load_image(self, filename: str, scale: float = 1.0) -> Optional[pygame.Surface]:
        """Charge une image avec mise en cache."""
        cache_key = f"{filename}_{scale}"
        
        if cache_key in self.images:
            return self.images[cache_key]
        
        try:
            image_path = os.path.join(self.images_dir, filename)
            if os.path.exists(image_path):
                image = pygame.image.load(image_path).convert_alpha()
                if scale != 1.0:
                    new_size = (int(image.get_width() * scale), int(image.get_height() * scale))
                    image = pygame.transform.scale(image, new_size)
                self.images[cache_key] = image
                print(f"✅ Loaded image: {filename}")
                return image
        except Exception as e:
            print(f"❌ Failed to load image {filename}: {e}")
        
        return None
    
    def load_sound(self, filename: str) -> Optional[pygame.mixer.Sound]:
        """Charge un son avec mise en cache."""
        if filename in self.sounds:
            return self.sounds[filename]
        
        try:
            sound_path = os.path.join(self.sounds_dir, filename)
            if os.path.exists(sound_path):
                sound = pygame.mixer.Sound(sound_path)
                self.sounds[filename] = sound
                print(f"✅ Loaded sound: {filename}")
                return sound
        except Exception as e:
            print(f"❌ Failed to load sound {filename}: {e}")
        
        return None
    
    def create_gradient_surface(self, width: int, height: int, 
                              start_color: Tuple[int, int, int], 
                              end_color: Tuple[int, int, int],
                              horizontal: bool = True) -> pygame.Surface:
        """Crée une surface avec dégradé."""
        surface = pygame.Surface((width, height), pygame.SRCALPHA)
        
        for i in range(width if horizontal else height):
            ratio = i / (width if horizontal else height)
            r = int(start_color[0] * (1 - ratio) + end_color[0] * ratio)
            g = int(start_color[1] * (1 - ratio) + end_color[1] * ratio)
            b = int(start_color[2] * (1 - ratio) + end_color[2] * ratio)
            
            if horizontal:
                pygame.draw.line(surface, (r, g, b), (i, 0), (i, height))
            else:
                pygame.draw.line(surface, (r, g, b), (0, i), (width, i))
        
        return surface
    
    def create_rounded_rect(self, size: Tuple[int, int], color: Tuple[int, int, int], 
                          radius: int = 10, border: int = 0, 
                          border_color: Tuple[int, int, int] = None) -> pygame.Surface:
        """Crée un rectangle aux coins arrondis."""
        width, height = size
        surface = pygame.Surface((width, height), pygame.SRCALPHA)
        
        # Dessiner le rectangle arrondi
        rect = pygame.Rect(0, 0, width, height)
        pygame.draw.rect(surface, color, rect, border_radius=radius)
        
        # Ajouter une bordure si demandée
        if border > 0 and border_color:
            pygame.draw.rect(surface, border_color, rect, border, border_radius=radius)
        
        return surface
    
    def play_sound(self, sound_name: str, volume: float = 1.0):
        """Joue un son."""
        sound = self.load_sound(sound_name)
        if sound:
            sound.set_volume(volume)
            sound.play()
    
    def get_available_resources(self) -> Dict[str, list]:
        """Retourne la liste des ressources disponibles."""
        return {
            'fonts': list(self.fonts.keys()),
            'colors': list(self.colors.keys()),
            'images': list(self.images.keys()),
            'sounds': list(self.sounds.keys())
        }


# Test amélioré
if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    
    rm = ResourceManager()
    
    print("\n🎨 ResourceManager Test")
    print("=" * 50)
    
    # Test des couleurs
    print("\n📊 Available colors:")
    color_categories = {}
    for color_name in rm.colors.keys():
        category = color_name.split('_')[0]
        if category not in color_categories:
            color_categories[category] = []
        color_categories[category].append(color_name)
    
    for category, colors in color_categories.items():
        print(f"  {category}: {len(colors)} colors")
    
    # Test des polices
    print(f"\n📝 Available fonts: {list(rm.fonts.keys())}")
    
    # Test dégradé
    print("\n🌈 Testing gradient creation...")
    gradient = rm.create_gradient_surface(200, 50, rm.get_color('blue'), rm.get_color('purple'))
    
    # Test rectangle arrondi
    print("🔲 Testing rounded rectangle...")
    rounded_rect = rm.create_rounded_rect((150, 60), rm.get_color('panel'), radius=15, border=2, border_color=rm.get_color('panel_border'))
    
    # Affichage de test
    screen.fill(rm.get_color('background'))
    
    # Afficher le dégradé
    screen.blit(gradient, (50, 50))
    font = rm.get_font('small')
    text = font.render("Gradient Test", True, rm.get_color('text'))
    screen.blit(text, (60, 65))
    
    # Afficher le rectangle arrondi
    screen.blit(rounded_rect, (50, 120))
    text = font.render("Rounded Rect", True, rm.get_color('text'))
    screen.blit(text, (70, 140))
    
    # Afficher des échantillons de couleur
    colors_to_show = ['blue', 'green', 'red', 'purple', 'orange', 'yellow']
    for i, color_name in enumerate(colors_to_show):
        color = rm.get_color(color_name)
        pygame.draw.rect(screen, color, (50 + i * 60, 200, 50, 30))
        color_text = font.render(color_name, True, rm.get_color('text'))
        screen.blit(color_text, (50 + i * 60, 235))
    
    pygame.display.flip()
    
    # Garder la fenêtre ouverte
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                running = False
    
    pygame.quit()
    
    print("\n✅ All resource tests completed successfully!")