"""
Package models pour le jeu Blue Prince.
Contient toutes les classes du modèle de données.
"""

from .item import (
    Item, ConsumableItem, PermanentItem, Food,
    Steps, Keys, Gems, Coins, Dice,
    Shovel, Hammer, LockpickKit, MetalDetector, RabbitFoot,
    Compass, Map, Torch, Spyglass, Hourglass,
    Apple, Banana, Cake, Sandwich, Meal
)
from .inventory import Inventory
from .door import Door
from .room import Room, RoomColor, create_room_catalog
from .player import Player
from .manor import Manor

__all__ = [
    # Abstract
    'Item', 'ConsumableItem', 'PermanentItem', 'Food',
    # Consumables
    'Steps', 'Keys', 'Gems', 'Coins', 'Dice',
    # Permanent items
    'Shovel', 'Hammer', 'LockpickKit', 'MetalDetector', 'RabbitFoot',
    'Compass', 'Map', 'Torch', 'Spyglass', 'Hourglass',
    # Food
    'Apple', 'Banana', 'Cake', 'Sandwich', 'Meal',
    # Core
    'Inventory', 'Door', 'Room', 'RoomColor', 'Player', 'Manor',
    # Functions
    'create_room_catalog'
]

__version__ = '1.0.0'
__author__ = 'Moss'