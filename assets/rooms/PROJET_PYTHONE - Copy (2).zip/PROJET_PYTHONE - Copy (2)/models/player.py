"""
Module du joueur.
Jour 3 : Déplacements et gestion de l'état du joueur.
"""

from .inventory import Inventory


class Player:
    """Représente le joueur."""
    
    def __init__(self, start_position: tuple = (4, 4)):
        self.position = start_position
        self.inventory = Inventory()
    
    def move(self, new_position: tuple, manor) -> bool:
        """Déplace le joueur."""
        # Vérifie si on a des pas
        if self.inventory.steps.quantity <= 0:
            print("❌ No more steps!")
            return False
        
        # ✅ CORRECTION: Torche réduit le coût en pas
        step_cost = 1
        if self.inventory.has_permanent_item('torch'):
            step_cost = 0  # Déplacement gratuit avec la torche
            print("🔦 Torche active: déplacement gratuit!")
        
        # Consomme le coût en pas (0 si torche, 1 sinon)
        for _ in range(step_cost):
            if not self.inventory.steps.use(self):
                print("❌ Not enough steps for movement!")
                return False
        
        remaining_steps = self.inventory.steps.quantity
        print(f"👣 Moved to {new_position} ({remaining_steps} steps left)")
        
        # Met à jour la position
        old_position = self.position
        self.position = new_position
        
        # Entre dans la nouvelle pièce
        room = manor.get_room(new_position)
        if room:
            room.enter(self)
        
        return True
    
    def has_lost(self) -> bool:
        """Vérifie si le joueur a perdu."""
        return self.inventory.steps.quantity <= 0
    
    def get_step_cost(self) -> int:
        """
        Calcule le coût en pas pour un déplacement.
        
        Returns:
            int: Coût en pas (0 avec torche, 1 sans)
        """
        if self.inventory.has_permanent_item('torch'):
            return 0
        return 1
    
    def __str__(self):
        step_cost = self.get_step_cost()
        torch_status = "avec torche" if step_cost == 0 else "sans torche"
        return f"Player at {self.position} ({torch_status}, {self.inventory.steps.quantity} steps)"


# Test
if __name__ == "__main__":
    from manor import Manor
    
    print("🧪 TEST DU SYSTÈME DE DÉPLACEMENT AVEC TORCHE")
    print("=" * 50)
    
    # Création du joueur et du manoir
    player = Player((2, 2))
    manor = Manor()
    
    print("🎮 Test 1: Déplacement SANS torche")
    print("-" * 30)
    print(f"Position initiale: {player.position}")
    print(f"Pas initiaux: {player.inventory.steps.quantity}")
    print(f"Coût par déplacement: {player.get_step_cost()}")
    
    # Test déplacement sans torche
    success = player.move((2, 3), manor)
    print(f"Déplacement réussi: {success}")
    print(f"Pas restants: {player.inventory.steps.quantity}")
    print(f"Coût par déplacement: {player.get_step_cost()}")
    
    print("\n🎮 Test 2: Obtention de la torche")
    print("-" * 30)
    player.inventory.add_permanent_item('torch')
    print("✅ Torche ajoutée à l'inventaire!")
    player.inventory.display()
    
    print("\n🎮 Test 3: Déplacement AVEC torche")
    print("-" * 30)
    print(f"Position actuelle: {player.position}")
    print(f"Pas actuels: {player.inventory.steps.quantity}")
    print(f"Coût par déplacement: {player.get_step_cost()}")
    
    # Test déplacement avec torche
    steps_before = player.inventory.steps.quantity
    success = player.move((2, 4), manor)
    steps_after = player.inventory.steps.quantity
    
    print(f"Déplacement réussi: {success}")
    print(f"Pas avant: {steps_before}, Pas après: {steps_after}")
    print(f"Pas consommés: {steps_before - steps_after}")
    
    print("\n🎮 Test 4: Déplacements multiples avec torche")
    print("-" * 30)
    initial_steps = player.inventory.steps.quantity
    print(f"Pas initiaux: {initial_steps}")
    
    # Plusieurs déplacements avec torche
    movements = [(3, 4), (3, 5), (4, 5), (4, 4)]
    for i, pos in enumerate(movements, 1):
        player.move(pos, manor)
        print(f"  Déplacement {i}: {pos} → Pas: {player.inventory.steps.quantity}")
    
    final_steps = player.inventory.steps.quantity
    movements_count = len(movements)
    steps_used = initial_steps - final_steps
    
    print(f"\nRésumé:")
    print(f"  Déplacements effectués: {movements_count}")
    print(f"  Pas utilisés: {steps_used}")
    print(f"  Pas économisés grâce à la torche: {movements_count - steps_used}")
    
    print("\n🎮 Test 5: Vérification de l'état du joueur")
    print("-" * 30)
    print(f"Position finale: {player.position}")
    print(f"Pas restants: {player.inventory.steps.quantity}")
    print(f"Joueur a perdu: {player.has_lost()}")
    print(f"Représentation: {player}")
    
    print("\n" + "=" * 50)
    print("✅ TOUS LES TESTS PASSÉS - SYSTÈME TORCHE OPÉRATIONNEL")