"""Module de gestion des pièces.

Jour 7 : Catalogue complet avec effets spéciaux et système de récompenses.

Ce module implémente le système de pièces du jeu avec :
- Différents niveaux de rareté
- Effets d'entrée et de tirage
- Système de couleurs et de coûts en gemmes
"""

from enum import Enum
from .door import Door


class RoomColor(Enum):
    """Couleurs des pièces représentant différents types."""
    BLUE = "blue"      # Pièces standards, bibliothèques
    YELLOW = "yellow"  # Cuisines, nourriture, MAGASINS
    GREEN = "green"    # Nature, ateliers
    PURPLE = "purple"  # Magie, trésors
    ORANGE = "orange"  # Chance, armes
    RED = "red"        # Secret, danger


class Room:
    """
    Représente une pièce du manoir.
    
    Attributes:
        name (str): Nom de la pièce
        color (RoomColor): Couleur/thème de la pièce
        rarity (int): Niveau de rareté (0-3)
        gem_cost (int): Coût en gemmes pour sélectionner
        doors (dict): Portes disponibles dans la pièce
        items (list): Objets présents dans la pièce
        visited (bool): Si la pièce a été visitée
        on_enter_effect (callable): Effet déclenché à l'entrée
        on_draw_effect (callable): Effet déclenché au tirage
    """
    
    def __init__(
        self,
        name: str,
        color: RoomColor,
        rarity: int = 0,
        gem_cost: int = 0,
        items: list = None,
        on_enter_effect=None,
        on_draw_effect=None
    ):
        """
        Initialise une pièce.
        
        Args:
            name: Nom de la pièce
            color: Couleur de la pièce
            rarity: Niveau de rareté (0=commun, 3=très rare)
            gem_cost: Coût en gemmes pour sélectionner
            items: Liste d'objets dans la pièce
            on_enter_effect: Fonction appelée à l'entrée
            on_draw_effect: Fonction appelée au tirage
        """
        self.name = name
        self.color = color
        self.rarity = rarity
        self.gem_cost = gem_cost
        self.doors = {}
        self.items = items or []
        self.visited = False
        self.on_enter_effect = on_enter_effect
        self.on_draw_effect = on_draw_effect
    
    def add_door(self, direction: str, door: Door):
        """
        Ajoute une porte à la pièce.
        
        Args:
            direction: Direction de la porte ('north', 'south', etc.)
            door: Objet Door à ajouter
        """
        self.doors[direction] = door
    
    def get_available_directions(self) -> list:
        """
        Retourne les directions disponibles.
        
        Returns:
            list: Liste des directions avec portes
        """
        return list(self.doors.keys())
    
    def get_probability_weight(self) -> float:
        """
        Calcule le poids de probabilité pour le tirage.
        
        Les pièces plus rares ont un poids plus faible.
        
        Returns:
            float: Poids de probabilité
        """
        return 1.0 / (3 ** self.rarity)
    
    def can_be_placed(self, position: tuple, manor_size: tuple) -> bool:
        """
        Vérifie si la pièce peut être placée à une position.
        
        Args:
            position: Position (x, y) dans le manoir
            manor_size: Taille du manoir (width, height)
            
        Returns:
            bool: True si la pièce peut être placée
        """
        x, y = position
        width, height = manor_size
        return 0 <= x < width and 0 <= y < height
    
    def enter(self, player):
        """
        Actions exécutées quand le joueur entre dans la pièce.
        
        Args:
            player: Le joueur qui entre
        """
        if not self.visited:
            self.visited = True
            print(f"🏠 Discovered: {self.name}")
            
            # Applique l'effet d'entrée si présent
            if self.on_enter_effect:
                self.on_enter_effect(player, self)
            
            # Donne les objets de la pièce
            self._give_room_items(player)
        else:
            print(f"🏠 Returned to: {self.name}")
    
    def on_draw(self, player):
        """
        Actions exécutées quand la pièce est tirée.
        
        Args:
            player: Le joueur qui tire la pièce
        """
        if self.on_draw_effect:
            self.on_draw_effect(player, self)
    
    def _give_room_items(self, player):
        """
        Donne les objets de la pièce au joueur.
        
        Args:
            player: Le joueur qui reçoit les objets
        """
        for item in self.items:
            if item.startswith("food_"):
                food_type = item.replace("food_", "")
                player.inventory.add_food(food_type, 1)
                print(f"🍎 Found: {food_type}")
            
            elif item.startswith("permanent_"):
                permanent_type = item.replace("permanent_", "")
                if player.inventory.add_permanent_item(permanent_type):
                    print(f"🛠️ Obtained: {permanent_type}")
            
            elif item == "chest":
                # Coffre avec récompenses aléatoires
                import random
                rewards = [
                    ("coins", random.randint(10, 30)),
                    ("keys", random.randint(1, 3)),
                    ("gems", random.randint(1, 2)),
                    ("dice", 1)
                ]
                reward_type, amount = random.choice(rewards)
                player.inventory.add_item(reward_type, amount)
                print(f"📦 Chest contained: {amount} {reward_type}")
            
            else:
                # Objet consommable standard
                player.inventory.add_item(item, 1)
                print(f"🎁 Found: {item}")
    
    def __str__(self):
        """Représentation textuelle de la pièce."""
        return f"{self.name} ({self.color.value}, rarity {self.rarity}, cost {self.gem_cost} gems)"
    
    def __repr__(self):
        """Représentation pour le débogage."""
        return f"Room('{self.name}', {self.color}, rarity={self.rarity})"


def create_room_catalog() -> list:
    """
    Crée le catalogue complet de pièces.
    
    Jour 7 : Catalogue final avec tous les effets et récompenses.
    
    Returns:
        list: Liste de toutes les pièces disponibles
    """
    catalog = []
    
    # === PIÈCES COMMUNES (rarity 0) - Coût: 0 gemmes ===
    
    def library_effect(player, room):
        """Bibliothèque : donne des connaissances (pièces)."""
        player.inventory.add_item("coins", 15)
        print("📚 Gained knowledge worth 15 coins!")
    
    catalog.append(Room(
        "Library", RoomColor.BLUE, 0, 0,
        ["coins", "coins", "coins"],
        on_enter_effect=library_effect
    ))
    
    catalog.append(Room(
        "Kitchen", RoomColor.YELLOW, 0, 0,
        ["food_apple", "food_banana"]
    ))
    
    catalog.append(Room(
        "Hallway", RoomColor.BLUE, 0, 0,
        ["keys"]
    ))
    
    catalog.append(Room(
        "Storage Room", RoomColor.GREEN, 0, 0,
        ["chest"]
    ))
    
    catalog.append(Room(
        "Guard Room", RoomColor.ORANGE, 0, 0,
        ["keys", "keys"]
    ))
    
    catalog.append(Room(
        "Pantry", RoomColor.YELLOW, 0, 0,
        ["food_cake"]
    ))
    
    # === PIÈCES PEU COMMUNES (rarity 1) - Coût: 1 gemme ===
    
    catalog.append(Room(
        "Bedroom", RoomColor.GREEN, 1, 1,
        ["chest", "coins"]
    ))
    
    catalog.append(Room(
        "Study", RoomColor.PURPLE, 1, 1,
        ["coins", "keys", "gems"]
    ))
    
    catalog.append(Room(
        "Armory", RoomColor.ORANGE, 1, 1,
        ["permanent_hammer"]
    ))
    
    catalog.append(Room(
        "Wine Cellar", RoomColor.RED, 1, 1,
        ["food_meal"]
    ))
    
    def workshop_effect(player, room):
        """Atelier : donne une pelle."""
        if player.inventory.add_permanent_item("shovel"):
            print("🛠️ Found a sturdy shovel!")
    
    catalog.append(Room(
        "Workshop", RoomColor.GREEN, 1, 1,
        on_enter_effect=workshop_effect
    ))
    
    # ✅ AJOUT: MAGASIN (rarity 1)
    def shop_effect(player, room):
        """Magasin : permet d'acheter des objets."""
        print("🛒 Welcome to the Shop!")
        print("💡 Shop system will be implemented in the interface")
        # L'interaction se fera via l'interface de jeu
    
    catalog.append(Room(
        "Shop", RoomColor.YELLOW, 1, 1,
        on_enter_effect=shop_effect
    ))
    
    # ✅ AJOUT: SERRES (rarity 1) - Augmente chances pièces vertes
    def greenhouse_effect(player, room):
        """Serre : augmente les chances de pièces vertes."""
        print("🌿 La serre augmente vos chances de trouver des jardins!")
        # Cette partie sera gérée dans main.py via le random_manager
    
    catalog.append(Room(
        "Greenhouse", RoomColor.GREEN, 1, 1,
        on_enter_effect=greenhouse_effect
    ))
    
    # === PIÈCES RARES (rarity 2) - Coût: 2 gemmes ===
    
    def treasury_effect(player, room):
        """Trésorerie : richesses abondantes."""
        player.inventory.add_item("coins", 50)
        player.inventory.add_item("gems", 2)
        print("💰 Treasury overflowed with riches!")
    
    catalog.append(Room(
        "Treasury", RoomColor.PURPLE, 2, 2,
        on_enter_effect=treasury_effect
    ))
    
    catalog.append(Room(
        "Gallery", RoomColor.YELLOW, 2, 2,
        ["gems", "coins"]
    ))
    
    catalog.append(Room(
        "Laboratory", RoomColor.GREEN, 2, 2,
        ["permanent_metal_detector"]
    ))
    
    def dining_hall_effect(player, room):
        """Salle à manger : festin réparateur."""
        player.inventory.steps.add(20)
        print("🍽️ Had a feast! Restored 20 steps!")
    
    catalog.append(Room(
        "Dining Hall", RoomColor.YELLOW, 2, 2,
        on_enter_effect=dining_hall_effect
    ))
    
    def lucky_room_draw_effect(player, room):
        """Pièce chanceuse : donne un dé au tirage."""
        player.inventory.add_item("dice", 1)
        print("🎲 Lucky! Found a dice while drawing!")
    
    catalog.append(Room(
        "Lucky Room", RoomColor.ORANGE, 2, 1,
        on_draw_effect=lucky_room_draw_effect
    ))
    
    # ✅ AJOUT: MARCHÉ (rarity 2) - Version améliorée du magasin
    def market_effect(player, room):
        """Marché : magasin avec prix réduits."""
        print("🏪 Welcome to the Market! Better prices available!")
        print("💡 Market system will be implemented in the interface")
        # L'interaction se fera via l'interface de jeu
    
    catalog.append(Room(
        "Market", RoomColor.YELLOW, 2, 1,
        on_enter_effect=market_effect
    ))
    
    # ✅ AJOUT: FOURNEAU (rarity 2) - Augmente chances pièces rouges
    def furnace_effect(player, room):
        """Fourneau : augmente les chances de pièces rouges."""
        print("🔥 La chaleur attire les pièces dangereuses...")
        # Cette partie sera gérée dans main.py via le random_manager
    
    catalog.append(Room(
        "Furnace Room", RoomColor.RED, 2, 2,
        on_enter_effect=furnace_effect
    ))
    
    # === PIÈCES TRÈS RARES (rarity 3) - Coût: 3 gemmes ===
    
    def vault_effect(player, room):
        """Coffre-fort : trésor sécurisé."""
        player.inventory.add_item("coins", 40)
        print("💰 Found 40 coins in the secured vault!")
    
    catalog.append(Room(
        "Vault", RoomColor.BLUE, 3, 3,
        on_enter_effect=vault_effect
    ))
    
    def secret_room_effect(player, room):
        """Pièce secrète : trésors cachés."""
        player.inventory.add_item("gems", 3)
        player.inventory.add_item("keys", 5)
        player.inventory.add_item("coins", 30)
        player.inventory.add_permanent_item("rabbit_foot")
        print("🎁 Secret room revealed hidden treasures!")
    
    catalog.append(Room(
        "Secret Room", RoomColor.RED, 3, 3,
        on_enter_effect=secret_room_effect
    ))
    
    def throne_room_effect(player, room):
        """Salle du trône : bénédiction royale."""
        player.inventory.steps.add(30)
        player.inventory.add_item("gems", 2)
        print("👑 The throne blessed you with 30 steps and 2 gems!")
    
    catalog.append(Room(
        "Throne Room", RoomColor.PURPLE, 3, 3,
        on_enter_effect=throne_room_effect
    ))
    
    def maze_room_effect(player, room):
        """Salle du labyrinthe : récompense complexe."""
        # 50% de chance de gagner gros, 50% de perdre
        import random
        if random.random() > 0.5:
            player.inventory.add_item("gems", 3)
            player.inventory.add_item("dice", 2)
            print("🧩 Solved the maze! Great reward!")
        else:
            player.inventory.remove_item("steps", 10)
            print("🧩 Got lost in the maze! Lost 10 steps...")
    
    catalog.append(Room(
        "Maze Room", RoomColor.GREEN, 3, 3,
        on_enter_effect=maze_room_effect
    ))
    
    return catalog


def get_rooms_by_rarity(rarity: int, catalog: list = None) -> list:
    """
    Filtre les pièces par rareté.
    
    Args:
        rarity: Niveau de rareté désiré
        catalog: Catalogue de pièces (optionnel)
        
    Returns:
        list: Pièces de la rareté spécifiée
    """
    if catalog is None:
        catalog = create_room_catalog()
    return [room for room in catalog if room.rarity == rarity]


def get_room_by_name(name: str, catalog: list = None) -> Room:
    """
    Trouve une pièce par son nom.
    
    Args:
        name: Nom de la pièce recherchée
        catalog: Catalogue de pièces (optionnel)
        
    Returns:
        Room: Pièce trouvée ou None
    """
    if catalog is None:
        catalog = create_room_catalog()
    for room in catalog:
        if room.name.lower() == name.lower():
            return room
    return None


# ============================================================================
# Tests du module
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("TEST DU MODULE ROOM - JOUR 7 (AVEC EFFETS DE COULEUR)")
    print("=" * 70)
    
    # Test 1 : Création du catalogue
    print("\n🏠 Test 1 : Création du catalogue")
    print("-" * 70)
    catalog = create_room_catalog()
    print(f"✓ Catalogue créé avec {len(catalog)} pièces")
    
    # Test 2 : Vérification des nouvelles pièces avec effets de couleur
    print("\n🎨 Test 2 : Pièces avec effets de couleur")
    print("-" * 70)
    
    greenhouse = get_room_by_name("Greenhouse", catalog)
    furnace = get_room_by_name("Furnace Room", catalog)
    
    if greenhouse:
        print(f"✓ Serre trouvée: {greenhouse}")
        print(f"  - Rareté: {greenhouse.rarity}")
        print(f"  - Couleur: {greenhouse.color.value}")
        print(f"  - Effet: Augmente chances pièces vertes")
    else:
        print("✗ Serre non trouvée")
    
    if furnace:
        print(f"✓ Fourneau trouvé: {furnace}")
        print(f"  - Rareté: {furnace.rarity}")
        print(f"  - Couleur: {furnace.color.value}")
        print(f"  - Effet: Augmente chances pièces rouges")
    else:
        print("✗ Fourneau non trouvé")
    
    # Test 3 : Simulation des effets
    print("\n🎭 Test 3 : Simulation des effets")
    print("-" * 70)
    
    class MockPlayer:
        def __init__(self):
            from models.inventory import Inventory
            self.inventory = Inventory()
    
    player = MockPlayer()
    
    if greenhouse and greenhouse.on_enter_effect:
        print("🌿 Test effet serre:")
        greenhouse.on_enter_effect(player, greenhouse)
    
    if furnace and furnace.on_enter_effect:
        print("🔥 Test effet fourneau:")
        furnace.on_enter_effect(player, furnace)
    
    # Test 4 : Filtrage par rareté
    print("\n⭐ Test 4 : Filtrage par rareté")
    print("-" * 70)
    for rarity in range(4):
        rooms = get_rooms_by_rarity(rarity, catalog)
        print(f"✓ Rareté {rarity}: {len(rooms)} pièces")
    
    print("\n" + "=" * 70)
    print("✅ TOUS LES TESTS SONT PASSÉS - EFFETS DE COULEUR AJOUTÉS")
    print("=" * 70)