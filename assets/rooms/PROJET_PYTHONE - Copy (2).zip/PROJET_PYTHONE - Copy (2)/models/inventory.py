"""
Module de gestion de l'inventaire du joueur.

Jour 7 : Inventaire complet avec gestion des objets permanents.

Ce module implémente l'inventaire qui regroupe tous les objets
du joueur : consommables, permanents et nourriture.
"""

from .item import (
    Steps, Keys, Gems, Coins, Dice,
    Shovel, Hammer, LockpickKit, MetalDetector, RabbitFoot,
    Compass, Map, Torch, Spyglass, Hourglass,  # ✅ AJOUT: Nouveaux objets
    Apple, Banana, Cake, Sandwich, Meal
)


class Inventory:
    """
    Gère l'inventaire complet du joueur.
    
    L'inventaire contient tous les objets du joueur :
    
    Objets consommables :
    - Steps (pas) : ressource principale pour se déplacer
    - Keys (clés) : pour ouvrir les portes
    - Gems (gemmes) : pour sélectionner des pièces rares
    - Coins (pièces) : score et monnaie
    - Dice (dés) : pour relancer la sélection de pièces
    
    Objets permanents :
    - Shovel : pelle pour creuser
    - Hammer : marteau pour ouvrir les coffres
    - LockpickKit : kit de crochetage
    - MetalDetector : détecteur de métaux
    - RabbitFoot : patte de lapin porte-bonheur
    - Compass : boussole révèle les pièces adjacentes
    - Map : carte affiche la grille complète
    - Torch : torche réduit le coût en pas
    - Spyglass : longue-vue révèle les pièces à distance
    - Hourglass : sablier donne du temps supplémentaire
    
    Nourriture :
    - Apple, Banana, Cake, Sandwich, Meal : restaurent des pas
    
    Attributes:
        steps (Steps): Les pas du joueur
        keys (Keys): Les clés du joueur
        gems (Gems): Les gemmes du joueur
        coins (Coins): Les pièces du joueur
        dice (Dice): Les dés du joueur
        permanent_items (dict): Dictionnaire des objets permanents possédés
        food_items (dict): Dictionnaire de la nourriture possédée
    """
    
    def __init__(self):
        """
        Initialise l'inventaire avec les quantités de départ.
        
        Quantités initiales :
        - 70 pas
        - 0 clés
        - 2 gemmes
        - 0 pièces
        - 0 dés
        - Aucun objet permanent
        - Aucune nourriture
        """
        # Objets consommables de base
        self.steps = Steps(70)
        self.keys = Keys(0)
        self.gems = Gems(2)
        self.coins = Coins(0)
        self.dice = Dice(0)
        
        # Objets permanents (initialement vides)
        self.permanent_items = {}
        
        # Nourriture (initialement vide)
        self.food_items = {}
    
    def add_item(self, item_name: str, quantity: int = 1):
        """
        Ajoute une quantité d'un type d'objet consommable à l'inventaire.
        
        Args:
            item_name: Le nom de l'objet ("steps", "keys", "gems", "coins", "dice")
            quantity: La quantité à ajouter (par défaut 1)
            
        Raises:
            ValueError: Si le nom d'objet est inconnu
            ValueError: Si la quantité est négative
        """
        if quantity < 0:
            raise ValueError("Quantity must be positive")
        
        item_name = item_name.lower()
        
        if item_name == "steps":
            self.steps.add(quantity)
        elif item_name == "keys":
            self.keys.add(quantity)
        elif item_name == "gems":
            self.gems.add(quantity)
        elif item_name == "coins":
            self.coins.add(quantity)
        elif item_name == "dice":
            self.dice.add(quantity)
        else:
            raise ValueError(f"Unknown consumable item type: {item_name}")
    
    def remove_item(self, item_name: str, quantity: int = 1) -> bool:
        """
        Retire une quantité d'un type d'objet consommable de l'inventaire.
        
        Args:
            item_name: Le nom de l'objet ("steps", "keys", "gems", "coins", "dice")
            quantity: La quantité à retirer (par défaut 1)
            
        Returns:
            bool: True si l'opération a réussi, False si quantité insuffisante
            
        Raises:
            ValueError: Si le nom d'objet est inconnu
            ValueError: Si la quantité est négative
        """
        if quantity < 0:
            raise ValueError("Quantity must be positive")
        
        item_name = item_name.lower()
        
        if item_name == "steps":
            return self.steps.remove(quantity)
        elif item_name == "keys":
            return self.keys.remove(quantity)
        elif item_name == "gems":
            return self.gems.remove(quantity)
        elif item_name == "coins":
            return self.coins.remove(quantity)
        elif item_name == "dice":
            return self.dice.remove(quantity)
        else:
            raise ValueError(f"Unknown consumable item type: {item_name}")
    
    def add_permanent_item(self, item_name: str):
        """
        Ajoute un objet permanent à l'inventaire.
        
        Args:
            item_name: Le nom de l'objet permanent
            
        Returns:
            bool: True si l'objet a été ajouté, False si déjà possédé
        """
        item_map = {
            "shovel": Shovel(),
            "hammer": Hammer(),
            "lockpick_kit": LockpickKit(),
            "metal_detector": MetalDetector(),
            "rabbit_foot": RabbitFoot(),
            # ✅ AJOUT: Nouveaux objets permanents
            "compass": Compass(),
            "map": Map(),
            "torch": Torch(),
            "spyglass": Spyglass(),
            "hourglass": Hourglass()
        }
        
        if item_name in item_map:
            if item_name not in self.permanent_items:
                self.permanent_items[item_name] = item_map[item_name]
                return True
        return False
    
    def add_food(self, food_name: str, quantity: int = 1):
        """
        Ajoute de la nourriture à l'inventaire.
        
        Args:
            food_name: Le nom de la nourriture
            quantity: La quantité à ajouter
        """
        food_map = {
            "apple": Apple(),
            "banana": Banana(),
            "cake": Cake(),
            "sandwich": Sandwich(),
            "meal": Meal()
        }
        
        if food_name in food_map:
            if food_name not in self.food_items:
                self.food_items[food_name] = {
                    'item': food_map[food_name],
                    'quantity': 0
                }
            self.food_items[food_name]['quantity'] += quantity
    
    def use_food(self, food_name: str, player) -> bool:
        """
        Utilise un objet nourriture.
        
        Args:
            food_name: Le nom de la nourriture
            player: Le joueur qui utilise la nourriture
            
        Returns:
            bool: True si la nourriture a été utilisée, False sinon
        """
        if food_name in self.food_items and self.food_items[food_name]['quantity'] > 0:
            food_item = self.food_items[food_name]['item']
            success = food_item.use(player)
            if success:
                self.food_items[food_name]['quantity'] -= 1
                # Supprimer l'entrée si plus de quantité
                if self.food_items[food_name]['quantity'] <= 0:
                    del self.food_items[food_name]
            return success
        return False
    
    def get_quantity(self, item_name: str) -> int:
        """
        Récupère la quantité d'un type d'objet consommable.
        
        Args:
            item_name: Le nom de l'objet
            
        Returns:
            int: La quantité disponible
            
        Raises:
            ValueError: Si le nom d'objet est inconnu
        """
        item_name = item_name.lower()
        
        if item_name == "steps":
            return self.steps.quantity
        elif item_name == "keys":
            return self.keys.quantity
        elif item_name == "gems":
            return self.gems.quantity
        elif item_name == "coins":
            return self.coins.quantity
        elif item_name == "dice":
            return self.dice.quantity
        else:
            raise ValueError(f"Unknown item type: {item_name}")
    
    def has_item(self, item_name: str, quantity: int = 1) -> bool:
        """
        Vérifie si l'inventaire contient une quantité minimale d'un objet consommable.
        
        Args:
            item_name: Le nom de l'objet
            quantity: La quantité minimale requise
            
        Returns:
            bool: True si l'inventaire contient assez de cet objet
        """
        return self.get_quantity(item_name) >= quantity
    
    def has_permanent_item(self, item_name: str) -> bool:
        """
        Vérifie si le joueur possède un objet permanent.
        
        Args:
            item_name: Le nom de l'objet permanent
            
        Returns:
            bool: True si l'objet est possédé
        """
        return item_name in self.permanent_items
    
    def has_food(self, food_name: str = None) -> bool:
        """
        Vérifie si le joueur possède de la nourriture.
        
        Args:
            food_name: Nom spécifique de nourriture (optionnel)
            
        Returns:
            bool: True si le joueur a de la nourriture
        """
        if food_name:
            return food_name in self.food_items and self.food_items[food_name]['quantity'] > 0
        return len(self.food_items) > 0
    
    def display(self):
        """
        Affiche l'inventaire de manière formatée.
        
        Affiche tous les objets avec leur quantité actuelle.
        Utilise des émojis pour une meilleure lisibilité.
        """
        print("📊 ═══════════════════════════════════════")
        print("   INVENTORY")
        print("   ═══════════════════════════════════════")
        
        # Objets consommables
        print("   Consumables:")
        print(f"     👣 Steps:  {self.steps.quantity:>3}")
        print(f"     🔑 Keys:   {self.keys.quantity:>3}")
        print(f"     💎 Gems:   {self.gems.quantity:>3}")
        print(f"     🪙 Coins:  {self.coins.quantity:>3}")
        print(f"     🎲 Dice:   {self.dice.quantity:>3}")
        
        # Objets permanents
        print("\n   Permanent Items:")
        if self.permanent_items:
            for item_name, item in self.permanent_items.items():
                emoji_map = {
                    "shovel": "⛏️",
                    "hammer": "🔨",
                    "lockpick_kit": "🔓",
                    "metal_detector": "📡",
                    "rabbit_foot": "🐇",
                    "compass": "🧭",
                    "map": "🗺️",
                    "torch": "🔦",
                    "spyglass": "🔭",
                    "hourglass": "⏳"
                }
                emoji = emoji_map.get(item_name, "✅")
                print(f"     {emoji} {item.name}")
        else:
            print("     (None)")
        
        # Nourriture
        print("\n   Food:")
        if self.food_items:
            for food_name, food_data in self.food_items.items():
                food_item = food_data['item']
                quantity = food_data['quantity']
                print(f"     🍎 {food_item.name}: {quantity:>2}")
        else:
            print("     (None)")
        
        print("   ═══════════════════════════════════════")
    
    def get_summary(self) -> dict:
        """
        Retourne un résumé de l'inventaire sous forme de dictionnaire.
        
        Returns:
            dict: Dictionnaire avec les quantités de tous les objets
        """
        summary = {
            'steps': self.steps.quantity,
            'keys': self.keys.quantity,
            'gems': self.gems.quantity,
            'coins': self.coins.quantity,
            'dice': self.dice.quantity,
            'permanent_items': list(self.permanent_items.keys()),
            'food_items': {name: data['quantity'] for name, data in self.food_items.items()}
        }
        return summary
    
    def __str__(self):
        """Représentation textuelle de l'inventaire."""
        return f"Inventory(steps={self.steps.quantity}, keys={self.keys.quantity}, " \
               f"gems={self.gems.quantity}, coins={self.coins.quantity}, " \
               f"dice={self.dice.quantity}, permanents={len(self.permanent_items)}, " \
               f"food={len(self.food_items)})"
    
    def __repr__(self):
        """Représentation pour le débogage."""
        return self.__str__()


# ============================================================================
# Tests du module
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("TEST DU MODULE INVENTORY - JOUR 7 (AVEC NOUVEAUX OBJETS)")
    print("=" * 70)
    
    # Test 1 : Création d'inventaire
    print("\n📦 Test 1 : Création d'inventaire avec valeurs par défaut")
    print("-" * 70)
    inv = Inventory()
    inv.display()
    print(f"✓ Inventaire créé : {inv}")
    
    # Test 2 : Ajout d'objets consommables
    print("\n➕ Test 2 : Ajout d'objets consommables")
    print("-" * 70)
    inv.add_item("keys", 5)
    print(f"✓ Ajout de 5 clés")
    
    inv.add_item("coins", 100)
    print(f"✓ Ajout de 100 pièces")
    
    inv.add_item("dice", 3)
    print(f"✓ Ajout de 3 dés")
    
    inv.display()
    
    # Test 3 : Ajout d'objets permanents (TOUS les nouveaux)
    print("\n🛠️  Test 3 : Ajout de TOUS les objets permanents")
    print("-" * 70)
    permanent_items = [
        "shovel", "hammer", "lockpick_kit", "metal_detector", "rabbit_foot",
        "compass", "map", "torch", "spyglass", "hourglass"
    ]
    
    for item in permanent_items:
        success = inv.add_permanent_item(item)
        if success:
            print(f"✓ Ajout de {item}")
        else:
            print(f"✗ Échec ajout de {item}")
    
    inv.display()
    
    # Test 4 : Ajout de nourriture
    print("\n🍎 Test 4 : Ajout de nourriture")
    print("-" * 70)
    inv.add_food("apple", 2)
    print(f"✓ Ajout de 2 pommes")
    
    inv.add_food("cake", 1)
    print(f"✓ Ajout de 1 gâteau")
    
    inv.add_food("meal", 1)
    print(f"✓ Ajout de 1 repas complet")
    
    inv.display()
    
    # Test 5 : Vérifications des nouveaux objets
    print("\n🔍 Test 5 : Vérifications des nouveaux objets")
    print("-" * 70)
    new_items = ["compass", "map", "torch", "spyglass", "hourglass"]
    for item in new_items:
        has_item = inv.has_permanent_item(item)
        print(f"✓ A {item} ? {has_item}")
    
    print(f"✓ A de la nourriture ? {inv.has_food()}")
    print(f"✓ A des pommes ? {inv.has_food('apple')}")
    print(f"✓ A au moins 3 clés ? {inv.has_item('keys', 3)}")
    
    # Test 6 : Utilisation de nourriture
    print("\n🍽️  Test 6 : Utilisation de nourriture")
    print("-" * 70)
    
    class MockPlayer:
        def __init__(self, inventory):
            self.inventory = inventory
    
    player = MockPlayer(inv)
    
    print(f"✓ Pas avant repas : {inv.steps.quantity}")
    inv.use_food("meal", player)
    print(f"✓ Pas après repas : {inv.steps.quantity}")
    
    # Test 7 : Résumé
    print("\n📋 Test 7 : Résumé de l'inventaire")
    print("-" * 70)
    summary = inv.get_summary()
    print(f"✓ Résumé : {summary}")
    
    # Test 8 : Scénario de jeu complet avec nouveaux objets
    print("\n🎮 Test 8 : Scénario de jeu complet avec nouveaux objets")
    print("-" * 70)
    game_inv = Inventory()
    print("Début du jeu :")
    game_inv.display()
    
    print("\n→ Le joueur trouve un coffre avec 3 clés, 50 pièces et 2 dés")
    game_inv.add_item("keys", 3)
    game_inv.add_item("coins", 50)
    game_inv.add_item("dice", 2)
    
    print("→ Le joueur trouve une boussole et une carte")
    game_inv.add_permanent_item("compass")
    game_inv.add_permanent_item("map")
    
    print("→ Le joueur trouve de la nourriture")
    game_inv.add_food("apple", 3)
    game_inv.add_food("banana", 2)
    
    game_inv.display()
    
    print("\n→ Le joueur ouvre une porte (utilise 1 clé)")
    game_inv.remove_item("keys", 1)
    
    print("→ Le joueur fait 5 déplacements (utilise 5 pas)")
    game_inv.remove_item("steps", 5)
    
    print("→ Le joueur mange une pomme")
    game_inv.use_food("apple", player)
    
    game_inv.display()
    
    print("\n" + "=" * 70)
    print("✅ TOUS LES TESTS SONT PASSÉS - NOUVEAUX OBJETS INTÉGRÉS")
    print("=" * 70)