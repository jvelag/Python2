# Blue Prince - Projet POO 2025

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Pygame](https://img.shields.io/badge/Pygame-2.5.2-green.svg)](https://www.pygame.org/)
[![License](https://img.shields.io/badge/License-Academic-orange.svg)](LICENSE)

> Implémentation d'une version simplifiée du jeu vidéo "Blue Prince" en Python  
> **Master 1 Systèmes Communicants** - Sorbonne Université  
> **Année académique:** 2024-2025

---

## 👨‍🎓 Informations Projet

- **Étudiant:** CHABANE CHAOCUHE Mohand
- **Formation:** Master 1 Systèmes Communicants
- **Établissement:** Sorbonne Université
- **Date de rendu:** 16 novembre 2025


---

## 📋 Table des Matières

- [Description](#-description)
- [Objectifs Pédagogiques](#-objectifs-pédagogiques)
- [Installation](#-installation)
- [Utilisation](#-utilisation)
- [Architecture](#-architecture)
- [Fonctionnalités](#-fonctionnalités)
- [Concepts POO Implémentés](#-concepts-poo-implémentés)
- [Structure du Projet](#-structure-du-projet)
- [Technologies Utilisées](#-technologies-utilisées)
- [Démonstration](#-démonstration)
- [Documentation](#-documentation)

---

## 🎮 Description

**Blue Prince** est un jeu d'exploration dans un manoir mystérieux où le joueur doit atteindre l'Antichambre en gérant stratégiquement ses ressources limitées.

### Principe du jeu

Le joueur explore un manoir composé d'une grille de **5 lignes × 9 colonnes** (45 pièces potentielles). À chaque ouverture de porte, le jeu propose un choix entre 3 pièces tirées aléatoirement. Le joueur doit construire un chemin vers la sortie tout en gérant :

- **👣 Pas** : Chaque déplacement coûte 1 pas (initial: 70)
- **🔑 Clés** : Nécessaires pour ouvrir les portes verrouillées
- **💎 Gemmes** : Permettent de sélectionner des pièces rares
- **🪙 Pièces d'or** : Monnaie d'échange dans les magasins
- **🎲 Dés** : Permettent de retirer les pièces proposées

### Conditions de victoire/défaite

**🎉 Victoire :** Atteindre l'Antichambre (case en haut de la grille)  
**💀 Défaite :** Épuiser tous ses pas avant d'atteindre la sortie

---

## 🎯 Objectifs Pédagogiques

Ce projet met en pratique les concepts fondamentaux de la **Programmation Orientée Objet** :

1. ✅ **Abstraction** - Classe abstraite `Item` définissant le contrat pour tous les objets
2. ✅ **Héritage** - Hiérarchie de classes (ConsumableItem, PermanentItem, Food)
3. ✅ **Polymorphisme** - Méthode `use()` redéfinie selon le type d'objet
4. ✅ **Encapsulation** - Attributs privés et méthodes publiques
5. ✅ **Composition** - Player possède un Inventory
6. ✅ **Agrégation** - Manor contient des Room

**Patterns de conception utilisés :**
- Manager Pattern (RandomManager, InteractionManager)
- Template Method (classe Item abstraite)
- MVC (séparation Modèle-Vue-Contrôleur)

---

## 🚀 Installation

### Prérequis

- **Python 3.8** ou supérieur
- **pip** (gestionnaire de paquets Python)
- **Git** (pour cloner le repository)

### Installation des dépendances

```bash
# 1. Cloner le repository
git clone https://github.com/votre-username/blue-prince.git
cd blue-prince

# 2. Créer un environnement virtuel (recommandé)
python -m venv venv

# 3. Activer l'environnement virtuel
# Sur Windows:
venv\Scripts\activate
# Sur macOS/Linux:
source venv/bin/activate

# 4. Installer les dépendances
pip install -r requirements.txt
```

### Vérification de l'installation

```bash
# Vérifier la version de Python
python --version
# Doit afficher Python 3.8.x ou supérieur

# Vérifier que Pygame est installé
python -c "import pygame; print(pygame.version.ver)"
# Doit afficher 2.5.2
```

---

## 🎮 Utilisation

### Lancer le jeu

```bash
python main.py
```

### Contrôles

| Touche | Action |
|--------|--------|
| **Z** | Aller vers le nord / Ouvrir porte nord |
| **S** | Aller vers le sud / Ouvrir porte sud |
| **Q** | Aller vers l'ouest / Ouvrir porte ouest |
| **D** | Aller vers l'est / Ouvrir porte est |
| **1-9** | Interagir avec les objets de la pièce |
| **← →** | Naviguer dans le menu de sélection |
| **ENTRÉE** | Sélectionner une pièce |
| **R** | Utiliser un dé pour retirer (dans le menu) |
| **I** | Afficher l'inventaire (console) |
| **ESC** | Quitter le jeu |

### Conseils de jeu

💡 **Stratégies gagnantes :**
- Gérez vos pas avec attention (la nourriture restaure des pas)
- Collectez des clés pour ouvrir les portes verrouillées
- Utilisez les gemmes pour les pièces rares et précieuses
- Trouvez le kit de crochetage pour économiser vos clés
- Explorez les pièces vertes pour des objets permanents

---

## 🏗️ Architecture

Le projet suit une **architecture modulaire** organisée en packages spécialisés :

```
blue-prince/
│
├── models/              # 📦 Modèle de données
│   ├── item.py         # Hiérarchie d'objets (abstraction + héritage)
│   ├── inventory.py    # Gestion de l'inventaire
│   ├── door.py         # Système de portes verrouillées
│   ├── room.py         # Catalogue de pièces avec effets
│   ├── player.py       # Joueur et déplacements
│   └── manor.py        # Grille 5×9 du manoir
│
├── managers/            # ⚙️ Logique métier
│   ├── random_manager.py      # Gestion de l'aléatoire
│   ├── interaction_manager.py # Interactions avec objets
│   └── shop_manager.py        # Système de magasin
│
├── renderers/           # 🎨 Interface graphique (Vue)
│   ├── grid_renderer.py       # Affichage de la grille
│   ├── inventory_renderer.py  # Affichage de l'inventaire
│   └── room_selection_menu.py # Menu de sélection
│
├── utils/               # 🛠️ Utilitaires
│   └── resource_manager.py    # Polices et couleurs Pygame
│
├── main.py             # 🎯 Point d'entrée (Contrôleur)
├── requirements.txt    # 📋 Dépendances
├── README.md          # 📖 Ce fichier
├── .gitignore         # 🚫 Fichiers ignorés par Git
└── class_diagram.puml # 📐 Diagramme UML
```

### Diagramme UML

Le diagramme de classes complet est disponible dans `class_diagram.puml`.  
Visualisez-le sur : http://www.plantuml.com/plantuml/uml/

---

## ✨ Fonctionnalités

### Fonctionnalités Principales (20/20)

| Fonctionnalité | Implémentation | Status |
|----------------|----------------|--------|
| Interface graphique Pygame | Affichage complet de la grille et de l'inventaire | ✅ |
| Déplacement dans le manoir | Grille 5×9 avec navigation ZQSD | ✅ |
| Système de portes | 3 niveaux de verrouillage (0, 1, 2) | ✅ |
| Tirage de pièces | Sélection parmi 3 pièces aléatoires | ✅ |
| Gestion des ressources | Pas, clés, gemmes, pièces, dés | ✅ |
| Conditions de victoire | Atteindre l'Antichambre | ✅ |
| Conditions de défaite | Épuisement des pas | ✅ |
| Système de rareté | 4 niveaux (0-3) avec probabilités pondérées | ✅ |
| Kit de crochetage | Ouvre portes niveau 1 sans clé | ✅ |
| Objets permanents | Détecteur métaux, patte lapin, etc. | ✅ |

### Fonctionnalités Avancées (Syscom)

| Fonctionnalité | Status |
|----------------|--------|
| Système de magasin | ✅ |
| Coffres avec butin aléatoire | ✅ |
| Pelle et zones de creusage | ✅ |
| Marteau pour coffres | ✅ |
| Nourriture restaurative | ✅ |
| Effets spéciaux des pièces | ✅ |
| Modificateurs de probabilité | ✅ |

---

## 🎓 Concepts POO Implémentés

### 1. Abstraction

**Classe abstraite `Item` :**

```python
from abc import ABC, abstractmethod

class Item(ABC):
    """Classe abstraite représentant un objet du jeu."""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    
    @abstractmethod
    def use(self, player):
        """Méthode abstraite - doit être implémentée."""
        pass
```

### 2. Héritage

**Hiérarchie des objets :**

```
Item (abstract)
│
├── ConsumableItem
│   ├── Steps      (pas)
│   ├── Keys       (clés)
│   ├── Gems       (gemmes)
│   ├── Coins      (pièces d'or)
│   └── Dice       (dés)
│
├── PermanentItem
│   ├── Shovel     (pelle)
│   ├── Hammer     (marteau)
│   ├── LockpickKit (kit de crochetage)
│   ├── MetalDetector (détecteur)
│   └── RabbitFoot (patte de lapin)
│
└── Food
    ├── Apple      (+2 pas)
    ├── Banana     (+3 pas)
    ├── Cake       (+10 pas)
    ├── Sandwich   (+15 pas)
    └── Meal       (+25 pas)
```

### 3. Polymorphisme

**Méthode `use()` redéfinie selon le type :**

```python
# Food restaure des pas
class Food(Item):
    def use(self, player):
        player.inventory.steps.add(self.steps_restored)
        return True

# Keys décrémente le compteur
class Keys(ConsumableItem):
    def use(self, player):
        return self.remove(1)

# PermanentItem a un effet passif
class PermanentItem(Item):
    def use(self, player):
        return True  # Ne se consomme pas
```

### 4. Composition vs Agrégation

```python
# COMPOSITION (●) : Player POSSÈDE Inventory
class Player:
    def __init__(self):
        self.inventory = Inventory()  # Dépendance forte

# AGRÉGATION (◇) : Manor CONTIENT Room
class Manor:
    def __init__(self):
        self.grid = [[None] * 9 for _ in range(5)]  # Dépendance faible
```

### 5. Encapsulation

```python
class Door:
    # Constantes de classe (publiques)
    UNLOCKED = 0
    LOCKED = 1
    DOUBLE_LOCKED = 2
    
    def __init__(self, lock_level: int = UNLOCKED):
        # Attributs privés (convention _)
        self.lock_level = lock_level
        self.is_open = False
    
    # Méthodes publiques
    def can_open(self, player) -> tuple[bool, str]:
        """Interface publique pour vérifier l'accès."""
        # Logique encapsulée
        ...
```

---

## 🗂️ Structure du Projet

### Package `models/` - Modèle de données

**Responsabilité :** Représentation des entités du jeu

- `item.py` (480 lignes) - Système d'objets complet
- `inventory.py` (368 lignes) - Gestion de l'inventaire
- `door.py` (180 lignes) - Système de portes
- `room.py` (520 lignes) - Catalogue de 25+ pièces
- `player.py` (140 lignes) - Joueur et déplacements
- `manor.py` (80 lignes) - Grille du manoir

### Package `managers/` - Logique métier

**Responsabilité :** Règles du jeu et interactions

- `random_manager.py` (200 lignes) - Aléatoire centralisé
- `interaction_manager.py` (350 lignes) - Interactions objets
- `shop_manager.py` (100 lignes) - Système de magasin

### Package `renderers/` - Interface graphique

**Responsabilité :** Affichage avec Pygame

- `grid_renderer.py` (180 lignes) - Rendu de la grille
- `inventory_renderer.py` (350 lignes) - Rendu inventaire
- `room_selection_menu.py` (250 lignes) - Menu sélection

### Fichier principal

- `main.py` (433 lignes) - Orchestration et boucle de jeu

**Total :** ~3500+ lignes de code

---

## 💻 Technologies Utilisées

| Technologie | Version | Usage |
|-------------|---------|-------|
| **Python** | 3.8+ | Langage principal |
| **Pygame** | 2.5.2 | Interface graphique et gestion événements |
| **ABC** | Built-in | Classes abstraites |
| **Enum** | Built-in | Énumérations (RoomColor) |
| **Random** | Built-in | Génération aléatoire |

---

## 📸 Démonstration

### Écran de jeu

```
┌─────────────────────────────────────────────────────────────┐
│                     BLUE PRINCE                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌───┬───┬───┬───┬───┬───┬───┬───┬───┐                  │
│   │ ? │ ? │ ? │ ? │🎯 │ ? │ ? │ ? │ ? │                  │
│   ├───┼───┼───┼───┼───┼───┼───┼───┼───┤    INVENTORY     │
│   │ ? │ ? │ ? │ ? │ ? │ ? │ ? │ ? │ ? │                  │
│   ├───┼───┼───┼───┼───┼───┼───┼───┼───┤    👣 Steps: 65   │
│   │ ? │ ? │ ? │ ? │ ? │ ? │ ? │ ? │ ? │    🔑 Keys:   3   │
│   ├───┼───┼───┼───┼───┼───┼───┼───┼───┤    💎 Gems:   1   │
│   │ ? │ ? │ ? │✓ │👤│✓ │ ? │ ? │ ? │    🪙 Coins: 45   │
│   ├───┼───┼───┼───┼───┼───┼───┼───┼───┤    🎲 Dice:   0   │
│   │ ? │ ? │ ? │ ? │🚪│ ? │ ? │ ? │ ? │                  │
│   └───┴───┴───┴───┴───┴───┴───┴───┴───┘    PERMANENT     │
│                                              🔓 Lockpick   │
│                                              ⛏️  Shovel    │
└─────────────────────────────────────────────────────────────┘
```

---

## 📚 Documentation

### Fichiers de documentation

- `README.md` - Ce fichier (vue d'ensemble)
- `ARCHITECTURE.md` - Détails de l'architecture (à créer)
- `class_diagram.puml` - Diagramme UML complet
- Rapport de conception (PDF) - Document séparé

### Diagramme UML

Pour visualiser le diagramme de classes :

1. Copier le contenu de `class_diagram.puml`
2. Aller sur http://www.plantuml.com/plantuml/uml/
3. Coller et télécharger l'image

Ou en local avec PlantUML installé :

```bash
plantuml class_diagram.puml
```

### Génération de la documentation

```bash
# Avec pydoc (documentation auto depuis docstrings)
python -m pydoc -b

# Naviguer vers http://localhost:XXXX
```

---

## 🧪 Tests

### Tests manuels

Le jeu a été testé manuellement pour vérifier :

- ✅ Toutes les fonctionnalités principales
- ✅ Les interactions avec les objets
- ✅ Les conditions de victoire/défaite
- ✅ La génération aléatoire équilibrée
- ✅ La sauvegarde de l'état du jeu

### Tests automatisés (bonus)

Des tests unitaires peuvent être ajoutés :

```python
# tests/test_inventory.py
import unittest
from models.inventory import Inventory

class TestInventory(unittest.TestCase):
    def test_initial_values(self):
        inv = Inventory()
        self.assertEqual(inv.steps.quantity, 70)
        self.assertEqual(inv.gems.quantity, 2)
```

---

## 🐛 Problèmes Connus et Limitations

### Limitations actuelles

1. **Pas de sauvegarde** - Le jeu ne peut pas être sauvegardé
2. **Interface fixe** - Résolution d'écran 1200×800 non modifiable
3. **Pas de son** - Aucun effet sonore ou musique

### Améliorations futures possibles

- Système de sauvegarde/chargement
- Multijoueur local
- Plus d'effets de pièces
- Animations améliorées
- Niveaux de difficulté
- Achievements/succès

---

## 📄 Licence

Ce projet est réalisé dans un cadre académique pour le cours de Programmation Orientée Objet.

**Utilisation :** Projet éducatif - Sorbonne Université  
**Redistribution :** Avec accord de l'auteur

---

## 👤 Auteur

**CHABANE CHAOCUHE Mohand**  
Étudiant en Master 1 Systèmes Communicants  
Sorbonne Université - 2024/2025

📧 Email : [votre.email@etu.sorbonne-universite.fr]  
🐙 GitHub : [https://github.com/votre-username]

---

## 🙏 Remerciements

- **Anthropic (Claude)** - Assistance pour l'analyse et la documentation
- **Communauté Pygame** - Documentation et ressources
- **Blue Prince (jeu original)** - Inspiration pour le projet
- **Professeur TP** - Encadrement du projet

---

## 📅 Historique des Versions

### Version 1.0 (14 novembre 2025)
- ✅ Architecture complète en packages
- ✅ Toutes les fonctionnalités principales implémentées
- ✅ Interface graphique Pygame fonctionnelle
- ✅ 25+ pièces avec effets variés
- ✅ Système d'aléatoire équilibré
- ✅ Documentation complète

---

## 📞 Support

Pour toute question concernant ce projet :

1. **Consulter ce README** en premier
2. **Consulter la documentation** dans `docs/`
3. **Contacter l'auteur** par email universitaire

---

<div align="center">

**🎮 Bon jeu et bonne exploration du manoir ! 🏰**

---

*README généré le 15 novembre 2025*  
*Projet Blue Prince - POO 2025*

</div>
