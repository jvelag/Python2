"""
Package utils pour le jeu Blue Prince.
Contient les utilitaires et ressources.
"""

from .resource_manager import ResourceManager

__all__ = [
    'ResourceManager'
]
