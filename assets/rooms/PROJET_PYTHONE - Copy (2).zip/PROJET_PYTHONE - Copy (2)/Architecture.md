# Architecture du Projet Blue Prince

> Documentation technique de l'architecture logicielle  
> **Master 1 Systèmes Communicants** - Sorbonne Université  
> **Auteur:** CHABANE CHAOCUHE Mohand  - **Année:** 2024-2025

---

## 📋 Table des Matières

1. [Vue d'Ensemble](#-vue-densemble)
2. [Principes Architecturaux](#-principes-architecturaux)
3. [Organisation en Packages](#-organisation-en-packages)
4. [Concepts POO Appliqués](#-concepts-poo-appliqués)
5. [Patterns de Conception](#-patterns-de-conception)
6. [Flux de Données](#-flux-de-données)
7. [Diagramme de Classes](#-diagramme-de-classes)
8. [Justifications des Choix](#-justifications-des-choix)
9. [Décisions Techniques](#-décisions-techniques)

---

## 🏛️ Vue d'Ensemble

### Architecture Modulaire

Le projet Blue Prince suit une **architecture modulaire en couches** inspirée du pattern **MVC (Model-View-Controller)** avec une séparation claire des responsabilités :

```
┌─────────────────────────────────────────────────────────────┐
│                    BluePrinceGame                           │
│                    (Contrôleur)                             │
│  • Orchestre les interactions                              │
│  • Gère la boucle de jeu                                   │
│  • Coordonne Modèle et Vue                                 │
└─────────────────────────────────────────────────────────────┘
                    ↓                    ↓
        ┌───────────────────┐    ┌──────────────────┐
        │   MODÈLE (M)      │    │    VUE (V)       │
        │                   │    │                  │
        │  • models/        │    │  • renderers/    │
        │  • managers/      │    │  • utils/        │
        └───────────────────┘    └──────────────────┘
```

### Caractéristiques Principales

| Caractéristique | Description |
|-----------------|-------------|
| **Modularité** | 4 packages indépendants et cohésifs |
| **Séparation des préoccupations** | Modèle, Vue, Logique métier séparés |
| **Extensibilité** | Facilité d'ajout de nouvelles fonctionnalités |
| **Maintenabilité** | Code organisé et documenté |
| **Testabilité** | Composants isolés testables unitairement |

---

## 🎯 Principes Architecturaux

### 1. Separation of Concerns (SoC)

Chaque package a une **responsabilité unique et bien définie** :

```python
models/        → QUOI (Données et entités du jeu)
managers/      → COMMENT (Logique métier et règles)
renderers/     → PRÉSENTATION (Affichage graphique)
utils/         → SUPPORT (Ressources et utilitaires)
```

**Avantage :** Modifications localisées sans impact sur les autres composants.

### 2. Don't Repeat Yourself (DRY)

- Classe abstraite `Item` évite la duplication
- `RandomManager` centralise tout l'aléatoire
- `ResourceManager` centralise les ressources graphiques

### 3. Single Responsibility Principle (SRP)

Chaque classe a une seule raison de changer :

```python
Player          → Gère UNIQUEMENT la position et le déplacement
Inventory       → Gère UNIQUEMENT les objets possédés
InteractionManager → Gère UNIQUEMENT les interactions
```

### 4. Open/Closed Principle (OCP)

**Ouvert à l'extension, fermé à la modification :**

```python
# Ajouter un nouvel objet sans modifier Item
class Torch(PermanentItem):
    def __init__(self):
        super().__init__(...)
```

### 5. Dependency Inversion Principle (DIP)

Les modules de haut niveau ne dépendent pas des détails :

```python
# BluePrinceGame dépend de l'abstraction Item
# Pas des classes concrètes Apple, Banana, etc.
inventory.use_food(food_name, player)  # Polymorphisme
```

---

## 📦 Organisation en Packages

### Structure Complète

```
blue-prince/
│
├── models/                          # 📦 MODÈLE (Entités du jeu)
│   ├── __init__.py                 # Exports du package
│   ├── item.py                     # ⭐ Hiérarchie d'objets (480 lignes)
│   ├── inventory.py                # 🎒 Gestion inventaire (368 lignes)
│   ├── door.py                     # 🚪 Système de portes (180 lignes)
│   ├── room.py                     # 🏠 Catalogue de pièces (520 lignes)
│   ├── player.py                   # 👤 Joueur (140 lignes)
│   └── manor.py                    # 🏰 Grille du manoir (80 lignes)
│
├── managers/                        # ⚙️ LOGIQUE MÉTIER (Règles du jeu)
│   ├── __init__.py
│   ├── random_manager.py           # 🎲 Aléatoire centralisé (200 lignes)
│   ├── interaction_manager.py      # 🔄 Interactions objets (350 lignes)
│   └── shop_manager.py             # 🛒 Système de magasin (100 lignes)
│
├── renderers/                       # 🎨 VUE (Interface Pygame)
│   ├── __init__.py
│   ├── grid_renderer.py            # 🗺️ Affichage grille (180 lignes)
│   ├── inventory_renderer.py       # 📋 Affichage inventaire (350 lignes)
│   └── room_selection_menu.py      # 📜 Menu sélection (250 lignes)
│
├── utils/                           # 🛠️ UTILITAIRES (Support)
│   ├── __init__.py
│   └── resource_manager.py         # 🎨 Polices/couleurs (100 lignes)
│
├── main.py                          # 🎯 CONTRÔLEUR (Orchestration - 433 lignes)
├── requirements.txt                 # 📋 Dépendances
├── README.md                        # 📖 Documentation utilisateur
├── ARCHITECTURE.md                  # 🏛️ Ce fichier
└── class_diagram.puml              # 📐 Diagramme UML
```

**Total : ~3500+ lignes de code**

---

## 🎓 Concepts POO Appliqués

### 1. Abstraction 🔷

#### Définition
L'abstraction consiste à **définir un contrat commun** sans spécifier l'implémentation.

#### Implémentation dans le projet

**Classe abstraite `Item` :**

```python
from abc import ABC, abstractmethod

class Item(ABC):
    """
    Classe abstraite représentant tous les objets du jeu.
    
    Définit le CONTRAT que tous les objets doivent respecter.
    """
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    
    @abstractmethod
    def use(self, player):
        """
        Méthode abstraite - DOIT être implémentée par les sous-classes.
        
        Force toutes les classes dérivées à définir comment l'objet s'utilise.
        """
        pass
```

#### Avantages

✅ **Interface unifiée** - Tous les objets ont une méthode `use()`  
✅ **Garantie de comportement** - Impossible d'instancier `Item` directement  
✅ **Documentation claire** - Le contrat est explicite  
✅ **Détection d'erreurs** - Python lève une erreur si `use()` n'est pas implémentée

---

### 2. Héritage 🌳

#### Définition
L'héritage permet de **créer des classes spécialisées** à partir d'une classe parent.

#### Hiérarchie Complète

```
Item (abstract)
│
├─ ConsumableItem                    # Objets qui s'épuisent
│  ├─ Steps         (70 initial)     # Ressource principale
│  ├─ Keys          (0 initial)      # Ouvrir portes
│  ├─ Gems          (2 initial)      # Sélectionner pièces rares
│  ├─ Coins         (0 initial)      # Monnaie d'échange
│  └─ Dice          (0 initial)      # Retirer le tirage
│
├─ PermanentItem                     # Objets qui restent
│  ├─ Shovel                         # Creuser
│  ├─ Hammer                         # Ouvrir coffres sans clé
│  ├─ LockpickKit                    # Ouvrir portes niveau 1
│  ├─ MetalDetector                  # Trouver plus de métaux
│  ├─ RabbitFoot                     # Augmenter la chance
│  ├─ Compass                        # Révéler pièces adjacentes
│  ├─ Map                            # Afficher grille complète
│  ├─ Torch                          # Réduire coût en pas
│  ├─ Spyglass                       # Révéler à distance
│  └─ Hourglass                      # Temps supplémentaire
│
└─ Food                              # Nourriture restaurative
   ├─ Apple         (+2 pas)
   ├─ Banana        (+3 pas)
   ├─ Cake          (+10 pas)
   ├─ Sandwich      (+15 pas)
   └─ Meal          (+25 pas)
```

#### Code Exemple

```python
class ConsumableItem(Item):
    """
    Spécialisation de Item pour les objets consommables.
    
    HÉRITE de Item et AJOUTE :
    - Un attribut 'quantity'
    - Des méthodes add() et remove()
    """
    
    def __init__(self, name: str, description: str, quantity: int = 1):
        super().__init__(name, description)  # Appel au constructeur parent
        self.quantity = quantity             # Ajout d'un attribut spécifique
    
    def add(self, amount: int):
        """Méthode spécifique aux consommables."""
        self.quantity += amount
    
    def use(self, player):
        """Implémentation concrète de la méthode abstraite."""
        return self.remove(1)
```

#### Avantages

✅ **Réutilisation du code** - Pas de duplication entre Steps, Keys, Gems  
✅ **Hiérarchie logique** - Structure claire et compréhensible  
✅ **Maintenance facilitée** - Modification dans Item profite à tous  
✅ **Extensibilité** - Facile d'ajouter de nouveaux types d'objets

---

### 3. Polymorphisme 🎭

#### Définition
Le polymorphisme permet d'utiliser **une même interface avec des comportements différents**.

#### Implémentation : Méthode `use()`

**Même méthode, comportements différents :**

```python
# 1. Food : Restaure des pas
class Food(Item):
    def use(self, player):
        player.inventory.steps.add(self.steps_restored)
        print(f"🍎 Restored {self.steps_restored} steps!")
        return True

# 2. Keys : Décrémente le compteur
class Keys(ConsumableItem):
    def use(self, player):
        if self.quantity > 0:
            return self.remove(1)
        return False

# 3. PermanentItem : Effet passif
class PermanentItem(Item):
    def use(self, player):
        # Ne se consomme jamais
        return True

# 4. Steps : Gère la fin de partie
class Steps(ConsumableItem):
    def use(self, player):
        if self.quantity > 0:
            return self.remove(1)
        # Plus de pas = défaite
        return False
```

#### Utilisation dans le code

```python
# Le code appelant n'a PAS besoin de connaître le type exact
def eat_food(inventory, food_name, player):
    """Utilise du polymorphisme pour manger n'importe quelle nourriture."""
    food_item = inventory.food_items[food_name]['item']
    
    # Appel polymorphique - le comportement dépend du type réel
    success = food_item.use(player)
    
    # Aucun if/elif nécessaire !
    return success
```

#### Avantages

✅ **Code générique** - Même code pour tous les objets  
✅ **Extensibilité** - Nouveau type = aucune modification du code appelant  
✅ **Lisibilité** - Pas de switch/case géant  
✅ **Flexibilité** - Comportement déterminé à l'exécution

---

### 4. Encapsulation 🔒

#### Définition
L'encapsulation consiste à **cacher les détails internes** et exposer une interface publique.

#### Implémentation

```python
class Door:
    """
    Encapsulation du système de portes.
    
    CACHE : Les détails de verrouillage
    EXPOSE : Une interface simple (can_open, open)
    """
    
    # Constantes publiques (interface)
    UNLOCKED = 0
    LOCKED = 1
    DOUBLE_LOCKED = 2
    
    def __init__(self, lock_level: int = UNLOCKED):
        # Attributs internes (par convention, pas de _ car Python accepte l'accès)
        self.lock_level = lock_level
        self.is_open = False
    
    # Interface publique simple
    def can_open(self, player) -> tuple[bool, str]:
        """
        Interface publique - cache la complexité interne.
        
        L'utilisateur n'a pas besoin de connaître :
        - Les niveaux de verrouillage
        - La logique du kit de crochetage
        - Les messages d'erreur
        """
        # Logique interne complexe encapsulée
        if self.lock_level == Door.UNLOCKED:
            return True, "Porte déverrouillée"
        
        if self.lock_level == Door.LOCKED:
            if player.inventory.has_permanent_item('lockpick_kit'):
                return True, "Kit de crochetage"
            if player.inventory.keys.quantity > 0:
                return True, "Clé disponible"
            return False, "Clé ou kit nécessaire"
        
        # ... (logique pour DOUBLE_LOCKED)
    
    def open(self, player) -> bool:
        """Interface publique simple pour ouvrir."""
        can_open, message = self.can_open(player)
        
        if can_open:
            # Gestion interne de la consommation
            self._consume_resources(player)
            self.is_open = True
        
        return can_open
```

#### Avantages

✅ **Simplicité d'utilisation** - Interface claire  
✅ **Flexibilité interne** - Peut changer l'implémentation sans casser le code client  
✅ **Robustesse** - Évite les manipulations incorrectes  
✅ **Maintenance** - Modifications localisées

---

### 5. Composition vs Agrégation 🔗

#### Différence Conceptuelle

| Relation | Symbole UML | Signification | Durée de vie |
|----------|-------------|---------------|--------------|
| **Composition** | ◆────● | "fait partie de" | Dépendante |
| **Agrégation** | ◇────○ | "contient" | Indépendante |

#### Composition : Player ◆──● Inventory

**Relation forte - Dépendance de vie**

```python
class Player:
    """
    COMPOSITION : Player POSSÈDE un Inventory.
    
    L'inventaire N'EXISTE PAS sans le joueur.
    Si le joueur est détruit, l'inventaire aussi.
    """
    
    def __init__(self, start_position: tuple):
        # Création directe - dépendance forte
        self.inventory = Inventory()  # ◆ Composition
        self.position = start_position
```

**Caractéristiques :**
- ◆ L'inventaire est créé DANS le constructeur de Player
- ◆ Un inventaire appartient à UN SEUL joueur
- ◆ Destruction du joueur → destruction de l'inventaire
- ◆ Relation "a un" forte

#### Agrégation : Manor ◇──○ Room

**Relation faible - Existence indépendante**

```python
class Manor:
    """
    AGRÉGATION : Manor CONTIENT des Room.
    
    Les pièces EXISTENT indépendamment du manoir.
    Elles sont créées avant d'être placées.
    """
    
    def __init__(self):
        # Grille vide initialement
        self.grid = [[None for _ in range(9)] for _ in range(5)]
    
    def place_room(self, room: Room, position: tuple):
        """
        Place une pièce EXISTANTE dans la grille.
        
        La pièce existe déjà (créée ailleurs).
        Le manoir ne fait que la RÉFÉRENCER.
        """
        row, col = position
        self.grid[row][col] = room  # ◇ Agrégation (référence)

# Les pièces existent dans un catalogue indépendant
room_catalog = create_room_catalog()  # Pièces créées

# Puis placées dans le manoir
manor.place_room(room_catalog[0], (4, 4))  # Référence
```

**Caractéristiques :**
- ◇ Les pièces existent AVANT d'être dans le manoir
- ◇ Une pièce peut exister sans manoir (catalogue)
- ◇ Destruction du manoir → les pièces existent toujours
- ◇ Relation "contient" faible

#### Tableau Récapitulatif

| Aspect | Composition (Player-Inventory) | Agrégation (Manor-Room) |
|--------|-------------------------------|------------------------|
| **Création** | Créé dans le constructeur | Créé séparément |
| **Propriété** | Appartient exclusivement | Partageable |
| **Durée de vie** | Liée au propriétaire | Indépendante |
| **Multiplicité** | 1 à 1 | 1 à plusieurs |
| **Exemple réel** | Cœur dans un corps | Livre dans une bibliothèque |

---

## 🎨 Patterns de Conception

### 1. Manager Pattern

#### Description
Centralise la logique métier dans des classes "Manager" spécialisées.

#### Implémentation

```python
class RandomManager:
    """
    MANAGER PATTERN
    
    Centralise TOUTE la génération aléatoire du jeu.
    
    Responsabilités :
    - Tirage de pièces avec probabilités
    - Génération de niveaux de portes
    - Tables de butin aléatoires
    - Modificateurs de probabilité
    """
    
    def __init__(self):
        self.color_modifiers = {
            'green': 1.0,
            'red': 1.0,
            # ...
        }
    
    def draw_rooms(self, available_rooms: list, count: int) -> list:
        """Tire des pièces avec pondération par rareté."""
        weights = [room.get_probability_weight() for room in available_rooms]
        return random.choices(available_rooms, weights=weights, k=count)
    
    @staticmethod
    def get_door_lock_level(row: int, max_rows: int) -> int:
        """Génère le niveau de porte selon la position."""
        # Progression : plus dur en haut
        ...
```

#### Avantages

✅ **Centralisation** - Un seul endroit pour l'aléatoire  
✅ **Testabilité** - Facile de mocker le RandomManager  
✅ **Équilibrage** - Modifications centralisées  
✅ **Réutilisabilité** - Partagé entre tous les composants

**Autres Managers dans le projet :**
- `InteractionManager` - Gère les interactions avec objets
- `ShopManager` - Gère le système de magasin

---

### 2. Template Method Pattern

#### Description
Définit le **squelette d'un algorithme** dans une classe mère, en déléguant certaines étapes aux sous-classes.

#### Implémentation : Classe Item

```python
class Item(ABC):
    """
    TEMPLATE METHOD PATTERN
    
    Définit la STRUCTURE commune à tous les objets.
    Les détails sont implémentés dans les sous-classes.
    """
    
    def __init__(self, name: str, description: str):
        # Étape 1 : Initialisation commune (template)
        self.name = name
        self.description = description
    
    @abstractmethod
    def use(self, player):
        # Étape 2 : Comportement spécifique (à définir)
        pass
    
    def __str__(self):
        # Étape 3 : Représentation commune (template)
        return f"{self.name}: {self.description}"

# Les sous-classes remplissent le "trou" (use)
class Food(Item):
    def use(self, player):
        # Implémentation spécifique pour Food
        player.inventory.steps.add(self.steps_restored)
        return True
```

#### Avantages

✅ **Réutilisation** - Comportements communs partagés  
✅ **Extension** - Facile d'ajouter de nouveaux types  
✅ **Consistance** - Structure uniforme garantie  
✅ **Maintenance** - Modifications du template profitent à tous

---

### 3. MVC (Model-View-Controller)

#### Description
Sépare l'application en 3 composants : Modèle, Vue, Contrôleur.

#### Implémentation dans Blue Prince

```
┌─────────────────────────────────────────────────────────┐
│                 CONTROLLER (Contrôleur)                 │
│                                                         │
│              BluePrinceGame (main.py)                   │
│  • Gère les événements utilisateur                     │
│  • Coordonne Modèle et Vue                             │
│  • Orchestre la logique de jeu                         │
└─────────────────────────────────────────────────────────┘
            │                               │
            ↓                               ↓
┌──────────────────────┐      ┌────────────────────────────┐
│  MODEL (Modèle)      │      │  VIEW (Vue)                │
│                      │      │                            │
│  models/             │      │  renderers/                │
│  • Item              │      │  • GridRenderer            │
│  • Inventory         │      │  • InventoryRenderer       │
│  • Door              │      │  • RoomSelectionMenu       │
│  • Room              │      │                            │
│  • Player            │      │  utils/                    │
│  • Manor             │      │  • ResourceManager         │
│                      │      │                            │
│  managers/           │      │  Responsabilité :          │
│  • RandomManager     │      │  AFFICHAGE                 │
│  • InteractionMgr    │      │  (Pygame)                  │
│  • ShopManager       │      │                            │
│                      │      │                            │
│  Responsabilité :    │      │                            │
│  DONNÉES + LOGIQUE   │      │                            │
└──────────────────────┘      └────────────────────────────┘
```

#### Séparation des Responsabilités

**MODÈLE (models/ + managers/) :**
```python
# Pure logique - AUCUN Pygame
class Player:
    def move(self, new_position: tuple, manor) -> bool:
        """Logique de déplacement - indépendante de l'affichage."""
        if self.inventory.steps.quantity <= 0:
            return False
        
        self.inventory.steps.use(self)
        self.position = new_position
        return True
```

**VUE (renderers/) :**
```python
# Pure affichage - AUCUNE logique métier
class GridRenderer:
    def render_grid(self, manor: Manor, player: Player):
        """Affichage - ne modifie JAMAIS les données."""
        for row in range(manor.height):
            for col in range(manor.width):
                self._render_cell(manor, player, row, col, x, y)
```

**CONTRÔLEUR (main.py) :**
```python
class BluePrinceGame:
    def handle_events(self):
        """Reçoit les événements utilisateur."""
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                self._handle_keypress(event.key)
    
    def _handle_keypress(self, key):
        """Coordonne Modèle et Vue."""
        if key == pygame.K_z:
            # 1. Appel au MODÈLE
            success = self.player.move(new_pos, self.manor)
            
            # 2. Mise à jour de la VUE (automatique dans render())
```

#### Avantages

✅ **Séparation claire** - Chaque composant a un rôle précis  
✅ **Testabilité** - Le modèle peut être testé sans Pygame  
✅ **Flexibilité** - Changement de Vue possible (terminal, web, etc.)  
✅ **Maintenance** - Modifications isolées par responsabilité

---

## 🔄 Flux de Données

### Cycle Complet d'une Action

#### Exemple : Le joueur appuie sur Z (aller au nord)

```
┌─────────────────────────────────────────────────────────────┐
│ 1. EVENT (Pygame)                                           │
│    Utilisateur appuie sur Z                                 │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. CONTROLLER (BluePrinceGame)                              │
│    handle_events() → détecte pygame.K_z                     │
│    _try_move_or_open_door('north', (-1, 0))                │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. MODÈLE - Vérifications (Manor)                          │
│    • Position valide ?                                      │
│    • Porte existante ?                                      │
│    • Porte ouverte ?                                        │
└─────────────────────────────────────────────────────────────┘
                         ↓
                    ┌────────┐
                    │ Porte  │
                    │fermée ?│
                    └────────┘
                    /        \
                 OUI          NON
                  ↓            ↓
┌──────────────────────┐  ┌──────────────────────┐
│ 4a. MODÈLE - Door    │  │ 4b. MODÈLE - Player  │
│  door.open(player)   │  │  player.move(...)    │
│  • Vérifie clés      │  │  • Consomme 1 pas    │
│  • Consomme clé      │  │  • Change position   │
│  • Tire 3 pièces     │  │  • Entre dans pièce  │
└──────────────────────┘  └──────────────────────┘
         ↓                          ↓
┌──────────────────────┐  ┌──────────────────────┐
│ 5a. CONTROLLER       │  │ 5b. MODÈLE - Room    │
│  Affiche menu        │  │  room.enter(player)  │
│  sélection           │  │  • Donne objets      │
└──────────────────────┘  │  • Active effets     │
                          └──────────────────────┘
                                     ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. VUE (Renderers)                                          │
│    • GridRenderer affiche la nouvelle position             │
│    • InventoryRenderer affiche les pas restants            │
└─────────────────────────────────────────────────────────────┘
```

### Flux de Données : Diagramme de Séquence

```
Utilisateur   BluePrinceGame   Manor   Door   Player   Room   Renderer
    │               │            │       │       │       │        │
    │──Appui Z──────>│            │       │       │       │        │
    │               │            │       │       │       │        │
    │               │─is_valid?─>│       │       │       │        │
    │               │<───Yes─────│       │       │       │        │
    │               │            │       │       │       │        │
    │               │────has_door?──────>│       │       │        │
    │               │<────Yes─────────────│       │       │        │
    │               │            │       │       │       │        │
    │               │────is_open?────────>│       │       │        │
    │               │<────No──────────────│       │       │        │
    │               │            │       │       │       │        │
    │               │────open(player)────>│       │       │        │
    │               │            │       │──has_key?──────>        │
    │               │            │       │<───Yes──────────│       │
    │               │            │       │──use_key()──────>│      │
    │               │<────Opened──────────│       │       │        │
    │               │            │       │       │       │        │
    │               │───────draw_rooms────>│      │       │        │
    │               │            │       │       │       │        │
    │               │[Menu selection]     │       │       │        │
    │               │            │       │       │       │        │
    │               │──────────move()────────────────────>│        │
    │               │            │       │       │       │        │
    │               │──────────enter()───────────────────>│        │
    │               │            │       │       │<─give_items─────│
    │               │            │       │       │       │        │
    │               │───────────render()─────────────────────────>│
    │<──Affichage───────────────────────────────────────────────────│
```

---

## 📐 Diagramme de Classes

### Vue Simplifiée

```
┌─────────────────────┐
│   Item (abstract)   │
│ ─────────────────── │
│ + name: str         │
│ + description: str  │
│ ─────────────────── │
│ + use(player): bool │◄───────────────────┐
└─────────────────────┘                    │
         △                                 │
         │ Héritage                        │
    ┌────┴────┬─────────────┐              │
    │         │             │              │
┌───▼──────┐ ┌▼─────────┐ ┌▼──────┐       │
│Consumable│ │Permanent │ │ Food  │       │
│   Item   │ │   Item   │ │       │       │
└──────────┘ └──────────┘ └───────┘       │
    △            △                         │
    │            │                         │
┌───┴───┐    ┌───┴────┐                   │
│Steps  │    │Shovel  │                   │
│Keys   │    │Hammer  │                   │
│Gems   │    │Lockpick│                   │
└───────┘    └────────┘                   │
                                          │
┌──────────────┐                          │
│  Inventory   │                          │
│ ──────────── │                          │
│ + steps      │◄─────────────────────────┘ Composition
│ + keys       │  (contient Items)
│ + gems       │
│ + permanent  │
│ + food       │
└──────────────┘
       △
       │ Composition
       │
┌──────▼───────┐         ┌──────────┐
│   Player     │         │  Manor   │
│ ──────────── │         │ ──────── │
│ + position   │◄───────►│ + grid   │ Association
│ + inventory  │         │ + width  │
│ ──────────── │         │ + height │
│ + move()     │         └──────────┘
└──────────────┘                │
                                │ Agrégation
                                │
                          ┌─────▼────┐
                          │   Room   │
                          │ ──────── │
                          │ + name   │
                          │ + color  │
                          │ + doors  │
                          │ + items  │
                          └──────────┘
                                │
                                │ Composition
                                │
                          ┌─────▼────┐
                          │   Door   │
                          │ ──────── │
                          │ + level  │
                          │ + is_open│
                          └──────────┘
```

### Diagramme UML Complet

Le diagramme UML complet est disponible dans le fichier `class_diagram.puml`.

**Pour le visualiser :**

1. **En ligne** (recommandé) :
   - Copier le contenu de `class_diagram.puml`
   - Aller sur http://www.plantuml.com/plantuml/uml/
   - Coller et télécharger l'image

2. **En local** :
   ```bash
   plantuml class_diagram.puml
   # Génère class_diagram.png
   ```

---

## 💡 Justifications des Choix

### Pourquoi cette structure en packages ?

#### ❓ Question
Pourquoi séparer `models/`, `managers/`, `renderers/` au lieu de tout mettre ensemble ?

#### ✅ Réponse

**1. Separation of Concerns (Séparation des préoccupations)**

Chaque package a une **responsabilité unique** :
- `models/` : "QUOI" (Les entités du jeu)
- `managers/` : "COMMENT" (Les règles du jeu)
- `renderers/` : "APPARENCE" (L'affichage)

**Bénéfices :**
- Modifications localisées (changer l'affichage n'impacte pas le modèle)
- Tests plus faciles (on peut tester le modèle sans Pygame)
- Collaboration facilitée (plusieurs développeurs sur différents packages)

**2. Maintenabilité**

```python
# ❌ AVANT (tout dans un fichier)
# blue_prince.py (10,000 lignes)
# Difficile de trouver une classe
# Difficile de comprendre les dépendances

# ✅ APRÈS (packages séparés)
models/item.py        # Je sais où chercher
renderers/grid.py     # Organisation claire
managers/random.py    # Facile à naviguer
```

**3. Réutilisabilité**

Les `models/` peuvent être réutilisés pour :
- Une version terminal du jeu
- Une version web (Flask/Django)
- Des tests automatisés
- Un serveur multijoueur

---

### Pourquoi l'abstraction avec `Item` ?

#### ❓ Question
Pourquoi créer une classe abstraite `Item` ? Pourquoi pas juste des classes indépendantes ?

#### ✅ Réponse

**1. Garantie de comportement**

```python
# Sans Item abstrait
class Apple:
    def eat(self, player):  # Méthode "eat"
        ...

class Key:
    def use(self, player):  # Méthode "use"
        ...

# ❌ Problème : Interface incohérente
# Comment appeler ? eat() ou use() ?
```

Avec `Item` abstrait :

```python
# ✅ Solution : Interface unifiée
class Item(ABC):
    @abstractmethod
    def use(self, player):
        pass

# Toutes les classes DOIVENT implémenter use()
# Garantie par Python (erreur si non implémenté)
```

**2. Polymorphisme**

```python
# Grâce à Item abstrait, ce code fonctionne pour TOUS les objets
def use_item(item: Item, player):
    item.use(player)  # Appel polymorphique
    
# Même code pour Apple, Key, Shovel, etc.
# Sans Item, il faudrait un if/elif pour chaque type
```

**3. Documentation du contrat**

`Item` documente explicitement : "Tous les objets doivent pouvoir être utilisés".

---

### Pourquoi 3 branches (Consumable, Permanent, Food) ?

#### ❓ Question
Pourquoi séparer Food de ConsumableItem ? La nourriture se consomme aussi.

#### ✅ Réponse

**Comportements fondamentalement différents :**

```python
# ConsumableItem : Décrémente un compteur
class Keys(ConsumableItem):
    def use(self, player):
        self.quantity -= 1  # Simple décrémentation
        return True

# Food : Restaure des pas (effet secondaire)
class Apple(Food):
    def use(self, player):
        player.inventory.steps.add(2)  # Modifie autre chose
        return True

# PermanentItem : Ne se consomme JAMAIS
class Shovel(PermanentItem):
    def use(self, player):
        return True  # Effet passif
```

**Bénéfices :**
- Clarté conceptuelle (3 types d'objets distincts)
- Facilite l'ajout de nouveaux objets
- Évite les vérifications if/else dans ConsumableItem

---

### Pourquoi Composition pour Player-Inventory ?

#### ❓ Question
Pourquoi Player possède-t-il un Inventory (composition) plutôt qu'une simple référence (agrégation) ?

#### ✅ Réponse

**Relation existentielle :**

```python
# COMPOSITION ◆
class Player:
    def __init__(self):
        self.inventory = Inventory()  # Créé ici
        # L'inventaire N'EXISTE PAS sans le joueur

# Si on détruit le joueur
del player
# → L'inventaire est aussi détruit (garbage collection)
```

Pourquoi pas agrégation ?

```python
# AGRÉGATION ◇ (alternative)
inventory = Inventory()  # Créé séparément
player = Player(inventory)  # Passé en paramètre

# ❌ Problème : Un inventaire sans joueur n'a pas de sens
# ❌ Complexité inutile : Qui crée l'inventaire ?
# ❌ Risques : Plusieurs joueurs pourraient partager un inventaire
```

**Composition = Relation forte et logique**

---

### Pourquoi Agrégation pour Manor-Room ?

#### ❓ Question
Pourquoi les Room ne sont-elles pas créées dans Manor ?

#### ✅ Réponse

**Existence indépendante :**

```python
# Les pièces existent dans un CATALOGUE
room_catalog = create_room_catalog()  # 25+ pièces créées

# Le manoir référence juste les pièces choisies
manor.place_room(room_catalog[5], (2, 3))

# ✅ Avantages :
# - Le catalogue existe même sans manoir
# - Plusieurs manoirs pourraient référencer les mêmes pièces
# - Tirage aléatoire depuis le catalogue
```

Si c'était une composition :

```python
# ❌ Problème
class Manor:
    def __init__(self):
        # Comment créer 25+ pièces ?
        # Comment tirer au hasard ?
        # Les pièces disparaissent si on détruit le manoir
```

**Agrégation = Flexibilité et réutilisabilité**

---

## 🔧 Décisions Techniques

### Choix de Pygame

#### Alternatives Considérées
- **Terminal** : Trop limité pour l'affichage
- **Tkinter** : Moins adapté pour les jeux
- **Kivy** : Plus complexe, overkill pour ce projet

#### Raisons du Choix
✅ **Simplicité** - API claire et bien documentée  
✅ **Performance** - Suffisante pour un jeu 2D  
✅ **Communauté** - Beaucoup de ressources  
✅ **Pédagogique** - Bon équilibre complexité/résultats

---

### Gestion de l'Aléatoire

#### Centralisation dans RandomManager

**Pourquoi centraliser ?**

```python
# ❌ AVANT : Aléatoire dispersé
class Room:
    def generate_loot(self):
        return random.choice([...])  # ❌ Difficile à tester

class Door:
    def __init__(self):
        self.level = random.randint(0, 2)  # ❌ Non reproductible

# ✅ APRÈS : Centralisé
class RandomManager:
    def get_loot(self):
        return random.choice([...])
    
    def get_door_level(self, row):
        return self._calculate_level(row)

# Avantages :
# - Tests reproductibles (mocker RandomManager)
# - Équilibrage centralisé
# - Seed pour debug (random.seed())
```

---

### Structure de Données pour la Grille

#### Choix : Liste 2D

```python
# Option choisie
self.grid = [[None for _ in range(9)] for _ in range(5)]

# Alternatives considérées :
# 1. Dictionnaire : {(row, col): room}
# 2. Liste 1D : [None] * 45
```

#### Justification

✅ **Accès naturel** : `grid[row][col]`  
✅ **Itération facile** : Boucles for imbriquées  
✅ **Visuel** : Structure proche du rendu  
✅ **Performance** : O(1) pour l'accès

---

## 📈 Évolution et Extensibilité

### Comment Ajouter un Nouveau Type d'Objet ?

```python
# 1. Choisir la branche appropriée
class Compass(PermanentItem):  # Nouvel objet permanent
    
    def __init__(self):
        super().__init__(
            name="Compass",
            description="Reveals adjacent rooms",
            effect_description="See around you"
        )
    
    def use(self, player):
        # Effet spécifique
        reveal_adjacent_rooms(player.position)
        return True

# 2. Ajouter au catalogue dans inventory.py
PERMANENT_ITEMS = {
    # ...
    'compass': Compass()
}

# 3. C'est tout ! ✅
# Pas besoin de modifier :
# - Item (abstraction)
# - Inventory (polymorphisme)
# - Renderers (affichage générique)
```

---

### Comment Ajouter une Nouvelle Pièce ?

```python
# Dans room.py, fonction create_room_catalog()

def magic_library_effect(player, room):
    """Bibliothèque magique : donne des dés."""
    player.inventory.add_item("dice", 2)
    print("📚 Found 2 magical dice!")

catalog.append(Room(
    name="Magic Library",
    color=RoomColor.PURPLE,
    rarity=2,  # Pièce rare
    gem_cost=2,
    items=["gems", "chest"],
    on_enter_effect=magic_library_effect
))

# ✅ Ajoutée automatiquement au tirage !
```

---

### Comment Changer l'Affichage ?

```python
# Créer un nouveau renderer
class TerminalRenderer:
    """Affichage en mode terminal (alternative à Pygame)."""
    
    def render_grid(self, manor, player):
        """Affiche la grille en ASCII."""
        for row in range(manor.height):
            for col in range(manor.width):
                if (row, col) == player.position:
                    print("@", end=" ")
                else:
                    print(".", end=" ")
            print()

# Dans main.py
# self.grid_renderer = GridRenderer(...)  # Pygame
self.grid_renderer = TerminalRenderer()   # Terminal

# ✅ Le modèle reste IDENTIQUE !
# C'est la puissance du MVC
```

---

## 🎓 Conclusion

### Points Clés de l'Architecture

1. **Modularité** - 4 packages avec responsabilités claires
2. **POO Solide** - Abstraction, héritage, polymorphisme, encapsulation
3. **Patterns** - Manager, Template Method, MVC
4. **Extensibilité** - Facile d'ajouter fonctionnalités
5. **Maintenabilité** - Code organisé et documenté

### Compétences Démontrées

✅ Maîtrise des concepts POO fondamentaux  
✅ Application de patterns de conception  
✅ Architecture logicielle structurée  
✅ Séparation Modèle-Vue-Contrôleur  
✅ Code propre et maintenable

---

## 📚 Références

- [Python Official Documentation](https://docs.python.org/3/)
- [Design Patterns in Python](https://refactoring.guru/design-patterns/python)
- [SOLID Principles](https://en.wikipedia.org/wiki/SOLID)
- [MVC Pattern](https://en.wikipedia.org/wiki/Model%E2%80%93view%E2%80%93controller)
- [UML Class Diagrams](https://www.uml-diagrams.org/class-diagrams-overview.html)

---

<div align="center">

**🏛️ Architecture Blue Prince**

*Documentation réalisée dans le cadre du projet POO 2025*  
*Master 1 Systèmes Communicants - Sorbonne Université*

**Auteur:** CHABANE CHAOCUHE Mohand  
**Date:** Novembre 2025

</div>