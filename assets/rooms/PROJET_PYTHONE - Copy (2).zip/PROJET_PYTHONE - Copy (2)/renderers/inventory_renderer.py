"""
Rendu de l'inventaire.

Jour 7 : Affichage complet avec objets permanents et nourriture.

Ce module gère l'affichage de l'inventaire du joueur avec :
- Objets consommables (pas, clés, gemmes, pièces, dés)
- Objets permanents (équipement spécial)
- Nourriture (objets restauratifs)
- Interface visuelle claire et organisée
"""

import pygame
from models.inventory import Inventory
from utils.resource_manager import ResourceManager


class InventoryRenderer:
    """
    Affiche l'inventaire du joueur sur le côté de l'écran.
    
    Attributes:
        screen (pygame.Surface): Surface d'affichage
        resources (ResourceManager): Gestionnaire de ressources
        panel_x (int): Position X du panneau
        panel_y (int): Position Y du panneau  
        panel_width (int): Largeur du panneau
        panel_height (int): Hauteur du panneau
        animation_time (int): Compteur pour les animations
    """
    
    def __init__(self, screen: pygame.Surface, resources: ResourceManager):
        """
        Initialise le renderer d'inventaire.
        
        Args:
            screen: Surface Pygame pour l'affichage
            resources: Gestionnaire des ressources graphiques
        """
        self.screen = screen
        self.resources = resources
        
        # ✅ AUGMENTATION: Position et dimensions pour plus d'espace
        self.panel_x = 1500  # ← Plus à droite
        self.panel_y = 40   # ← Plus en haut
        self.panel_width = 400  # ← Légèrement plus large
        self.panel_height = 720  # ← Plus haut
        
        # Animations
        self.animation_time = 0
        self.pulse_value = 0
        
    def render(self, inventory: Inventory):
        """
        Affiche l'inventaire complet du joueur.
        
        Args:
            inventory: Inventaire du joueur à afficher
        """
        # Mise à jour des animations
        self.animation_time += 1
        self.pulse_value = abs(pygame.time.get_ticks() % 1000 - 500) / 500
        
        # Panneau de fond avec effet de profondeur
        panel_rect = pygame.Rect(
            self.panel_x,
            self.panel_y, 
            self.panel_width,
            self.panel_height
        )
        
        # Ombre portée
        shadow_rect = pygame.Rect(
            self.panel_x + 6,
            self.panel_y + 6,
            self.panel_width,
            self.panel_height
        )
        pygame.draw.rect(
            self.screen,
            (30, 30, 40, 180),
            shadow_rect,
            border_radius=15
        )
        
        # Panneau principal avec coins arrondis
        pygame.draw.rect(
            self.screen,
            self.resources.get_color('panel'),
            panel_rect,
            border_radius=15
        )
        
        # Bordure avec dégradé
        border_color = self._get_pulsing_border_color()
        pygame.draw.rect(
            self.screen,
            border_color,
            panel_rect,
            3,
            border_radius=15
        )
        
        # Titre de l'inventaire avec effet
        self._render_title()
        
        # ✅ AUGMENTATION: Plus d'espace après le titre
        y_offset = self.panel_y + 100
        
        # 1. Objets consommables
        y_offset = self._render_consumables(inventory, y_offset)
        
        # ✅ AUGMENTATION: Espace supplémentaire entre sections
        y_offset += 20
        
        # 2. Nourriture
        y_offset = self._render_food(inventory, y_offset)
        
        # ✅ AUGMENTATION: Espace supplémentaire entre sections
        y_offset += 20
        
        # 3. Objets permanents
        self._render_permanent_items(inventory, y_offset)
    
    def _get_pulsing_border_color(self):
        """Retourne une couleur de bordure qui pulse légèrement."""
        base_color = self.resources.get_color('panel_border')
        pulse_factor = 0.9 + 0.1 * self.pulse_value
        return (
            min(255, int(base_color[0] * pulse_factor)),
            min(255, int(base_color[1] * pulse_factor)),
            min(255, int(base_color[2] * pulse_factor))
        )
    
    def _render_title(self):
        """Affiche le titre de l'inventaire avec effets."""
        font_title = self.resources.get_font('large')
        
        # Ombre portée pour le titre
        title_shadow = font_title.render("INVENTORY", True, (30, 30, 60))
        title_shadow_rect = title_shadow.get_rect(
            centerx=self.panel_x + self.panel_width // 2 + 2, 
            y=self.panel_y + 32  # ← Plus bas
        )
        self.screen.blit(title_shadow, title_shadow_rect)
        
        # Titre principal
        title = font_title.render("INVENTORY", True, self.resources.get_color('text'))
        title_rect = title.get_rect(
            centerx=self.panel_x + self.panel_width // 2, 
            y=self.panel_y + 30  # ← Plus bas
        )
        self.screen.blit(title, title_rect)
        
        # ✅ AUGMENTATION: Ligne décorative plus basse
        line_y = self.panel_y + 80  # ← Plus d'espace sous le titre
        pygame.draw.line(
            self.screen,
            self.resources.get_color('panel_border'),
            (self.panel_x + 40, line_y),  # ← Marges plus grandes
            (self.panel_x + self.panel_width - 40, line_y),
            2
        )
    
    def _render_consumables(self, inventory: Inventory, start_y: int) -> int:
        """
        Affiche la section des objets consommables.
        
        Args:
            inventory: Inventaire du joueur
            start_y: Position Y de départ
            
        Returns:
            int: Nouvelle position Y après affichage
        """
        font_item = self.resources.get_font('medium')
        font_small = self.resources.get_font('small')
        y_offset = start_y
        
        # ✅ AUGMENTATION: En-tête plus grand et mieux espacé
        section_rect = pygame.Rect(
            self.panel_x + 25,  # ← Marge gauche augmentée
            y_offset - 10,
            self.panel_width - 50,  # ← Marge droite augmentée
            50  # ← Plus haut
        )
        pygame.draw.rect(
            self.screen,
            self.resources.get_color('panel_dark'),
            section_rect,
            border_radius=10
        )
        
        section_title = font_item.render("📦 CONSUMABLES", True, self.resources.get_color('text'))
        self.screen.blit(section_title, (self.panel_x + 45, y_offset + 10))  # ← Centré verticalement
        y_offset += 70  # ← Plus d'espace après l'en-tête
        
        # Liste des objets consommables
        consumables = [
            ("Steps", inventory.steps.quantity, "👣", "Steps remaining", (100, 200, 100)),
            ("Keys", inventory.keys.quantity, "🔑", "Keys for locked doors", (255, 200, 50)),
            ("Gems", inventory.gems.quantity, "💎", "Gems for special rooms", (180, 100, 255)),
            ("Coins", inventory.coins.quantity, "🪙", "Gold coins collected", (255, 215, 0)),
            ("Dice", inventory.dice.quantity, "🎲", "Dice to reroll selection", (100, 150, 255))
        ]
        
        for name, quantity, icon, description, glow_color in consumables:
            # Effet de brillance pour les quantités importantes
            is_highlighted = quantity > 10 and name in ["Coins", "Gems"]
            
            # ✅ AUGMENTATION: Ligne plus haute et mieux espacée
            line_rect = pygame.Rect(
                self.panel_x + 25,  # ← Marge gauche
                y_offset - 5,
                self.panel_width - 50,  # ← Marge droite
                60  # ← Plus haute
            )
            
            # Couleur de fond alternée
            if consumables.index((name, quantity, icon, description, glow_color)) % 2 == 0:
                bg_color = self.resources.get_color('panel_light')
            else:
                bg_color = self.resources.get_color('panel')
                
            if is_highlighted:
                # Effet de brillance pour les objets importants
                glow_alpha = int(50 + 25 * self.pulse_value)
                glow_surface = pygame.Surface((line_rect.width, line_rect.height), pygame.SRCALPHA)
                pygame.draw.rect(glow_surface, (*glow_color, glow_alpha), glow_surface.get_rect(), border_radius=8)
                self.screen.blit(glow_surface, line_rect)
            
            pygame.draw.rect(
                self.screen,
                bg_color,
                line_rect,
                border_radius=8
            )
            
            # Bordure subtile
            pygame.draw.rect(
                self.screen,
                self.resources.get_color('panel_border'),
                line_rect,
                1,
                border_radius=8
            )
            
            # ✅ AUGMENTATION: Contenu mieux espacé verticalement
            icon_text = font_item.render(icon, True, self.resources.get_color('text'))
            self.screen.blit(icon_text, (self.panel_x + 45, y_offset + 10))  # ← Décalé vers le bas
            
            name_text = font_item.render(name, True, self.resources.get_color('text'))
            self.screen.blit(name_text, (self.panel_x + 95, y_offset + 8))   # ← Plus à droite
            
            desc_text = font_small.render(description, True, self.resources.get_color('text_dark'))
            self.screen.blit(desc_text, (self.panel_x + 95, y_offset + 30))  # ← Plus d'espace
            
            # Quantité avec style
            qty_color = self.resources.get_color('text')
            if quantity == 0:
                qty_color = (200, 100, 100)
            elif is_highlighted:
                qty_color = glow_color
                
            qty_text = font_item.render(str(quantity), True, qty_color)
            qty_rect = qty_text.get_rect(right=self.panel_x + self.panel_width - 35)  # ← Marge droite
            qty_rect.y = y_offset + 12
            
            # Fond pour la quantité
            qty_bg = pygame.Rect(qty_rect.x - 8, qty_rect.y - 4, qty_rect.width + 16, qty_rect.height + 8)
            pygame.draw.rect(self.screen, self.resources.get_color('panel_dark'), qty_bg, border_radius=6)
            pygame.draw.rect(self.screen, self.resources.get_color('panel_border'), qty_bg, 1, border_radius=6)
            
            self.screen.blit(qty_text, qty_rect)
            
            y_offset += 70  # ← Plus d'espace entre les lignes
        
        # ✅ AUGMENTATION: Séparateur plus espacé
        y_offset += 20
        self._render_separator(y_offset)
        y_offset += 30
        
        return y_offset
    
    def _render_food(self, inventory: Inventory, start_y: int) -> int:
        """
        Affiche la section de la nourriture.
        
        Args:
            inventory: Inventaire du joueur
            start_y: Position Y de départ
            
        Returns:
            int: Nouvelle position Y après affichage
        """
        font_item = self.resources.get_font('medium')
        font_small = self.resources.get_font('small')
        y_offset = start_y
        
        # En-tête de section avec icône
        section_rect = pygame.Rect(
            self.panel_x + 25,
            y_offset - 10,
            self.panel_width - 50,
            50
        )
        pygame.draw.rect(
            self.screen,
            self.resources.get_color('panel_dark'),
            section_rect,
            border_radius=10
        )
        
        section_title = font_item.render("🍎 FOOD", True, self.resources.get_color('text'))
        self.screen.blit(section_title, (self.panel_x + 45, y_offset + 10))
        y_offset += 70
        
        # Icônes de nourriture avec couleurs
        food_data = {
            "apple": ("🍎", "Apple", (150, 220, 100)),
            "banana": ("🍌", "Banana", (240, 220, 80)), 
            "cake": ("🍰", "Cake", (240, 180, 180)),
            "sandwich": ("🥪", "Sandwich", (220, 180, 120)),
            "meal": ("🍽️", "Full Meal", (180, 220, 240))
        }
        
        has_food = False
        food_items = list(inventory.food_items.items())
        
        for i, (food_name, food_data_item) in enumerate(food_items):
            has_food = True
            quantity = food_data_item['quantity']
            food_item = food_data_item['item']
            
            icon, display_name, glow_color = food_data.get(food_name, ("🍎", food_name, (200, 200, 200)))
            
            # ✅ AUGMENTATION: Ligne plus haute
            line_rect = pygame.Rect(
                self.panel_x + 25,
                y_offset - 5,
                self.panel_width - 50,
                60
            )
            
            # Fond alterné
            bg_color = self.resources.get_color('panel_light') if i % 2 == 0 else self.resources.get_color('panel')
            pygame.draw.rect(
                self.screen,
                bg_color,
                line_rect,
                border_radius=8
            )
            
            # Bordure subtile
            pygame.draw.rect(
                self.screen,
                self.resources.get_color('panel_border'),
                line_rect,
                1,
                border_radius=8
            )
            
            # Contenu mieux espacé
            icon_text = font_item.render(icon, True, self.resources.get_color('text'))
            self.screen.blit(icon_text, (self.panel_x + 45, y_offset + 10))
            
            name_text = font_item.render(display_name, True, self.resources.get_color('text'))
            self.screen.blit(name_text, (self.panel_x + 95, y_offset + 8))
            
            desc_text = font_small.render(f"Restores {food_item.steps_restored} steps", True, self.resources.get_color('text_dark'))
            self.screen.blit(desc_text, (self.panel_x + 95, y_offset + 30))
            
            # Quantité avec style
            qty_text = font_item.render(f"x{quantity}", True, self.resources.get_color('text'))
            qty_rect = qty_text.get_rect(right=self.panel_x + self.panel_width - 35)
            qty_rect.y = y_offset + 12
            
            qty_bg = pygame.Rect(qty_rect.x - 8, qty_rect.y - 4, qty_rect.width + 16, qty_rect.height + 8)
            pygame.draw.rect(self.screen, self.resources.get_color('panel_dark'), qty_bg, border_radius=6)
            pygame.draw.rect(self.screen, self.resources.get_color('panel_border'), qty_bg, 1, border_radius=6)
            
            self.screen.blit(qty_text, qty_rect)
            
            y_offset += 70
        
        if not has_food:
            # Message stylisé quand pas de nourriture
            empty_rect = pygame.Rect(
                self.panel_x + 25,
                y_offset - 5,
                self.panel_width - 50,
                50
            )
            pygame.draw.rect(
                self.screen,
                self.resources.get_color('panel_light'),
                empty_rect,
                border_radius=8
            )
            
            none_text = font_small.render("🍽️ No food items available", True, self.resources.get_color('text_dark'))
            none_rect = none_text.get_rect(center=empty_rect.center)
            self.screen.blit(none_text, none_rect)
            y_offset += 60
        
        # Ligne de séparation
        y_offset += 20
        self._render_separator(y_offset)
        y_offset += 30
        
        return y_offset
    
    def _render_permanent_items(self, inventory: Inventory, start_y: int):
        """
        Affiche la section des objets permanents.
        
        Args:
            inventory: Inventaire du joueur
            start_y: Position Y de départ
        """
        font_item = self.resources.get_font('medium')
        font_small = self.resources.get_font('small')
        y_offset = start_y
        
        # En-tête de section avec icône
        section_rect = pygame.Rect(
            self.panel_x + 25,
            y_offset - 10,
            self.panel_width - 50,
            50
        )
        pygame.draw.rect(
            self.screen,
            self.resources.get_color('panel_dark'),
            section_rect,
            border_radius=10
        )
        
        section_title = font_item.render("🛠️ EQUIPMENT", True, self.resources.get_color('text'))
        self.screen.blit(section_title, (self.panel_x + 45, y_offset + 10))
        y_offset += 70
        
        # Icônes et descriptions
        permanent_data = {
            "shovel": ("⛏️", "Dig for hidden treasures", (150, 120, 80)),
            "hammer": ("🔨", "Open chests without keys", (180, 100, 80)), 
            "lockpick_kit": ("🔓", "Open level 1 locked doors", (80, 150, 220)),
            "metal_detector": ("📡", "Find more keys and coins", (100, 180, 220)),
            "rabbit_foot": ("🍀", "Increase overall luck", (120, 200, 100)),
            "compass": ("🧭", "Reveals adjacent rooms", (80, 160, 220)),
            "map": ("🗺️", "Shows complete manor grid", (160, 120, 220)),
            "torch": ("🔦", "Reduces step cost by 1", (220, 180, 60)),
            "spyglass": ("🔭", "Reveals distant rooms", (60, 140, 200)),
            "hourglass": ("⏳", "Grants extra steps", (180, 160, 120))
        }
        
        has_any_permanent = False
        permanent_items = list(inventory.permanent_items.items())
        
        for i, (item_name, item) in enumerate(permanent_items):
            if item:
                has_any_permanent = True
                icon, description, glow_color = permanent_data.get(item_name, ("🛠️", "Special equipment", (200, 200, 200)))
                
                # ✅ AUGMENTATION: Ligne plus haute pour l'équipement
                line_rect = pygame.Rect(
                    self.panel_x + 25,
                    y_offset - 5,
                    self.panel_width - 50,
                    70  # ← Plus haute
                )
                
                # Effet de brillance pour l'équipement
                glow_alpha = int(30 + 15 * self.pulse_value)
                glow_surface = pygame.Surface((line_rect.width, line_rect.height), pygame.SRCALPHA)
                pygame.draw.rect(glow_surface, (*glow_color, glow_alpha), glow_surface.get_rect(), border_radius=10)
                self.screen.blit(glow_surface, line_rect)
                
                # Fond principal
                bg_color = self.resources.get_color('panel_light') if i % 2 == 0 else self.resources.get_color('panel')
                pygame.draw.rect(
                    self.screen,
                    bg_color,
                    line_rect,
                    border_radius=10
                )
                
                # Bordure colorée selon l'objet
                pygame.draw.rect(
                    self.screen,
                    glow_color,
                    line_rect,
                    2,
                    border_radius=10
                )
                
                # Contenu mieux espacé
                icon_text = font_item.render(icon, True, self.resources.get_color('text'))
                self.screen.blit(icon_text, (self.panel_x + 45, y_offset + 10))
                
                name_text = font_item.render(item.name, True, self.resources.get_color('text'))
                self.screen.blit(name_text, (self.panel_x + 95, y_offset + 8))
                
                desc_text = font_small.render(description, True, self.resources.get_color('text_dark'))
                self.screen.blit(desc_text, (self.panel_x + 95, y_offset + 30))
                
                # Indicateur "EQUIPPED"
                equipped_text = font_small.render("EQUIPPED", True, (100, 200, 100))
                equipped_rect = equipped_text.get_rect(right=self.panel_x + self.panel_width - 35, top=y_offset + 10)
                self.screen.blit(equipped_text, equipped_rect)
                
                y_offset += 80  # ← Plus d'espace entre les équipements
        
        if not has_any_permanent:
            # Message stylisé quand pas d'équipement
            empty_rect = pygame.Rect(
                self.panel_x + 25,
                y_offset - 5,
                self.panel_width - 50,
                60
            )
            pygame.draw.rect(
                self.screen,
                self.resources.get_color('panel_light'),
                empty_rect,
                border_radius=10
            )
            
            none_text = font_small.render("🛠️ No equipment yet", True, self.resources.get_color('text_dark'))
            none_rect = none_text.get_rect(center=empty_rect.center)
            self.screen.blit(none_text, none_rect)
    
    def _render_separator(self, y_pos: int):
        """
        Affiche une ligne de séparation décorative.
        
        Args:
            y_pos: Position Y de la ligne
        """
        # Ligne avec effet de dégradé
        for i in range(5):
            alpha = 200 - i * 40
            color = (*self.resources.get_color('panel_border')[:3], alpha)
            line_surface = pygame.Surface((self.panel_width - 80, 1), pygame.SRCALPHA)  # ← Plus court
            line_surface.fill(color)
            self.screen.blit(line_surface, (self.panel_x + 40, y_pos + i))  # ← Centré


# ============================================================================
# Tests du module
# ============================================================================

if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((1200, 800))
    pygame.display.set_caption("Inventory Renderer Test - Spaced")
    
    resources = ResourceManager()
    
    # Création d'un inventaire de test complet
    inventory = Inventory()
    inventory.add_item("keys", 8)
    inventory.add_item("coins", 275)
    inventory.add_item("gems", 5)
    inventory.add_item("dice", 3)
    
    # Ajout de quelques objets permanents
    permanent_items = ["shovel", "hammer", "lockpick_kit", "torch"]
    
    for item in permanent_items:
        inventory.add_permanent_item(item)
    
    # Ajout de nourriture variée
    inventory.add_food("apple", 3)
    inventory.add_food("cake", 1)
    inventory.add_food("meal", 1)
    
    renderer = InventoryRenderer(screen, resources)
    
    # Boucle de test
    running = True
    clock = pygame.time.Clock()
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
        
        # Rendu
        screen.fill(resources.get_color('background'))
        renderer.render(inventory)
        
        # Instructions
        font = resources.get_font('small')
        instructions = font.render("Press ESC to exit - Spaced Inventory Renderer Test", True, resources.get_color('text'))
        screen.blit(instructions, (20, 20))
        
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()