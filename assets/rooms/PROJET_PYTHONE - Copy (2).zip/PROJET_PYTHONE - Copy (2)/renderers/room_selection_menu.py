"""
Menu de sélection de pièces.
Jour 6 : Interface pour choisir parmi 3 pièces tirées.
"""

import pygame
from utils.resource_manager import ResourceManager


class RoomSelectionMenu:
    """Menu de sélection de pièce avec design amélioré."""
    
    def __init__(self, screen: pygame.Surface, resources: ResourceManager):
        self.screen = screen
        self.resources = resources
        
        self.is_visible = False
        self.rooms = []
        self.selected_index = 0
        self.callback = None
        
        # Animation
        self.animation_progress = 0  # 0 à 100
        self.animation_speed = 8
        
        # Position du menu (centré)
        self.menu_width = 1050
        self.menu_height = 650  # Augmenté pour plus d'espace
        self.menu_x = (screen.get_width() - self.menu_width) // 2
        self.menu_y = (screen.get_height() - self.menu_height) // 2 - 50  # Remonté un peu
        
        # Effets visuels
        self.selection_pulse = 0
        self.pulse_speed = 0.1
    
    def show(self, rooms: list, on_select_callback):
        """Affiche le menu avec les pièces proposées."""
        self.rooms = rooms
        self.selected_index = 0
        self.callback = on_select_callback
        self.is_visible = True
        self.animation_progress = 0  # Début animation
    
    def hide(self):
        """Cache le menu."""
        self.is_visible = False
        self.rooms = []
        self.animation_progress = 0
    
    def update(self):
        """Met à jour les animations."""
        if not self.is_visible:
            return
        
        # Animation d'entrée
        if self.animation_progress < 100:
            self.animation_progress = min(100, self.animation_progress + self.animation_speed)
        
        # Pulsation de sélection
        self.selection_pulse = (self.selection_pulse + self.pulse_speed) % 100
    
    def handle_input(self, event: pygame.event.Event) -> bool:
        """
        Gère les entrées du menu.
        Returns: True si l'événement a été géré.
        """
        if not self.is_visible:
            return False
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.selected_index = (self.selected_index - 1) % len(self.rooms)
                self._play_selection_sound()
                return True
            elif event.key == pygame.K_RIGHT:
                self.selected_index = (self.selected_index + 1) % len(self.rooms)
                self._play_selection_sound()
                return True
            elif event.key == pygame.K_RETURN:
                self._select_room()
                return True
            elif event.key == pygame.K_ESCAPE:
                self.hide()
                return True
        
        return False
    
    def _play_selection_sound(self):
        """Joue un son de sélection (à implémenter avec resource_manager)."""
        # Pourrait être ajouté plus tard
        pass
    
    def _select_room(self):
        """Sélectionne la pièce courante."""
        if 0 <= self.selected_index < len(self.rooms):
            selected_room = self.rooms[self.selected_index]
            if self.callback:
                self.callback(selected_room)
            self.hide()
    
    def render(self, inventory):
        """Affiche le menu avec animations."""
        if not self.is_visible:
            return
        
        # Calcul de l'opacité basée sur l'animation
        alpha = int(255 * (self.animation_progress / 100))
        
        # Overlay semi-transparent avec animation
        overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, int(180 * (self.animation_progress / 100))))
        self.screen.blit(overlay, (0, 0))
        
        # Animation de scale pour le panneau
        scale_factor = 0.8 + (0.2 * (self.animation_progress / 100))
        current_width = int(self.menu_width * scale_factor)
        current_height = int(self.menu_height * scale_factor)
        current_x = (self.screen.get_width() - current_width) // 2
        current_y = (self.screen.get_height() - current_height) // 2 - 50
        
        # Panneau du menu avec ombre
        menu_rect = pygame.Rect(current_x, current_y, current_width, current_height)
        
        # Ombre
        shadow_rect = menu_rect.move(8, 8)
        pygame.draw.rect(self.screen, (0, 0, 0, 100), shadow_rect, border_radius=15)
        
        # Panneau principal
        pygame.draw.rect(self.screen, self.resources.get_color('panel'), menu_rect, border_radius=15)
        pygame.draw.rect(self.screen, self.resources.get_color('panel_border'), menu_rect, 4, border_radius=15)
        
        # Titre avec effet
        font_title = self.resources.get_font('large')
        title = font_title.render("CHOOSE YOUR PATH", True, self.resources.get_color('text_highlight'))
        title_rect = title.get_rect(centerx=self.screen.get_width() // 2, y=current_y + 30)
        
        # Ombre du titre
        title_shadow = font_title.render("CHOOSE YOUR PATH", True, (0, 0, 0, 100))
        self.screen.blit(title_shadow, title_rect.move(2, 2))
        self.screen.blit(title, title_rect)
        
        # Affiche les 3 pièces avec animation
        room_width = 250
        room_height = 280  # Augmenté pour plus d'infos
        spacing = 30
        start_x = current_x + (current_width - (3 * room_width + 2 * spacing)) // 2
        start_y = current_y + 100
        
        for i, room in enumerate(self.rooms):
            x = start_x + i * (room_width + spacing)
            # Animation d'entrée décalée
            room_alpha = min(255, alpha + (i * 20))
            self._render_room_card(room, x, start_y, room_width, room_height, 
                                 i == self.selected_index, inventory, room_alpha)
        
        # Instructions avec style
        font_inst = self.resources.get_font('small')
        instructions = [
            "← → : Navigate between rooms",
            "ENTER : Select room", 
            "ESC : Cancel selection"
        ]
        
        for i, instruction in enumerate(instructions):
            inst_text = font_inst.render(instruction, True, self.resources.get_color('text_dark'))
            inst_rect = inst_text.get_rect(centerx=self.screen.get_width() // 2, 
                                         y=current_y + current_height - 60 + i * 25)
            self.screen.blit(inst_text, inst_rect)
    
    def _render_room_card(self, room, x: int, y: int, width: int, height: int, 
                         is_selected: bool, inventory, alpha: int = 255):
        """Affiche une carte de pièce avec effets visuels."""
        # Effet de pulsation pour la sélection
        pulse_scale = 1.0
        if is_selected:
            pulse_value = abs((self.selection_pulse - 50) / 50)  # 0 à 1
            pulse_scale = 1.0 + (pulse_value * 0.05)  # +5% de scale
        
        current_width = int(width * pulse_scale)
        current_height = int(height * pulse_scale)
        current_x = x + (width - current_width) // 2
        current_y = y + (height - current_height) // 2
        
        card_rect = pygame.Rect(current_x, current_y, current_width, current_height)
        
        # Couleur de fond avec dégradé
        base_color = self.resources.get_color(room.color.value)
        if is_selected:
            # Éclaircir la couleur pour l'effet de sélection
            highlight_color = tuple(min(255, c + 40) for c in base_color)
            # Dégradé
            for i in range(current_height):
                ratio = i / current_height
                color = tuple(int(base_color[j] * (1 - ratio) + highlight_color[j] * ratio) for j in range(3))
                pygame.draw.line(self.screen, color, 
                               (current_x, current_y + i), 
                               (current_x + current_width, current_y + i))
        else:
            pygame.draw.rect(self.screen, base_color, card_rect, border_radius=12)
        
        # Bordure avec effet
        border_color = self.resources.get_color('text_highlight') if is_selected else self.resources.get_color('panel_border')
        border_width = 6 if is_selected else 3
        
        pygame.draw.rect(self.screen, border_color, card_rect, border_width, border_radius=12)
        
        # Effet de brillance pour la sélection
        if is_selected:
            glow_surf = pygame.Surface((current_width, current_height), pygame.SRCALPHA)
            for i in range(3):
                glow_rect = pygame.Rect(i, i, current_width - 2*i, current_height - 2*i)
                glow_alpha = 50 - (i * 15)
                pygame.draw.rect(glow_surf, (*border_color[:3], glow_alpha), glow_rect, 2, border_radius=12)
            self.screen.blit(glow_surf, (current_x, current_y))
        
        # Nom de la pièce
        font_name = self.resources.get_font('medium_bold')
        name_lines = self._wrap_text(room.name, font_name, current_width - 30)
        
        y_offset = current_y + 20
        for line in name_lines:
            name_text = font_name.render(line, True, self.resources.get_color('text'))
            name_rect = name_text.get_rect(centerx=current_x + current_width // 2, y=y_offset)
            self.screen.blit(name_text, name_rect)
            y_offset += 28
        
        # Séparateur
        sep_y = y_offset + 10
        pygame.draw.line(self.screen, self.resources.get_color('panel_border'),
                        (current_x + 20, sep_y),
                        (current_x + current_width - 20, sep_y), 2)
        
        # Icône de couleur
        color_circle_radius = 15
        color_circle_pos = (current_x + 30, sep_y + 25)
        pygame.draw.circle(self.screen, base_color, color_circle_pos, color_circle_radius)
        pygame.draw.circle(self.screen, self.resources.get_color('panel_border'), 
                         color_circle_pos, color_circle_radius, 2)
        
        # Type de pièce
        font_info = self.resources.get_font('small')
        type_text = font_info.render(f"Type: {room.color.value.upper()}", True, self.resources.get_color('text'))
        type_rect = type_text.get_rect(x=current_x + 60, y=sep_y + 15)
        self.screen.blit(type_text, type_rect)
        
        # Rareté avec étoiles
        rarity_y = sep_y + 40
        rarity_stars = "★" * (room.rarity + 1)
        star_color = self._get_rarity_color(room.rarity)
        rarity_text = font_info.render(f"Rarity: {rarity_stars}", True, star_color)
        rarity_rect = rarity_text.get_rect(x=current_x + 30, y=rarity_y)
        self.screen.blit(rarity_text, rarity_rect)
        
        # Coût en gemmes
        cost_y = rarity_y + 25
        can_afford = inventory.gems.quantity >= room.gem_cost
        cost_color = self.resources.get_color('text') if can_afford else (255, 100, 100)
        
        gem_text = f"Cost: {room.gem_cost} 💎"
        if room.gem_cost == 0:
            gem_text = "FREE 🎁"
        
        cost_text = font_info.render(gem_text, True, cost_color)
        cost_rect = cost_text.get_rect(x=current_x + 30, y=cost_y)
        self.screen.blit(cost_text, cost_rect)
        
        # Items dans la pièce (si disponibles)
        if room.items:
            items_y = cost_y + 25
            items_text = font_info.render(f"Items: {len(room.items)}", True, self.resources.get_color('text_dark'))
            items_rect = items_text.get_rect(x=current_x + 30, y=items_y)
            self.screen.blit(items_text, items_rect)
        
        # Indicateur de sélection
        if is_selected:
            selector_y = current_y + current_height + 10
            selector_text = font_info.render("▼ SELECTED ▼", True, self.resources.get_color('text_highlight'))
            selector_rect = selector_text.get_rect(centerx=current_x + current_width // 2, y=selector_y)
            self.screen.blit(selector_text, selector_rect)
    
    def _get_rarity_color(self, rarity: int) -> tuple:
        """Retourne la couleur selon la rareté."""
        colors = [
            (200, 200, 200),  # Commun - Gris
            (100, 200, 100),  # Peu commun - Vert
            (100, 150, 255),  # Rare - Bleu
            (200, 100, 255),  # Très rare - Violet
        ]
        return colors[rarity] if rarity < len(colors) else colors[-1]
    
    def _wrap_text(self, text: str, font: pygame.font.Font, max_width: int) -> list:
        """Découpe le texte en plusieurs lignes si nécessaire."""
        words = text.split()
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            if font.size(test_line)[0] <= max_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines if lines else [text]