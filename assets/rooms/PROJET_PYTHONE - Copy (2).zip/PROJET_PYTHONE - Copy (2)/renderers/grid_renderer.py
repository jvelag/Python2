"""
Rendu de la grille du manoir.
Jour 5 : Affichage graphique de la grille.
"""

import pygame
from models.manor import Manor
from models.player import Player
from utils.resource_manager import ResourceManager


class GridRenderer:
    """Affiche la grille du manoir avec des effets visuels améliorés."""
    
    def __init__(self, screen: pygame.Surface, resources: ResourceManager):
        self.screen = screen
        self.resources = resources
        
        # ✅ OPTIMISATION: Espacement optimal
        self.grid_start_x = 220  # ← Encore plus à droite
        self.grid_start_y = 220  # ← Encore plus bas
        self.cell_size = 110     # ← Cellules légèrement plus grandes
        self.cell_padding = 15   # ← Plus d'espace interne
        self.cell_spacing = 8    # ← Espace entre les cellules
        
        # Animations
        self.animation_time = 0
        self.player_pulse = 0
        
    def render_grid(self, manor: Manor, player: Player):
        """Affiche la grille complète avec animations."""
        # Mise à jour des animations
        self.animation_time += 1
        self.player_pulse = abs(pygame.time.get_ticks() % 1000 - 500) / 500
        
        # ✅ OPTIMISATION: Titre mieux positionné
        font_title = self.resources.get_font('title')
        title = font_title.render("BLUE PRINCE", True, self.resources.get_color('text'))
        title_shadow = font_title.render("BLUE PRINCE", True, (30, 30, 60))
        
        self.screen.blit(title_shadow, (self.grid_start_x + 3, 52))
        self.screen.blit(title, (self.grid_start_x, 50))
        
        # Légende des couleurs
        self._render_color_legend()
        
        # ✅ OPTIMISATION: Grille avec espacement calculé
        total_grid_width = manor.width * (self.cell_size + self.cell_spacing) - self.cell_spacing
        total_grid_height = manor.height * (self.cell_size + self.cell_spacing) - self.cell_spacing
        
        # Centrer horizontalement si nécessaire
        actual_start_x = self.grid_start_x
        
        for row in range(manor.height):
            for col in range(manor.width):
                x = actual_start_x + col * (self.cell_size + self.cell_spacing)
                y = self.grid_start_y + row * (self.cell_size + self.cell_spacing)
                
                self._render_cell(manor, player, row, col, x, y)
    
    def _render_cell(self, manor: Manor, player: Player, row: int, col: int, x: int, y: int):
        """Affiche une cellule de la grille avec effets visuels."""
        position = (row, col)
        room = manor.get_room(position)
        
        # ✅ OPTIMISATION: Rectangle avec espacement optimal
        cell_rect = pygame.Rect(
            x + self.cell_padding,
            y + self.cell_padding,
            self.cell_size - 2 * self.cell_padding,
            self.cell_size - 2 * self.cell_padding
        )
        
        # Effet de surbrillance pour la cellule du joueur
        is_player_cell = position == player.position
        
        if position == manor.entrance_position:
            self._render_entrance_cell(cell_rect, is_player_cell)
            
        elif position == manor.exit_position:
            self._render_exit_cell(cell_rect, is_player_cell)
            
        elif room and room.visited:
            self._render_visited_room(room, cell_rect, is_player_cell)
            
        else:
            self._render_unknown_cell(cell_rect, is_player_cell)
        
        # Portes visibles
        if room and room.visited:
            self._render_doors(room, cell_rect)
        
        # ✅ OPTIMISATION: Joueur dessiné après tout le reste
        if is_player_cell:
            self._draw_player(cell_rect)
    
    def _render_entrance_cell(self, cell_rect: pygame.Rect, is_player_cell: bool):
        """Affiche la cellule d'entrée."""
        base_color = self.resources.get_color('entrance')
        if is_player_cell:
            pulse_factor = 0.7 + 0.3 * self.player_pulse
            highlight_color = (
                min(255, int(base_color[0] * pulse_factor)),
                min(255, int(base_color[1] * pulse_factor)),
                min(255, int(base_color[2] * pulse_factor))
            )
            pygame.draw.rect(self.screen, highlight_color, cell_rect, border_radius=10)
        else:
            pygame.draw.rect(self.screen, base_color, cell_rect, border_radius=10)
        
        pygame.draw.rect(self.screen, self.resources.get_color('panel_border'), cell_rect, 3, border_radius=10)
        
        # ✅ OPTIMISATION: Meilleur espacement du contenu
        font_icon = self.resources.get_font('medium')
        icon = font_icon.render("🚪", True, self.resources.get_color('text'))
        icon_rect = icon.get_rect(center=(cell_rect.centerx, cell_rect.centery - 15))
        self.screen.blit(icon, icon_rect)
        
        self._draw_text_centered("START", cell_rect, 'small', y_offset=20)
    
    def _render_exit_cell(self, cell_rect: pygame.Rect, is_player_cell: bool):
        """Affiche la cellule de sortie."""
        base_color = self.resources.get_color('exit')
        if is_player_cell:
            pulse_factor = 0.7 + 0.3 * self.player_pulse
            highlight_color = (
                min(255, int(base_color[0] * pulse_factor)),
                min(255, int(base_color[1] * pulse_factor)),
                min(255, int(base_color[2] * pulse_factor))
            )
            pygame.draw.rect(self.screen, highlight_color, cell_rect, border_radius=10)
        else:
            pygame.draw.rect(self.screen, base_color, cell_rect, border_radius=10)
        
        pygame.draw.rect(self.screen, self.resources.get_color('panel_border'), cell_rect, 3, border_radius=10)
        
        font_icon = self.resources.get_font('medium')
        icon = font_icon.render("🏆", True, self.resources.get_color('text'))
        icon_rect = icon.get_rect(center=(cell_rect.centerx, cell_rect.centery - 15))
        self.screen.blit(icon, icon_rect)
        
        self._draw_text_centered("EXIT", cell_rect, 'small', y_offset=20)
    
    def _render_visited_room(self, room, cell_rect: pygame.Rect, is_player_cell: bool):
        """Affiche une pièce visitée."""
        base_color = self.resources.get_color(room.color.value)
        
        # Effet de brillance pour les pièces rares
        if room.rarity >= 2:
            shine_alpha = int(100 + 50 * abs(pygame.time.get_ticks() % 1000 - 500) / 500)
            shine_surface = pygame.Surface((cell_rect.width, cell_rect.height), pygame.SRCALPHA)
            pygame.draw.rect(shine_surface, (*base_color[:3], shine_alpha), shine_surface.get_rect(), border_radius=10)
            self.screen.blit(shine_surface, cell_rect)
        
        if is_player_cell:
            pulse_factor = 0.8 + 0.2 * self.player_pulse
            highlight_color = (
                min(255, int(base_color[0] * pulse_factor)),
                min(255, int(base_color[1] * pulse_factor)),
                min(255, int(base_color[2] * pulse_factor))
            )
            pygame.draw.rect(self.screen, highlight_color, cell_rect, border_radius=10)
        else:
            pygame.draw.rect(self.screen, base_color, cell_rect, border_radius=10)
        
        border_color = self.resources.get_color('panel_border')
        if room.rarity == 1:
            border_color = (100, 100, 200)
        elif room.rarity == 2:
            border_color = (180, 80, 220)
        elif room.rarity == 3:
            border_color = (220, 180, 40)
            
        pygame.draw.rect(self.screen, border_color, cell_rect, 2, border_radius=10)
        
        # ✅ OPTIMISATION: Meilleur espacement du contenu
        room_icons = {
            "Library": "📚", "Kitchen": "🍳", "Workshop": "🛠️", 
            "Treasury": "💰", "Shop": "🛒", "Market": "🏪",
            "Greenhouse": "🌿", "Furnace": "🔥", "Bedroom": "🛏️",
            "Study": "📖", "Armory": "⚔️", "Wine Cellar": "🍷",
            "Laboratory": "🧪", "Dining Hall": "🍽️", "Lucky Room": "🍀",
            "Vault": "🔒", "Secret Room": "🕵️", "Throne Room": "👑",
            "Maze Room": "🧩"
        }
        
        icon = room_icons.get(room.name, "🏠")
        font_icon = self.resources.get_font('small')
        icon_surface = font_icon.render(icon, True, self.resources.get_color('text'))
        icon_rect = icon_surface.get_rect(center=(cell_rect.centerx, cell_rect.centery - 12))
        self.screen.blit(icon_surface, icon_rect)
        
        # Nom tronqué avec meilleure gestion
        room_name = room.name
        if len(room.name) > 10:
            room_name = room.name[:9] + ".."
        self._draw_text_centered(room_name, cell_rect, 'small', y_offset=15)
        
        # Indicateur de rareté
        if room.rarity > 0:
            rarity_stars = "⭐" * room.rarity
            star_font = self.resources.get_font('small')
            star_surface = star_font.render(rarity_stars, True, (255, 215, 0))
            star_rect = star_surface.get_rect(center=(cell_rect.centerx, cell_rect.bottom - 12))
            self.screen.blit(star_surface, star_rect)
    
    def _render_unknown_cell(self, cell_rect: pygame.Rect, is_player_cell: bool):
        """Affiche une cellule non découverte."""
        base_color = self.resources.get_color('panel')
        if is_player_cell:
            pulse_color = (
                min(255, int(base_color[0] * (1 + 0.2 * self.player_pulse))),
                min(255, int(base_color[1] * (1 + 0.2 * self.player_pulse))),
                min(255, int(base_color[2] * (1 + 0.2 * self.player_pulse)))
            )
            pygame.draw.rect(self.screen, pulse_color, cell_rect, border_radius=10)
        else:
            pygame.draw.rect(self.screen, base_color, cell_rect, border_radius=10)
        
        pygame.draw.rect(self.screen, self.resources.get_color('grid_line'), cell_rect, 2, border_radius=10)
        
        # Point d'interrogation animé
        question_alpha = 150 + int(50 * abs(pygame.time.get_ticks() % 1000 - 500) / 500)
        font = self.resources.get_font('medium')
        question_surface = font.render("?", True, (*self.resources.get_color('text')[:3], question_alpha))
        question_rect = question_surface.get_rect(center=cell_rect.center)
        self.screen.blit(question_surface, question_rect)
    
    def _render_doors(self, room, cell_rect: pygame.Rect):
        """Affiche les portes de la pièce."""
        door_size = 8  # ← Légèrement plus grandes
        for direction, door in room.doors.items():
            if direction == 'north':
                pygame.draw.rect(self.screen, self._get_door_color(door), 
                               (cell_rect.centerx - door_size, cell_rect.top - 4, door_size * 2, 5))
            elif direction == 'south':
                pygame.draw.rect(self.screen, self._get_door_color(door), 
                               (cell_rect.centerx - door_size, cell_rect.bottom - 1, door_size * 2, 5))
            elif direction == 'east':
                pygame.draw.rect(self.screen, self._get_door_color(door), 
                               (cell_rect.right - 1, cell_rect.centery - door_size, 5, door_size * 2))
            elif direction == 'west':
                pygame.draw.rect(self.screen, self._get_door_color(door), 
                               (cell_rect.left - 4, cell_rect.centery - door_size, 5, door_size * 2))
    
    def _get_door_color(self, door):
        """Retourne la couleur selon l'état de la porte."""
        if door.is_open:
            return (100, 200, 100)
        elif door.lock_level == 1:
            return (200, 150, 50)
        elif door.lock_level == 2:
            return (200, 50, 50)
        else:
            return (150, 150, 150)
    
    def _render_color_legend(self):
        """Affiche la légende avec espacement optimal."""
        legend_y = self.grid_start_y - 50  # ← Plus d'espace au-dessus
        
        # ✅ OPTIMISATION: Légende mieux espacée
        colors_line1 = [
            ("blue", "Standard"),
            ("yellow", "Commerce"), 
            ("green", "Nature")
        ]
        colors_line2 = [
            ("purple", "Magie"),
            ("orange", "Chance"),
            ("red", "Secret")
        ]
        
        # Première ligne avec plus d'espace
        for i, (color, label) in enumerate(colors_line1):
            x = self.grid_start_x + i * 160  # ← Plus d'espace
            pygame.draw.circle(self.screen, self.resources.get_color(color), (x, legend_y), 10)  # ← Plus grandes
            font = self.resources.get_font('small')
            text = font.render(label, True, self.resources.get_color('text_dark'))
            self.screen.blit(text, (x + 20, legend_y - 12))  # ← Plus d'espace après la pastille
        
        # Deuxième ligne avec bon espacement
        legend_y += 30  # ← Plus d'espace entre les lignes
        for i, (color, label) in enumerate(colors_line2):
            x = self.grid_start_x + i * 160
            pygame.draw.circle(self.screen, self.resources.get_color(color), (x, legend_y), 10)
            font = self.resources.get_font('small')
            text = font.render(label, True, self.resources.get_color('text_dark'))
            self.screen.blit(text, (x + 20, legend_y - 12))
    
    def _draw_player(self, cell_rect: pygame.Rect):
        """Dessine le joueur avec animation."""
        center_x = cell_rect.centerx
        center_y = cell_rect.centery
        
        # Cercle externe pulsant
        pulse_radius = 15 + 3 * self.player_pulse  # ← Légèrement plus grand
        pygame.draw.circle(
            self.screen,
            (*self.resources.get_color('player')[:3], 150),
            (center_x, center_y),
            pulse_radius
        )
        
        # Joueur principal
        pygame.draw.circle(
            self.screen,
            self.resources.get_color('player'),
            (center_x, center_y),
            12  # ← Légèrement plus grand
        )
        
        # Reflet
        pygame.draw.circle(
            self.screen,
            (255, 255, 255, 100),
            (center_x - 4, center_y - 4),  # ← Ajusté
            4  # ← Légèrement plus grand
        )
        
        # Contour
        pygame.draw.circle(
            self.screen,
            self.resources.get_color('text'),
            (center_x, center_y),
            12,  # ← Ajusté
            2
        )
    
    def _draw_text_centered(self, text: str, rect: pygame.Rect, font_size: str, y_offset=0):
        """Dessine du texte centré dans un rectangle avec décalage optionnel."""
        font = self.resources.get_font(font_size)
        text_surface = font.render(text, True, self.resources.get_color('text'))
        text_rect = text_surface.get_rect(center=(rect.centerx, rect.centery + y_offset))
        self.screen.blit(text_surface, text_rect)


# Test
if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((1200, 800))  # ← Taille adaptée
    resources = ResourceManager()
    
    from models.manor import Manor
    from models.player import Player
    from models.room import Room, RoomColor
    
    manor = Manor()
    player = Player(manor.entrance_position)
    
    # Place quelques pièces pour le test
    rooms_to_place = [
        ("Library", RoomColor.BLUE, 0, (3, 3)),
        ("Treasury", RoomColor.PURPLE, 2, (2, 2)),
        ("Greenhouse", RoomColor.GREEN, 1, (4, 4)),
        ("Shop", RoomColor.YELLOW, 1, (1, 1)),
        ("Secret Room", RoomColor.RED, 3, (0, 3))
    ]
    
    for name, color, rarity, pos in rooms_to_place:
        room = Room(name, color, rarity)
        room.visited = True
        from models.door import Door
        room.add_door('north', Door(0))
        room.add_door('east', Door(1))
        manor.place_room(room, pos)
    
    renderer = GridRenderer(screen, resources)
    
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        screen.fill(resources.get_color('background'))
        renderer.render_grid(manor, player)
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()